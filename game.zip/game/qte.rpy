init: #QTE stuff
    $ time_max = 0
    $ timer_jump = 0
    $ time = 0
    
    #Images
    image qte_base = "images/qte/qte_base.png"
    image qte_ca_a01 = "images/qte/qte_ca_a01.png"
    image qte_ca_b01 = "images/qte/qte_ca_b01.png"
    image qte_ca_b02 = "images/qte/qte_ca_b02.png"
    image qte_ca_bf01 = "images/qte/qte_ca_bf01.png"
    image qte_ca_bf02 = "images/qte/qte_ca_bf02.png"
    image qte_ca_bf03 = "images/qte/qte_ca_bf03.png"
    image qte_ca_bf04 = "images/qte/qte_ca_bf04.png"
    image qte_ca_bg01 = "images/qte/qte_ca_bg01.png"
    # image qte_ca_c03 = "images/qte/qte_ca_c03.png"
    image qte_ca_d01 = "images/qte/qte_ca_d01.png"
    image qte_ca_d02 = "images/qte/qte_ca_d02.png"
    image qte_ca_ef01 = "images/qte/qte_ca_ef01.png"
    image qte_ca_g01 = "images/qte/qte_ca_g01.png"
    image qte_ca_van01 = "images/qte/qte_ca_van01.png"
    image qte_ca_van02 = "images/qte/qte_ca_van02.png"
    image qte_ca_wil01 = "images/qte/qte_ca_wil01.png"
    image qte_ca_wil02 = "images/qte/qte_ca_wil02.png"
    image qte_ca_zal01 = "images/qte/qte_ca_zal01.png"
    image qte_ca_zal02 = "images/qte/qte_ca_zal02.png"

    image qte_fr_a01 = "images/qte/qte_fr_a01.png"
    image on_switch ="images/qte/qte_fr_a02.png"
    image off_switch = "images/qte/qte_fr_a03.png"
    image off_hover_switch = "images/qte/qte_fr_a04.png"

    image qte_fr_b01 = "images/qte/qte_fr_b01.png"
    image qte_fr_b02 = "images/qte/qte_fr_b02.png"
    image qte_fr_b03 = "images/qte/qte_fr_b03.png"
    image qte_fr_b04 = "images/qte/qte_fr_b04.png"

    image baskets = "images/qte/qte_jp_a01.png"

    image qte_jp_b01 = "images/qte/qte_jp_b01.png"
    image qte_jp_c01 = "images/qte/qte_jp_c01.png"
    image qte_jp_d01 = "images/qte/qte_jp_d01.png"

    #Effect
    image qte_ef_radial01 = "images/qte/qte_ef_radial01.png"
    image qte_ef_radial_add = Transform("qte_ef_radial", additive=True)
    
    image fr_com_ef_shoujomanga_add = Transform("fr_com_ef_shoujomanga", additive=True)

# position config for QTE
transform center_qte:
    xalign 0.5
    yalign 0.2

transform upper_qte:
    xalign 0.5
    yalign 0.05

transform center_bf:
    xalign 0.3
    yalign 0.0
    zoom 0.95

transform center_puppet:
    xalign 0.7
    yalign 0.295

transform center_puppet_single:
    xalign 0.65
    yalign 0.425

transform center_ef:
    xalign 0.72
    yalign 0.2

transform left_qte:
    xalign -0.1
    yalign 0.2

transform right_qte:
    xalign 1.1
    yalign 0.2

transform switches_bg:
    xalign 0.5
    yalign 0.5


# for debug
style dev_debug_frame is default:
    background "#ff00ff40"  

#QTE Styles
style qte_button_01 is button:
    background "images/qte/qte_ca_options01.png"
    hover_background "images/qte/qte_ca_options01_hover.png"
    xysize(419,107)

style qte_button_02 is button:
    background "images/qte/qte_ca_options02.png"
    hover_background "images/qte/qte_ca_options02_hover.png"
    xysize(419,114)

style qte_button_01_text is button_text:
    color "#F3E7DB"
    size 42
    bold True
    yalign 0.3

style qte_button_02_text is button_text:
    color "#F3E7DB"
    size 42
    bold True
    yalign 0.4

screen countdown(bar_position):
    zorder 50
    timer 0.05 repeat True action If(time > 0.0, true=SetVariable('time', time - 0.05), false=[Return(0), Hide('countdown'), Jump(timer_jump)])
    bar:
        value time
        range time_max
        if bar_position == "chapter1":
            xalign 0.5
            yalign 0.65
            yoffset 15
        elif bar_position == "chapter2":
            xalign 0.5
            yalign 0.8
        elif bar_position == "chapter3":
            xalign 0.5
            yalign 0.75
        elif bar_position == "switches":
            xalign 0.5
            yalign 0.1
        xmaximum 300
        if time <  (time_max * 0.25):
            left_bar "#f00"
            
screen showMove(x, y):    
    add "images/qte/qte_ca_d02.png" xalign x yalign y
    timer 0.2 action Hide("showMove")

screen showIcon():
    add "gui/inventory/frame_photo_icon.png" yalign 0.5 xalign 0.5

screen failed_screen(target_label):
    modal True
    frame:
        style "failed_window"
        vbox:
            xalign 0.5
            yalign 0.75
            spacing 30
            text "Try again my hero!" style "failed_text"
            textbutton "Retry" action Jump(target_label) style "failed_textbutton"

style failed_text is text:
    color "#473027"
    xalign 0.5

style failed_textbutton is menuback_textbutton:
    xalign 0.5

style failed_textbutton_text is menuback_textbutton_text

style switches_window:
    xysize(1100,748)
    xalign 0.5
    yalign 0.5
    background Frame("images/qte/qte_fr_a01.png")

style bomb_window:
    xysize(632,641)
    xalign 0.5
    yalign 0.5
    background Frame("images/qte/qte_fr_bomb_base.png")    

style bomb_buttons:
    xalign 0.5
    yalign 0.5
    xspacing 1
    yspacing 5
    yoffset 1
    xoffset -2

style failed_window:
    xysize (445,273)
    xpadding 75
    ypadding 25
    xalign 0.5
    yalign 0.5
    background Frame("system/system_popup_3.png")

init python: #simon says
    def show_sequence(given_sequence):
        for l in given_sequence:
            _window_hide
            renpy.show_screen("simonvoid")
            renpy.pause(0.5, hard=True)
            renpy.hide_screen("simonvoid")
            renpy.play("audio/france/fr_se_bomb_switch.mp3")
            renpy.show_screen("simon_show",l)
            renpy.pause(0.5,hard=True)
            renpy.hide_screen("simon_show")

    def create_sequence(number):
        for i in range(number):
            roll=renpy.random.randint(0,3)
            sequence.append(roll)

screen simon_show(thesign):
    frame:
        style "bomb_window"
        grid 2 2:
            style "bomb_buttons"
            if thesign==0:
                add "qte/qte_fr_yellow_lit.png" #play sound
            else:
                add "qte/qte_fr_yellow.png"
                
            if thesign==1:
                add "qte/qte_fr_pink_lit.png"
            else:
                add "qte/qte_fr_pink.png"
                
            if thesign==2:
                add "qte/qte_fr_green_lit.png"
            else:
                add "qte/qte_fr_green.png"
                
            if thesign==3:
                add "qte/qte_fr_blue_lit.png"
            else:
                add "qte/qte_fr_blue.png"    

screen simonvoid(): #Shows default
    frame:
        style "bomb_window"
        grid 2 2:
            style "bomb_buttons"
            add "qte/qte_fr_yellow.png"
            add "qte/qte_fr_pink.png"
            add "qte/qte_fr_green.png"
            add "qte/qte_fr_blue.png"

screen simoncheck(): #For Pressing
    frame:
        style "bomb_window"
        grid 2 2:
            style "bomb_buttons"
            imagebutton idle "qte/qte_fr_yellow.png" hover "qte/qte_fr_yellow_lit.png" action [Play("sound","audio/france/fr_se_bomb_switch.mp3"),Return(0)] #Add sound when clicking
            imagebutton idle "qte/qte_fr_pink.png" hover "qte/qte_fr_pink_lit.png" action [Play("sound","audio/france/fr_se_bomb_switch.mp3"),Return(1) ]
            imagebutton idle "qte/qte_fr_green.png" hover "qte/qte_fr_green_lit.png" action [Play("sound","audio/france/fr_se_bomb_switch.mp3"),Return(2)]
            imagebutton idle "qte/qte_fr_blue.png" hover "qte/qte_fr_blue_lit.png" action [Play("sound","audio/france/fr_se_bomb_switch.mp3"),Return(3) ]    