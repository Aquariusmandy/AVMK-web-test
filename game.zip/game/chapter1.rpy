label chapter_1:
    $ current_ch = 1
    stop music fadeout 1.0  # Fade out the menu music
    play music "audio/canada/ca_bgm_01.mp3" loop fadein 1.0  # Loop game music with fade in

    show bg_tree
    "This is Ryu."
    "Beloved puppy of Vantacrow Bringer."
    "And, at the present, a very full little dog."
    "Mmrrf..."
    "Nestled beneath the Christmas tree, Ryu slowly wakes from a most significant food coma."
    "For a moment, he cannot quite remember how he got there."
    "There had been chicken."
    "Lots of chicken."
    "Somthing sweet."
    "Something sticky."
    "And a particularly wonderful pudding..."
    "Mmrrf..."
    "Perhaps it had all been a dream."
    "A wonderful, delicouis Christmas dream."
    "Ah..."
    "Ryu yawns. The pauses."
    "There's still a suspicious hint of caramel stuck between his teeth."
    "...!"
    "Ah."
    "Not a dream, then."
    "Ryu looks around."
    "The house is quiet. Everyone is still alseep."
    "The presents are waiting beneath the tree."
    "The decorations are twinkling."
    "Everything is exactly as it should be on Christmas morning."
    "Except-"
    "Ryu looks towards the dining table."
    "...Ruff?"
    "Everyone had been busy the night before, preparing everything they would need for today's Christmas feast."
    "At least..."
    "Ryu was fairly certain there had been more of it."
    "Whines..."
    "Much more of it."
    "Now, there's is absolutely no evidence that ryu had anything to do with this."
    "Woof..."
    "None whatsoever."
    "But there will be plenty of questions when everyone wakes up."
    "And Christmas without a Christmas feast?"
    "Unthinkable."
    "Ryu rises to his paws."
    "There's still time."
    "Three parts of the Christmas feast are missing, and three very important jobs need doing."
    "If Ryu can put everything back together before everyone wakes up..."
    "Perhaps Christmas can still be saved."
    "WOOF!"
    "And so begins Ryu's most important mission yet."
    pause 0.5
    window hide
    jump dish_choice
    ##show screen continue_buttons

