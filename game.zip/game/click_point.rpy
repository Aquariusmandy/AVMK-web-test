# Define achievement sets for different screens

# Canada
# sequence in list:
#Sticker -> popup image, message when pape is found, pape position, item name
#Photodiary -> corresponding index in ca_achievements_images
# 01 -> Wilson & Lamia
# 02 -> Wen & Willy Milk
# 03 -> USAMI & Pancrepes
# 04 -> Rube & Tiger Tail Ice Cream
# 05 -> Koya & KFC
define ca_achievements = {
    'sticker_ca_01': ['gui/inventory/minigame/get_pop_pape/get_ca_nui_01.webp',_("Want to drive Wilson feral? \nTry a seductive half-snake enchantress. \nNo questions asked."),(700,575),_("Lamia?")], 
    'sticker_ca_02': ['gui/inventory/minigame/get_pop_pape/get_ca_nui_02.webp',_("Limited edition. Freshly squeezed. \nThirsty? You know you want a taste."),(1175,750),_("Willy Milk")],
    'sticker_ca_03': ['gui/inventory/minigame/get_pop_pape/get_ca_nui_03.webp',_("Wilson\'s signature crepes... \nor are they pancakes? \nEither way, they\'re delicious. Probably."),(1115,150),_("Crêpes (or pancakes?)")],
    'sticker_ca_04': ['gui/inventory/minigame/get_pop_pape/get_ca_nui_04.webp',_("Said to mark both the beginning \nand end of Calamitycrow. \nA legendary orange licorice ice cream in Canada, \nallegedly worth a two-hour detour."),(1000,375),_("Tiger Tail Ice Cream")],
    'sticker_ca_05': ['gui/inventory/minigame/get_pop_pape/get_ca_nui_05.webp',_("Willerton\'s pet żar-ptak. \nAlso known as KFC. \nHe\'s recently became a parent\n—totally unplanned."),(475,550),_("Krisis Fantastic Chicken")],
    'photodiary_ca_01':[2],
    'photodiary_ca_02':[0,1],
    'photodiary_ca_03':[3,4]

}

define ca_achievement_images = ['gui/inventory/minigame/pape/minigame_pape_ca_01.png', 'gui/inventory/minigame/pape/minigame_pape_ca_02.png', 'gui/inventory/minigame/pape/minigame_pape_ca_03.png','gui/inventory/minigame/pape/minigame_pape_ca_04.png','gui/inventory/minigame/pape/minigame_pape_ca_05.png']

default persistent.ca_captured = [False] * len(ca_achievement_images)
default persistent.ca_achievement_unlocked = [False] * len(ca_achievement_images)

# France
# sequence in list:
#Sticker -> popup image, message when pape is found, pape position, item name
#Photodiary -> corresponding index in fr_achievements_images
# 01 -> Kagetsu & Creme Brulee
# 02 -> Zali & Blue Cheese
# 03 -> Mana & Zalitamin
# 04 -> Vanta & French Toast
# 05 -> Zali & Fire Underwear
define fr_achievements = {
    'sticker_fr_01': ['gui/inventory/minigame/get_pop_pape/get_fr_nui_01.webp',_("Zali\'s favorite dessert. \nHomemade versions may spontaneously \nbecome...caramelized omelets."),(800,600),_("Crème Brûlée")], 
    'sticker_fr_02': ['gui/inventory/minigame/get_pop_pape/get_fr_nui_02.webp',_("\"Delicious!\nEveryone loves blue cheese!\" —Zali"),(1600,835),_("Blue Cheese")],
    'sticker_fr_03': ['gui/inventory/minigame/get_pop_pape/get_fr_nui_03.webp',_("Tasty, nutritious, and wildly popular! \nFor more details, consult \nmedical hero Vezalius Bandage.\nSide effects: unknown. \nUse with reckless confidence."),(825,550),_("Zalitamin")],
    'sticker_fr_04': ['gui/inventory/minigame/get_pop_pape/get_fr_nui_04.webp',_("Fluffy, sweet, and absolutely irresistible. \nFrench toast with American butter \nand Canadian maple syrup—heroic perfection."),(1400,550),_("French Toast")],
    'sticker_fr_05': ['gui/inventory/minigame/get_pop_pape/get_fr_nui_05.webp',_("Rumored to be a navy-blue brief \ncovered in tiny flames.\nFor Krisis\' eyes only."),(690,575),_("Flame Underwear")],
    'photodiary_fr_01':[0,1],
    'photodiary_fr_02':[2,3],
    'photodiary_fr_03':[4]    
}

define fr_achievement_images = ['gui/inventory/minigame/pape/minigame_pape_fr_01.png', 'gui/inventory/minigame/pape/minigame_pape_fr_02.png', 'gui/inventory/minigame/pape/minigame_pape_fr_03.png','gui/inventory/minigame/pape/minigame_pape_fr_04.png','gui/inventory/minigame/pape/minigame_pape_fr_05.png']

default persistent.fr_captured = [False] * len(fr_achievement_images)
default persistent.fr_achievement_unlocked = [False] * len(fr_achievement_images)

# Japan
# sequence in list:
#Sticker -> popup image, message when pape is found, pape position, item name
#Photodiary -> corresponding index in jp_achievements_images
# 01 -> Testu & Tamago Sando
# 02 -> Vanta & Josh
# 03 -> Inami & Lemon Sour
# 04 -> Vanta & Sushi Bake
# 05 -> Wilson & Vanvan, Yuyu, Banban
define jp_achievements = {
    'sticker_jp_01': ['gui/inventory/minigame/get_pop_pape/get_jp_nui_01.webp',_("A new recipe Vanta discovered recently.\n Nothing tastes better than \nwhen it\'s shared with the homies."),(1200,700),_("Tamago Sando")], 
    'sticker_jp_02': ['gui/inventory/minigame/get_pop_pape/get_jp_nui_02.webp',_("The first dragon Vantus ever tamed. \nBrave. Loyal. Unforgotten. \nHis spirit lives on in every dragon that followed."),(600,650),_("Josh")],
    'sticker_jp_03': ['gui/inventory/minigame/get_pop_pape/get_jp_nui_03.webp',_("The most beloved beverage among Krisis.\nLemon sour or lemon soda? \nJust serve it in a giga pitcher!"),(1325,400),_("Lemon Sour")],
    'sticker_jp_04': ['gui/inventory/minigame/get_pop_pape/get_jp_nui_04.webp',_("A dish Vanta loves to cook. \nJapanese? American? Who knows anymore. \nClaude didn\'t ask. He just inhaled it."),(1600,600),_("Sushi Bake")],
    'sticker_jp_05': ['gui/inventory/minigame/get_pop_pape/get_jp_nui_05.webp',_("A trio of dog siblings from an enchanted town, \noften seen playing and goofing around together. \nTheir names feel eerily familiar..."),(600,410),_("Vanvan, Yuyu, Banban")],
    'photodiary_jp_01':[0,1],
    'photodiary_jp_02':[2],
    'photodiary_jp_03':[3,4] 
}

define jp_achievement_images = ['gui/inventory/minigame/pape/minigame_pape_jp_01.png', 'gui/inventory/minigame/pape/minigame_pape_jp_02.png', 'gui/inventory/minigame/pape/minigame_pape_jp_03.png','gui/inventory/minigame/pape/minigame_pape_jp_04.png','gui/inventory/minigame/pape/minigame_pape_jp_05.png']

default persistent.jp_captured = [False] * len(jp_achievement_images)
default persistent.jp_achievement_unlocked = [False] * len(jp_achievement_images)

# Popup when pape is found according to country
screen ca_stickers_unlocked(achievement_id):
    modal True
    zorder 1001
    add "gui/inventory/frame_get_popup.png" xalign 0.5 yalign 0.5
    text ca_achievements.get(achievement_id)[3] xalign 0.5 yalign 0.2 style "sticker_title"
    text ca_achievements.get(achievement_id)[1] xalign 0.5 yalign 0.3 style "sticker_description"
    add ca_achievements.get(achievement_id)[0] xalign 0.5 yalign  0.6 yoffset 35   
    imagebutton:
        idle "gui/inventory/button/btn_close.png"
        xpos 0.65
        ypos 0.12
        action [
            Hide("ca_stickers_unlocked"),
        ]

screen fr_stickers_unlocked(achievement_id):
    modal True
    zorder 1001
    add "gui/inventory/frame_get_popup.png" xalign 0.5 yalign 0.5
    text fr_achievements.get(achievement_id)[3] xalign 0.5 yalign 0.2 style "sticker_title"
    text fr_achievements.get(achievement_id)[1] xalign 0.5 yalign 0.3 style "sticker_description"
    add fr_achievements.get(achievement_id)[0] xalign 0.5 yalign  0.6 yoffset 35 
    imagebutton:
        idle "gui/inventory/button/btn_close.png"
        xpos 0.65
        ypos 0.12
        action [
            Hide("fr_stickers_unlocked"),
        ]

screen jp_stickers_unlocked(achievement_id):
    modal True
    zorder 1001
    add "gui/inventory/frame_get_popup.png" xalign 0.5 yalign 0.5
    text jp_achievements.get(achievement_id)[3] xalign 0.5 yalign 0.2 style "sticker_title"
    text jp_achievements.get(achievement_id)[1] xalign 0.5 yalign 0.3 style "sticker_description"
    add jp_achievements.get(achievement_id)[0] xalign 0.5 yalign  0.6 yoffset 35 
    imagebutton:
        idle "gui/inventory/button/btn_close.png"
        xpos 0.65
        ypos 0.12
        action [
            Hide("jp_stickers_unlocked"),
        ]
