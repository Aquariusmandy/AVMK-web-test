default card_amount = 14
default card_rows = 2
default cards =[]
default selected_cards =[]
default hidden_cards =0
default match_found = False
default current_dish = None
default games_played =0
default persistent.cake_notplayed = True
default persistent.eggnog_notplayed = True
default persistent.stew_notplayed = True

image card_cake_1 = "images/memory/cheese.webp"
image card_cake_2 = "images/memory/monkeybread.webp"
image card_cake_3 = "images/memory/pork.webp"
image card_cake_4 = "images/memory/potato.webp"
image card_cake_5 = "images/memory/vanta.webp"
image card_cake_6 = "images/memory/wilson.webp"
image card_cake_7 = "images/memory/zali.webp"

image card_eggnog_1 = "images/memory/cheese_2.webp"
image card_eggnog_2 = "images/memory/monkeybread_2.webp"
image card_eggnog_3 = "images/memory/pork_2.webp"
image card_eggnog_4 = "images/memory/potato_2.webp"
image card_eggnog_5 = "images/memory/vanta_2.webp"
image card_eggnog_6 = "images/memory/wilson_2.webp"
image card_eggnog_7 = "images/memory/zali_2.webp"

image card_stew_1 = "images/memory/cheese_1.webp"
image card_stew_2 = "images/memory/monkeybread_1.webp"
image card_stew_3 = "images/memory/pork_1.webp"
image card_stew_4 = "images/memory/potato_1.webp"
image card_stew_5 = "images/memory/vanta_1.webp"
image card_stew_6 = "images/memory/wilson_1.webp"
image card_stew_7 = "images/memory/zali_1.webp"

image bg_taro = "/images/bg/bg_taro.webp"
image bg_tree = "/images/bg/bg_tree.webp"

image stew = "images/memory/stew.webp"
image stew_grey = "images/memory/stew_grey.webp"
image cake = "images/memory/cake.webp"
image cake_grey = "images/memory/cake_grey.webp"
image eggnog ="images/memory/eggnog.webp"
image eggnog_grey ="images/memory/eggnog_grey.webp"

init python:
    def randomize_cards():
        global cards
        global current_dish
        cards = []

        for i in range(int(card_amount/2)):
            card_num = i+1
            card_name = f"card_{current_dish}_{card_num}"
            cards.append(["%s"% card_name, "deselected","hidden"])
            cards.append(["%s"% card_name, "deselected","hidden"])

        renpy.random.shuffle(cards)

    def select_cards(card_index):
        global selected_cards
        global match_found

        cards[card_index][1] ="selected"
        selected_cards.append(card_index)

        if len(selected_cards) ==2 and cards[selected_cards[0]][0] == cards[selected_cards[1]][0]:
            match_found = True

    def deselect_cards():
        global selected_cards

        if len(selected_cards) == 2:
            for card in cards:
                if card[1] == 'selected':
                    card[1] = 'deselected'
        selected_cards = []


    def show_matches():
        global selected_cards
        global match_found
        global hidden_cards

        cards[selected_cards[0]][2] ="visible"
        cards[selected_cards[1]][2] ="visible"
        hidden_cards +=2
        deselect_cards()
        match_found = False
    
    def end_round():
        global match_found
        global hidden_cards

        match_found = False
        hidden_cards = 0


image card_back = "images/memory/card_back.webp" 
image finished_cake = "images/memory/finished_cake_S.webp"
image finished_stew = "images/memory/finished_stew.webp"
image finished_eggnog = "images/memory/finished_eggnog.webp"

label dish_choice:
    stop music fadeout 1.0
    scene bg_taro
    if games_played == 0:
        "SAVE CHRISTMAS DINNER!"
    elif games_played == 1:
        "One dish down! A promising start. Two to go!"
    else:
        "Two down. Against all odds, this is actually working. Only one dish remains."
    call screen dish_options_1

label debug:
    "debug"

label memory_game:
    if current_dish == 'cake':
        "Pudding Cake Ryu remembers this one well."
    elif current_dish == 'eggnog':
        "Taro Eggnog, How difficult can it be?"
    else:
        "Japanese Cream Stew, Ryu knows what must be done."
    $randomize_cards();
    call screen memory_mini_game

label next_part:
    scene bg_taro 
    "And with that, the final dish is complete!"
    "Three dishes, One Christmas dinner. Somehow, Ryu has done it."
    "The feast is saved. And, more importantly..."
    "No one needs to know why it needed saving in the first place."
    $ renpy.movie_cutscene("movies/ending_animation.webm", stop_music=False)
    pause
    return

transform show_finished_card:
    xalign 0.5
    yalign 1.0
    linear 0.5 yalign 0.3

transform smooth_glow:
    on idle:
        # Return to the original image state
        easein 0.2 matrixcolor BrightnessMatrix(0.0)
    on hover:
        # Fade into a brighter glow state (0.15 is roughly +15% brightness)
        easeout 0.2 matrixcolor BrightnessMatrix(0.15)

screen dish_options:
    hbox:
        xfill True
        yfill True
        imagebutton: 
            idle "stew" 
            hover Transform("stew",zoom=1.1)
            insensitive "stew_grey"
            sensitive persistent.stew_notplayed == True 
            action[SetVariable('current_dish','stew'),Jump('memory_game')]
            yalign 0.5 xalign 0.5 
        imagebutton: 
            idle "cake" 
            hover Transform("cake",zoom=1.1)
            insensitive "cake_grey"
            sensitive persistent.cake_notplayed == True 
            action[SetVariable('current_dish','cake'),Jump('memory_game')] 
            yalign 0.5 xalign 0.5
        imagebutton: 
            idle "eggnog" 
            hover Transform("eggnog",zoom=1.1)
            insensitive "eggnog_grey"
            sensitive persistent.eggnog_notplayed == True 
            action[SetVariable('current_dish','eggnog'),Jump('memory_game')]
            yalign 0.5 xalign 0.5

transform hover_zoom:
    anchor (0.5, 0.5)
    pos (0.5, 0.5)
    on idle:
        ease 0.1 zoom 1.0
    on hover:
        ease 0.1 zoom 1.1
    on insensitive:
        zoom 1.0

screen dish_options_1:
    hbox:
        xalign 0.5
        yalign 0.5
        spacing 100

        fixed:
            xysize (400, 400)   # set to your largest image size
            imagebutton:
                idle "stew"
                insensitive "stew_grey"
                sensitive persistent.stew_notplayed == True
                action [SetVariable('current_dish', 'stew'), Jump('memory_game')]
                at hover_zoom

        fixed:
            xysize (400, 400)
            imagebutton:
                idle "cake"
                insensitive "cake_grey"
                sensitive persistent.cake_notplayed == True
                action [SetVariable('current_dish', 'cake'), Jump('memory_game')]
                at hover_zoom

        fixed:
            xysize (400, 400)
            imagebutton:
                idle "eggnog"
                insensitive "eggnog_grey"
                sensitive persistent.eggnog_notplayed == True
                action [SetVariable('current_dish', 'eggnog'), Jump('memory_game')]
                at hover_zoom

label pop_up_card:
    show screen finished_card
    if current_dish =='cake':
        'The pudding cake is back where it belongs.'
    elif current_dish == 'eggnog':
        'One perfectly purple batch of taro eggnog.'
    else:
        'Warm, creamy, and ready for Christmas!'

screen finished_card:
    modal True
    if current_dish =='cake':
        imagebutton idle "finished_cake" action [Hide('finished_card'),IncrementVariable('games_played'),SetVariable('persistent.cake_notplayed','True'),Jump('show_cg')] at show_finished_card
    elif current_dish == 'eggnog':
        imagebutton idle "finished_eggnog" action [Hide('finished_card'),IncrementVariable('games_played'),SetVariable('persistent.eggnog_notplayed','True'),Jump('show_cg')]  at show_finished_card
    else:
        imagebutton idle "finished_stew" action [Hide('finished_card'),IncrementVariable('games_played'),SetVariable('persistent.stew_notplayed','True'),Jump('show_cg')]  at show_finished_card

label show_cg:
    window hide
    if current_dish =='cake':
        show ca_st_edcg
    elif current_dish == 'eggnog':
        show fr_st_edcg
    else:
        show jp_st_edcg
    pause
    if games_played <3:
        jump dish_choice
    else:
        jump next_part

screen memory_mini_game:
    image "bg_taro"
    grid int(card_amount/card_rows) card_rows:
        align(0.5,0.5)
        spacing 25
        for i, card in enumerate(cards):
            if card[1] =='deselected' and card[2] == 'hidden':
                imagebutton: 
                    idle "images/memory/card_back_mid.webp" 
                    hover Transform("images/memory/card_back_mid.webp" , matrixcolor=BrightnessMatrix(0.25))
                    sensitive If(len(selected_cards) != 2, True, False) 
                    action Function(select_cards,card_index = i) 
            elif card[1] =='selected' and card[2]=='hidden':
                image "%s" % card[0]
            elif card[2] == 'visible':
                image "%s" % card[0]
            else:
                null
    
    if match_found:
        timer 1.0 action Function(show_matches) repeat True
    elif len(selected_cards) == 2:
        timer 1.0 action Function(deselect_cards) repeat True
    elif hidden_cards == card_amount:
        timer 0.5 action [Function(end_round),Jump('pop_up_card')] repeat False