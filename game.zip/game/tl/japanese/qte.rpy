translate japanese strings:

    # game/qte.rpy:154
    old "Try again my hero!"
    new "もう一度だ、\nヒーロー！"

   
