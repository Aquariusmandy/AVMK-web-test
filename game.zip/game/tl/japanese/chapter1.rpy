﻿# TODO: Translation updated at 2025-05-21 11:46

# game/chapter1.rpy:37
translate japanese chapter_1_c3bb6ea5:

    # "This is your first time driving in Canada—not that you're nervous. As an experienced driver, this is exactly how you want to spend the day—with your homies, cruising down the open road on a perfect summer day."
    "カナダで運転するのはこれが初めて―でも、緊張なんてしていない。\n経験豊富なドライバーとして、こんな最高の夏の日は、仲間と一緒に広い道をドライブするのが理想の過ごし方だ。"

# game/chapter1.rpy:47
translate japanese chapter_1_9a61ab37:

    # wilson_char "Thanks, Mommy—I mean, Zali... Wait, Vanta!"
    wilson_char "サンキュー、ママ―じゃなかった、ザリ…\nあ、待て、ベンタ！"

# game/chapter1.rpy:107
translate japanese chapter_1_2_9bcb70d7:

    # "After the unexpected deer encounter (and Wilson's running commentary), you finally arrive at your destination."
    "予想外の鹿との遭遇（そしてウィルソンのコメント）を経て、ついに目的地に到着する。"

# game/chapter1.rpy:122
translate japanese chapter_1_2_0b892c3b:

    # "As you pause to enjoy the scenery, your gaze drifts to the swaying treetops and the\nsunlight spilling across the peaks. The view is simply breathtaking, a moment worth holding onto forever."
    "ふと足を止め、景色をじっくりと味わう。風に揺れる木々、山の頂を照らす陽の光。\nその光景はあまりにも美しく、ずっとこの瞬間を心に刻んでおきたくなるほどだ。"

# game/chapter1.rpy:133
translate japanese chapter_1_2_85482238:

    # "You pull out your phone and snap a quick picture of the landscape, capturing the golden afternoon hues. Sliding your phone back into your pocket, you walk toward the cabin."
    "あなたはスマホを取り出し、風景の写真を素早く撮る。\n午後の金色の光に包まれた景色をカメラに収めると、スマホをポケットに戻し、キャビンへと向かう。"

# game/chapter1.rpy:137
translate japanese chapter_1_2_bd9ba639:

    # wilson_char "Wait what? Umm, guys? So..."
    wilson_char "え、何？ …おい、みんな？ これって…"

# game/chapter1.rpy:153
translate japanese chapter_1_2_5a3aa98c:

    # "Before anyone could object, Wilson walks to the bed and plops onto it, rolling over to\nthe left side."
    "誰も異議を唱える間もなく、ウィルソンは一直線にベッドへ向かい、そのままドサッと飛び込んで左側に転がった。"

# game/chapter1.rpy:165
translate japanese chapter_1_2_c462a460:

    # "Agreeing with Wilson, you settle into the cabin and begin unpacking. The warmth of the room contrasts with the crisp air outside. After sorting out your bags, you three head into town to grab ingredients for the dinner tonight."
    "ウィルソンに同意し、キャビンでくつろぎながら荷解きを始める。\n部屋の暖かさが、外のひんやりとした夕方の空気と対照的だ。\n荷物を整理した後、三人は今夜の夕食の食材を買うために町へ向かう。"

# game/chapter1.rpy:231
translate japanese chapter_1_2_e9e480d6:

    # "That leaves you to make a choice: help Zali pick up groceries and head back to camp,\nor join Wilson in tracking down the missing cows for the distraught farmer."
    "さて、あなたの選択だ。\nザリと一緒に食材を買ってキャンプに戻るか、ウィルソンと一緒に行方不明の牛を探しに行くか。"

# game/chapter1.rpy:259
translate japanese chapter_1_2_a7dab79c:

    # "You look over to Wilson, expecting him to share your unease. Instead, his eyes light\nup with excitement."
    "同じ気持ちでいてくれることを期待してウィルソンのほうを見たが、彼の目は興奮で輝いていた。"

# game/chapter1.rpy:272
translate japanese chapter_1_2_8ae8dee7:

    # "Wilson drags you along to change into your costumes, while you follow behind with much less enthusiasm."
    "ウィルソンはノリノリであなたを引っ張っていき、渋々ながらもあなたはコスチュームに着替えにいく。"

# game/chapter1.rpy:298
translate japanese chapter_1_2_ad981d3b:

    # wilson_char "{size=45}MOooOooo~~~{/size}"
    wilson_char "{size=45}モォォォ〜〜〜〜{/size}"

# game/chapter1.rpy:303
translate japanese chapter_1_2_a96721d5:

    # vanta_char "M...Moo~"
    vanta_char "モ、モォ〜"

# game/chapter1.rpy:312
translate japanese chapter_1_2_2b099d45:

    # wandv_char "{size=45}MOOOOooo~~~~~{/size}"
    wandv_char "{size=45}モオオォォォ〜〜〜〜{/size}"

# game/chapter1.rpy:323
translate japanese chapter_1_2_1ba12b22:

    # "The farmer comes over as you start bickering, laughing as he hugs his calf with joy."
    "あなたたちが言い争いを始めたところで、農夫がやってきた。\n彼は笑いながら子牛を撫で、嬉しそうに抱きしめる。"

# game/chapter1.rpy:337
translate japanese chapter_1_2_6ee42fd0:

    # vanta_char "Please stop. I am not expanding on this. I don't even want to entertain the idea."
    vanta_char "頼むからやめろ。この話を広げるつもりはないし、考えることすらしたくない。"

# game/chapter1.rpy:343
translate japanese chapter_1_2_b9ba662a:

    # "With the calf safe and the task complete, you and Wilson begin your trek back toward\nthe campsite. Sunlight fades through the trees, casting long shadows that stretch across the forest floor."
    "子牛が無事に戻り、任務が完了したところで、二人はキャンプ場へ向かって歩き始める。\n森の中に差し込む夕陽が、道に長い影を落としていた。"

# game/chapter1.rpy:373
translate japanese chapter_1_2_19a5195f:

    # "Zali spins you around, expertly securing the apron strings around your waist.\nHis movements are smooth, effortless—like he's done this a hundred times before,\nwithout a hint of hesitation."
    "ザリはあなたをくるっと回しながら、手際よくエプロンの紐を腰に結びつける。\nまるで何百回もやったことがあるかのように、迷いのないスムーズな動き。"

# game/chapter1.rpy:406
translate japanese chapter_1_2_8e809cdd:

    # "You swipe the flour with exaggerated care, brushing off the smudge while Zali\nsuppresses a chuckle, making the moment linger a second longer than necessary."
    "ふざけた調子で粉を拭うが、ザリは笑いをこらえたままじっとしていて、その一瞬が妙に長く感じる。"

# game/chapter1.rpy:465
translate japanese chapter_1_3_060426dc:

    # wilson_char "The crispy shell and gooey center—nothing beats a roasted marshmallow by a campfire."
    wilson_char "ああ、これはたまらないな。外はカリッとしていて、中はとろっとろ。\nキャンプファイヤーで焼くマシュマロに勝るものはないよ。"

# game/chapter1.rpy:466
translate japanese chapter_1_3_1e17dd04:

    # wilson_char "Man, that hits the spot."
    wilson_char "ねぇ、コレ超ヤバくない～？"

# game/chapter1.rpy:469
translate japanese chapter_1_3_56b38a11:

    # vanta_char "That's what she said."
    vanta_char "ギャルかよ。"

# game/chapter1.rpy:480
translate japanese chapter_1_3_2762efdf:

    # wilson_char "It's nice to disconnect from screens and just enjoy a quiet moment for a change."
    wilson_char "たまにはスクリーンから離れて、こうやって穏やかな時間を楽しむのも悪くないな。"

# game/chapter1.rpy:502
translate japanese chapter_1_3_6672cf95:

    # vanta_char "{size=40}Hahah! Gay~~~{/size}"
    vanta_char "{size=40}ははっ、バカップルかよ！{/size}"

# game/chapter1.rpy:504
translate japanese chapter_1_3_2cb4a73f:

    # wilson_char "{size=45}WHAT?!{/size}"
    wilson_char "{size=45}はあ？！{/size}"

# game/chapter1.rpy:511
translate japanese chapter_1_3_9c5d95c5:

    # wilson_char "Nope! it's too late!"
    wilson_char "ダメ！もう遅いよ！"

# game/chapter1.rpy:532
translate japanese chapter_1_3_67b5e7d2:

    # "Hearing Zali's voice, you slowly wake up. You rub your eyes, shuffle to the windowsill,\nand pull back the curtain slightly."
    "ザリの声に反応し、あなたもゆっくりと目を覚ます。\n目をこすりながら窓際へと歩み寄り、カーテンを少しだけ開ける。"

# game/chapter1.rpy:537
translate japanese chapter_1_3_c336adc0:

    # zali_char "Is... Is that Bigfoot?"
    zali_char "あれ…あれってビッグフット？"

# game/chapter1.rpy:555
#translate japanese chapter_1_3_509f52fe:

    # "The three of you jump out of bed, throw on some clothes (you were naked *wink*),\nand grab whatever tools are within reach."
    # "あなたたち三人はベッドから飛び起き、急いで服を着る（さっきまで裸だった😉）。\nそして手近な道具を手に取った。"

# game/chapter1.rpy:556
translate japanese chapter_1_3_5788c88a:

    # "Zali picks up a frying pan, Wilson takes a flashlight, and you manage to find...\na sturdy stick."
    "ザリはフライパンを手に取り、ウィルソンは懐中電灯を握り、あなたは…\n頑丈そうな棒を見つける。"

# game/chapter1.rpy:576
translate japanese chapter_1_example_qte_debug_048a39f6:

    # "The three of you spring into action immediately, instincts kicking in as you prepare to face\nthe oncoming attack."
    "三人は即座に反応し、本能のままに迎え撃つ準備を整える。"

# game/chapter1.rpy:659
translate japanese chapter_1_wilson_fail_33f38322:

    # "Wilson throws the flashlight and it hits Bigfoot square between the eyes. The\ncreature stumbles, but Wilson's hesitation gives it an opening, and a massive arm swings toward him."
    "ウィルソンは懐中電灯を投げつけ、それはビッグフットの眉間に直撃した。\nビックフットはよろめくが、ウィルソンのためらいが隙を生み、巨大な腕が彼に向かって振り下ろされる。"

# game/chapter1.rpy:726
translate japanese chapter_1_zali_fail_040fa1b6:

    # "To everyone's surprise, the bandage slips and the frying pan flies from Zali's hand.\nBigfoot lunges, striking before he can react."
    "誰もが驚く中、包帯がほどけ、ザリの手からフライパンが飛んでいく。\nビッグフットが飛びかかり、彼が反応する前に一撃をくらわせる。"

# game/chapter1.rpy:737
translate japanese chapter_1_zali_timeout_fc538419:

    # vanta_char "ZALI—!!!!"
    vanta_char "ザリーーー!!!!"

# game/chapter1.rpy:907
translate japanese chapter_1_vanta_clear_01425ba5:

    # zali_char "Eyyy! Good job Vanta!!"
    zali_char "おおっ！やったな、ベンタ！！"

# game/chapter1.rpy:911
translate japanese chapter_1_vanta_clear_7836c2de:

    # wilson_char "Right, should we just tie it up for now? I'll notify A.S.H. so they can take care of it first thing in the morning."
    wilson_char "とりあえず縛っておこうか？\nA.S.H.に連絡して、朝になったら処理してもらおう。"

# game/chapter1.rpy:922
translate japanese chapter_1_vanta_clear_81409d2b:

    # "As the three of you get back inside the cabin, the weight of the night's events lingers.\nThis was supposed to be a relaxing holiday, but it seems that heroes really can't catch\na break."
    "三人がキャビンに戻ると、今夜の出来事の重みがじわじわと感じられる。\n本来ならリラックスするはずの休暇だったのに、どうやらヒーローはどこへ行っても休む暇がないらしい。"

# game/chapter1.rpy:927
translate japanese chapter_1_vanta_clear_d8b2e772:

    # "{size=40}Shu Yamino.{/size}"
    "{size=40}闇ノシュウ。{/size}"

# TODO: Translation updated at 2025-06-04 22:01

# game/chapter1.rpy:14
translate japanese chapter_1_9dde5f4b:

    # "Hey, your name is Vantacrow Bringer."
    "やぁ、あなたの名前はベンタクロウ・ブリンガー。"

# game/chapter1.rpy:15
translate japanese chapter_1_7e2b3532:

    # "The Tyrant and Ace of Krisis that works under A.S.H.—or the Astronomically Sexy Heroes."
    "A.S.H.（Astronomically Sexy Heroes＝天文学的にセクシーなヒーロー）の下で働く、クライシスの暴君にしてエース。"

# game/chapter1.rpy:16
translate japanese chapter_1_0618aa75:

    # "Well, you've been saving old women and beating up bad guys with your exceptional fists."
    "まあ、普段はおばあちゃんを助けたり、悪党を拳でぶっ飛ばしたりしてるわけだが…"

# game/chapter1.rpy:17
translate japanese chapter_1_3e03de08:

    # "But today? Today is different."
    "でも、今日は違う。"

# game/chapter1.rpy:18
translate japanese chapter_1_50543284:

    # "Instead of heading into the A.S.H. office like usual, you're in a car. Driving, actually."
    "いつものようにA.S.H.のオフィスへ向かうのではなく、今は車の中にいる。\nというか運転中だ。"

# game/chapter1.rpy:19
translate japanese chapter_1_99014dd5:

    # "Sitting next to you is your teammate, the former hitman Yu Q. Wilson, and in the back, the medic hero, Vezalius Bandage."
    "隣には元ヒットマンのチームメイト、ユウ・Q・ウィルソン。\n後部座席にはメディックヒーローのヴェザリウス・バンデージ。"

# game/chapter1.rpy:22
translate japanese chapter_1_5077bc57:

    # vanta_char "Wilson, I gotta say—this road trip was a really good call."
    vanta_char "ウィルソン、この車での旅行は本当にいいアイデアだったな。"

# game/chapter1.rpy:26
translate japanese chapter_1_f6c57937:

    # wilson_char "Right? With the Vezcrewneers on holiday, there's no way we are gonna sit around in an empty office all day."
    wilson_char "でしょ？ヴェズクルーニアーズはみんな休暇中なんだから、僕たちだけが空っぽのオフィスに一日中いるなんてありえないよ。"

# game/chapter1.rpy:31
translate japanese chapter_1_346f36b5:

    # zali_char "Exactly! The sun's out, the timing is perfect—I love a good summer getaway!"
    zali_char "そうそう！太陽は輝いてるし、タイミングも完璧―夏の小旅行って最高だよね！"

# game/chapter1.rpy:36
translate japanese chapter_1_7d9e48cc:

    # "It is a beautiful summer day in Canada. The trees sway gently in the warm breeze, their leaves shimmering under the golden sunlight, casting dappled shadows across the forest. The air carries a faint, earthy scent of pine and wildflowers."
    "ここはカナダの美しい夏の日。\n暖かい風に木々が優しく揺れ、金色の陽光を受けた葉がキラキラと輝く。森にはまだらな影が落ち、大地には松や野花のかすかな香りが漂っている。"

# game/chapter1.rpy:38
translate japanese chapter_1_9472b343:

    # "The three of you belt out lyrics to Super Duper, Wilson tossing out random hypotheticals, and Zali's laughter filling the gaps."
    "3人で『Super Duper』の歌詞を熱唱しながら、ウィルソンが思いつきのもしもの話を投げかけ、合間にはザリの笑い声が響いている。"

# game/chapter1.rpy:40
translate japanese chapter_1_20e188ee:

    # wilson_char "Zali, can you grab me a snack? Vanta, want some water?"
    wilson_char "ザリ、おやつ取ってくれ！ベンタ、水いる？"

# game/chapter1.rpy:42
translate japanese chapter_1_01ea1371:

    # vanta_char "Wilson, I swear to god, eat your snack in one bite. If you leave crumbs everywhere—"
    vanta_char "ウィルソン、頼むから一口で食えよ。お前、また車の中でボロボロこぼしたらー"

# game/chapter1.rpy:44
translate japanese chapter_1_50cb6f5e:

    # zali_char "Haha! Here you go...and here's the water."
    zali_char "ハハハ！はい、どうぞ…それと水もね。"

# game/chapter1.rpy:48
translate japanese chapter_1_fc6b879b:

    # wilson_char "There's a deer up ahead!"
    wilson_char "前方に―鹿がいる！"

# game/chapter1.rpy:58
translate japanese chapter_1_1_8cd855ec:

    # "You see it—a deer. Your reflexes kick in."
    "とっさに反射神経が働く。"

# game/chapter1.rpy:78
translate japanese tutorial_timeout_45079c71:

    # "You brake a moment too late, jolting the car. The deer makes it across safely, but Zali fumbles the bottle, sending water flying straight into Wilson's face."
    "ブレーキが一瞬遅れ、車が大きく揺れる。\n鹿は無事に道路を渡り切るが、ザリがボトルを取り損ね、水がウィルソンの顔に勢いよく飛び散った。"

# game/chapter1.rpy:80
translate japanese tutorial_timeout_12d88a79:

    # wilson_char "Gah! My face! I knew it—I'm not safe even in the passenger seat!"
    wilson_char "うわっ！顔が！わかってたよ…助手席にいたって安全じゃない！"

# game/chapter1.rpy:83
translate japanese tutorial_timeout_5e7d52ce:

    # vanta_char "Sorry about that, bro."
    vanta_char "悪かったよ。"

# game/chapter1.rpy:94
translate japanese tutorial_clear_6be43a09:

    # "You slam the brakes ahead of time, easily avoiding the deer as it darts across the road."
    "突然鹿が道路を横切ったが、あなたは素早くブレーキを踏み込み、難なくそれを避ける。"

# game/chapter1.rpy:96
translate japanese tutorial_clear_584ee927:

    # wilson_char "Nice! Awwn, the deer is sho cyute!"
    wilson_char "ナイス！ わぁ～、鹿めっちゃ可愛い！"

# game/chapter1.rpy:99
translate japanese tutorial_clear_a9f61f8e:

    # zali_char "There, Vanta, your water here."
    zali_char "ほら、ベンタ。君の水だよ。"

# game/chapter1.rpy:102
translate japanese tutorial_clear_c760d7e8:

    # vanta_char "Thanks, Zali!"
    vanta_char "ありがとう、ザリ！"

# game/chapter1.rpy:111
translate japanese chapter_1_2_fd0b80bf:

    # "Towering mountains rise in the distance, a crystal-clear lake sparkles at its center, and cozy cabins nestle along the edges, blending naturally into the serene landscape."
    "遠くにはそびえ立つ山々が広がり、中央には透き通った湖が輝いている。\nその湖のほとりには居心地の良さそうなキャビンが並び、静かな景色に自然と溶け込んでいた。"

# game/chapter1.rpy:114
translate japanese chapter_1_2_5e996afc:

    # wilson_char "Wow! This is so nice! I love a Canadian summer."
    wilson_char "うわぁ、ここ最高じゃん！カナダの夏、大好きだわ。"

# game/chapter1.rpy:117
translate japanese chapter_1_2_84e03dcb:

    # zali_char "Oh yeah! The cabin looks quite big as well. We are lucky to get a cabin this size last minute."
    zali_char "わあ、キャビンも結構大きいね。\nギリギリでこんなサイズのキャビンを取れたのはラッキーだったね。"

# game/chapter1.rpy:121
translate japanese chapter_1_2_4a415756:

    # "You pull up outside the cabin, stepping out into the fresh mountain air. The three of you grab your bags, Wilson striding ahead to the door and pushing it open."
    "あなたたちはキャビンの前に車を停め、澄んだ山の空気を吸い込みながら降り立つ。\n三人はそれぞれ荷物を手に取り、ウィルソンが一足先にドアへと向かい、勢いよく開ける。"

# game/chapter1.rpy:139
translate japanese chapter_1_2_3faa6ffa:

    # vanta_char "Hmm? What's wrong?"
    vanta_char "ん？ どうした？"

# game/chapter1.rpy:140
translate japanese chapter_1_2_3b5b02ce:

    # "You drop the luggage by the door, following Wilson's voice. Your eyes scan the cabin's interior—warm, cozy, and... Oh. One big bed? Really?"
    "あなたとザリは荷物をドアのそばに置き、ウィルソンの声に導かれるようにキャビンの中へ入る。\n目を向けると、室内は暖かくて居心地がよさそうで…え、ベッドがひとつだけ？マジで？"

# game/chapter1.rpy:141
translate japanese chapter_1_2_08461e11:

    # wilson_char "There's...only one bed..."
    wilson_char "…ベッドがひとつしかない…"

# game/chapter1.rpy:144
translate japanese chapter_1_2_4a36edfd:

    # zali_char "Ah, I can sleep on the couch—"
    zali_char "ああ、私はソファで寝るよ―"

# game/chapter1.rpy:147
translate japanese chapter_1_2_7ec0d30f:

    # vanta_char "Nope, not happening. It looks like the bed's big enough for the three of us, though."
    vanta_char "いや、それはないな。でも、このベッドなら三人でも十分寝られそうだ。"

# game/chapter1.rpy:149
translate japanese chapter_1_2_9991f5eb:

    # wilson_char "I call left side!"
    wilson_char "僕、左側な！"

# game/chapter1.rpy:155
translate japanese chapter_1_2_b296198f:

    # vanta_char "Do you have a preference, Zali?"
    vanta_char "ザリ、お前はどこがいい？"

# game/chapter1.rpy:157
translate japanese chapter_1_2_ef65b016:

    # zali_char "No, not really. I can take the spot next to Wilson."
    zali_char "いや、特にこだわりはないからウィルソンの隣でいいよ。"

# game/chapter1.rpy:158
translate japanese chapter_1_2_4b554111:

    # vanta_char "Alright, sure, I will be on the right side."
    vanta_char "よし、じゃあ俺は右側にするか。"

# game/chapter1.rpy:162
translate japanese chapter_1_2_69c01c46:

    # wilson_char "Shall we unpack and find some food before it gets dark?"
    wilson_char "荷解きして、暗くなる前に何か食べ物を探しに行こうか？"

# game/chapter1.rpy:171
translate japanese chapter_1_2_b3e9ff5c:

    # "As you make your way toward the shop, something catches your attention—random piles of timber debris scattered near people's homes. There hasn't been a storm recently, making the sight unusual."
    "店へ向かう途中、ふと目に留まるものがあった。\n民家のそばに、木材の破片がランダムに散らばっているのだ。\n最近は嵐もなかったはずなのに、妙な光景だった。"

# game/chapter1.rpy:174
translate japanese chapter_1_2_6526bcf4:

    # vanta_char "That's weird. What exactly happened here?"
    vanta_char "なんだこれ？一体何があったんだ？"

# game/chapter1.rpy:175
# translate japanese chapter_1_2_61f1b00b:

    # "A group of forest rangers stands outside the grocery store, their conversation growing louder as you approach. A farmer, clearly upset, joins them, gesturing at his broken fence and mentioning strange footprints he found near his farm."
    # "食料品店の前には数人の森林警備隊員が立っており、あなたたちが近づくにつれて会話の声が大きくなっていく。そこへ、明らかに苛立った様子の農夫が加わり、壊された柵のことや、自分の農場の近くで見つけた奇妙な足跡について身振り手振りで訴えている。"

# game/chapter1.rpy:176
translate japanese chapter_1_2_8abb259c:

    # vanta_char "Do you think all this wood and debris has something to do with what they're talking about?"
    vanta_char "この木材や瓦礫って、あの人たちが話してることと関係あるのか？"

# game/chapter1.rpy:180
translate japanese chapter_1_2_9fa6e9f5:

    # wilson_char "What if something happened? Oh... Don't tell me that's why we could book the last cabin on such short notice..."
    wilson_char "何か事件があったのかな？だからあんなに直前でも最後のキャビンが予約できたってこと？"

# game/chapter1.rpy:184
translate japanese chapter_1_2_c7826e0a:

    # zali_char "Hmm... Let's check it out. Maybe there's something we can help with."
    zali_char "ちょっと調べてみよう。もしかしたら手助けできるかもしれない。"

# game/chapter1.rpy:189
translate japanese chapter_1_2_8d2234ca:

    # "You three walk up to the forest rangers and the farmer, introducing yourselves as heroes from A.S.H.—here for a camping trip."
    "三人は森林警備隊員と農家の男のもとへ歩み寄り、A.S.H.のヒーローとして自己紹介する。今回の旅行はあくまでキャンプが目的だが…"

# game/chapter1.rpy:192
translate japanese chapter_1_2_17a5d887:

    # forest_ranger_char "Heroes? Isn't this perfect timing? You guys might be able to help us investigate..."
    forest_ranger_char "ヒーロー？なんて良いタイミングなんだ！\n君たちになら手伝ってもらえるかもしれない…"

# game/chapter1.rpy:194
translate japanese chapter_1_2_55a24edf:

    # zali_char "What happened? Is everything okay?"
    zali_char "何が起きてるんですか？大丈夫なんですか？"

# game/chapter1.rpy:195
translate japanese chapter_1_2_b58471d0:

    # forest_ranger_char "Something—or someone—is going through our village, tearing apart fences and breaking into storage sheds. It's leaving a mess everywhere."
    forest_ranger_char "何かが…あるいは誰かが村の中を荒らし回って、柵を壊したり倉庫に侵入したりしてるんだ。\nそこら中がめちゃくちゃだよ。"

# game/chapter1.rpy:198
translate japanese chapter_1_2_7ed3de24:

    # wilson_char "How long has this been going on? Is this area home to bears or something? But those footprints... Hmm..."
    wilson_char "どれくらい続いてるんです？このあたりに熊とかいるんですか？\nでも、あの足跡…ふむ…"

# game/chapter1.rpy:199
translate japanese chapter_1_2_d07e16c3:

    # forest_ranger_char "These started showing up a few days ago, right after some villagers reported strange noises at night. Whatever made them must have been enormous. I've never seen anything like them."
    forest_ranger_char "これが現れ始めたのは数日前さ。\n村人の何人かが夜中に妙な音を聞いたって報告した直後からな。\nそれを残したものは相当デカかったはずだ。こんな足跡、今まで見たことがない…"

# game/chapter1.rpy:200
translate japanese chapter_1_2_6d9f05ef:

    # "Wilson walks over to one of the massive footprints, crouching to examine it closely. His fingers trace the edges, and his brow furrows as he inspects the depth and the odd contours of its shape."
    "ウィルソンは巨大な足跡のひとつに近づき、しゃがみ込んでじっくり観察する。\n指で輪郭をなぞりながら、その深さと奇妙な形状を確認して眉をひそめた。"

# game/chapter1.rpy:201
translate japanese chapter_1_2_397bed70:

    # wilson_char "I mean... I know it's cliché but... Bigfoot in Canada?"
    wilson_char "いや…ベタな話だけどさ…カナダでビッグフットってことか？"

# game/chapter1.rpy:204
translate japanese chapter_1_2_7b878d61:

    # vanta_char "Hmm... It is interesting indeed. We'll help investigate and see if we can find this...thing."
    vanta_char "ふむ、確かに興味深いな。調査を手伝って、この…何かの正体を突き止めよう。"

# game/chapter1.rpy:207
translate japanese chapter_1_2_fcc47d56:

    # zali_char "We definitely don't want more damage to people's homes. If you notice anything unusual, let us know. Our cabin is just down the road."
    zali_char "これ以上、住民の家に被害が出るのは私たちも望みませんからね。\n何かおかしなことに気づいたら、ぜひ教えてください。\n私たちのキャビンはすぐ近くの道沿いにあります。"

# game/chapter1.rpy:208
translate japanese chapter_1_2_63eee9a8:

    # forest_ranger_char "That would be a huge help! I knew we can always count on the heroes!"
    forest_ranger_char "それは本当に助かるよ！ヒーローたちにはいつも頼りにしてるんだ。"

# game/chapter1.rpy:213
translate japanese chapter_1_2_3cc4193f:

    # farmer_char "Could you guys help me, too?"
    farmer_char "俺にも手を貸してくれないか？"

# game/chapter1.rpy:215
translate japanese chapter_1_2_cb621d33:

    # wilson_char "Sure! What's going on?"
    wilson_char "もちろん！何があった？"

# game/chapter1.rpy:216
translate japanese chapter_1_2_12f45844:

    # farmer_char "Whatever this thing is, it destroyed my fences and scared off my cows—they're all over the place! I'm so worried... There's even a calf missing!"
    farmer_char "何かに柵を壊されて、牛たちが怖がって逃げちまったんだ！\nあちこちに散らばっちまって…しかも子牛が一頭、行方不明なんだ！"

# game/chapter1.rpy:218
translate japanese chapter_1_2_6d7b800e:

    # wilson_char "Animals in distress? Of course I'll help. I, for one, know cows very well. Mooing is kind of my specialty."
    wilson_char "動物が困ってる？もちろん手伝うよ。僕、牛のことなら詳しいんだ。\nモーモー言うのは、ある意味専門分野だからな。"

# game/chapter1.rpy:219
translate japanese chapter_1_2_15ef97a7:

    # farmer_char "Oh really? Bless you, my boy! Come with me!"
    farmer_char "おお、本当か！？感謝するよ、坊や！さあ、こっちへ！"

# game/chapter1.rpy:222
translate japanese chapter_1_2_9659012f:

    # zali_char "Alright, guys, how about this? I'll grab the ingredients and head back to camp. If I see anything suspicious, I'll let you know."
    zali_char "よし、みんな、こうしよう。\n私が食材を買ってキャンプに戻る。何か怪しいものを見かけたら、すぐに知らせるよ。"

# game/chapter1.rpy:224
translate japanese chapter_1_2_fe236532:

    # wilson_char "Sounds good! I'll go find the cows with this guy."
    wilson_char "了解！僕はこの人と一緒に牛を探してくる。"

# game/chapter1.rpy:243
translate japanese chapter_1_2_72b42f5a:

    # "You decide to help Wilson find the cows. But before you can say anything, the farmer reaches into his back pocket and pulls out a comically large pair of cow costumes."
    "ウィルソンと一緒に牛を探すことに決めた。\nだが、その決意を口にする前に、農家の男がズボンの後ろポケットに手を突っ込み、妙にデカい牛の着ぐるみを取り出した。"

# game/chapter1.rpy:246
translate japanese chapter_1_2_84da4eaf:

    # vanta_char "Wh— Do you just have those on hand?"
    vanta_char "なっ…えっ、それ普通に持ち歩いてるのか！？"

# game/chapter1.rpy:249
translate japanese chapter_1_2_3d97b8e6:

    # farmer_char "Of course! You never know when you'll need a good cow disguise."
    farmer_char "もちろんさ！いつ良い牛の変装が必要になるかわからないからね。"

# game/chapter1.rpy:250
translate japanese chapter_1_2_71dfae6e:

    # farmer_char "Anyway, thank you so much, boys. Oh, and while you're at it, you wouldn't mind taking a few special commemorative photos for me, would you? You know, for branding purposes."
    farmer_char "とにかく、本当にありがとう。\nああ、それとついでに、特別な記念写真を何枚か撮らせてもらえないか？\nブランドの宣伝用なんだよ。"

# game/chapter1.rpy:253
translate japanese chapter_1_2_f321b96b:

    # wilson_char "I mean... Sure! Why not! Right, Vanta?"
    wilson_char "まあ…いいんじゃない？別に問題ないだろ！なあ、ベンタ？"

# game/chapter1.rpy:257
translate japanese chapter_1_2_89703e32:

    # "You have a very bad feeling about this."
    "とても嫌な予感がする。"

# game/chapter1.rpy:260
translate japanese chapter_1_2_06ad5655:

    # wilson_char "We get to be cowboys?! Awesome!"
    wilson_char "僕たち、カウボーイになれるの？！最高じゃん！"

# game/chapter1.rpy:261
translate japanese chapter_1_2_c8347f24:

    # wilson_char "Come on Vanta, put on the suit! Oh man, I need to practice my moos."
    wilson_char "さあベンタ、着ぐるみを着て！あぁ、ちゃんとモーモー鳴く練習もしなきゃ。"

# game/chapter1.rpy:263
translate japanese chapter_1_2_56dac3dd:

    # vanta_char "Oh my god... You're just gonna go with it?! No questions asked?!"
    vanta_char "お前、何の疑問も持たずに受け入れるのか？！"

# game/chapter1.rpy:264
translate japanese chapter_1_2_968db1e7:

    # wilson_char "What's there to ask? We get to become cowboys and save this poor farmer's cows, too!"
    wilson_char "聞くまでもないだろ？僕たちはカウボーイになれるし、このかわいそうな農夫の牛も助けられるんだぞ！"

# game/chapter1.rpy:267
translate japanese chapter_1_2_80ce8262:

    # farmer_char "It's really quite effective, these things! Why? I'd wear them myself, but I hurt my knees yesterday and can't exactly get on all fours today."
    farmer_char "これがまた結構効果的なんだよ！なぜかって？\n俺も着たいところだけど、昨日膝を痛めちまってな。今日は四つん這いになるのは無理なんだよ。"

# game/chapter1.rpy:270
translate japanese chapter_1_2_50d0097f:

    # vanta_char "What do you mean on all fours?! I should've just gone with Zali..."
    vanta_char "四つん這いってどういう意味だよ！？くそ、ザリについて行けばよかった…"

# game/chapter1.rpy:274
translate japanese chapter_1_2_acd36d5a:

    # "Soon, the both of you return to the field in your new ultimate calf herding outfit. The farmer has set up a camera some distance away. He gives you both an eager thumbs up."
    "しばらくして、あなたたち二人は『究極の子牛追い込みスタイル』に身を包み、再び牧草地へ戻る。農夫は少し離れた場所にカメラを設置しており、二人に嬉しそうに親指を立てて合図を送ってくる。"

# game/chapter1.rpy:278
translate japanese chapter_1_2_c2c708b6:

    # wilson_char "Should I go like: MooOOo~? Or more like: MOOooo!"
    wilson_char "僕、こうやって鳴いたほうがいいかな？モォ～って感じ？\nそれとも、モー！のほうがいい？"

# game/chapter1.rpy:280
translate japanese chapter_1_2_450de447:

    # wilson_char "Arghhh! Come on, Wilson. Think like a cow!"
    wilson_char "くそっ…ウィルソン、もっと牛になりきれ！"

# game/chapter1.rpy:281
translate japanese chapter_1_2_a356482d:

    # "You watch in amazement as Wilson, truly and spectacularly without dignity, commits fully to his new bovine role."
    "あなたは呆気にとられながら見つめる。\nウィルソンが、完全にプライドを捨て去り、牛役になりきっているその姿を。"

# game/chapter1.rpy:285
translate japanese chapter_1_2_a0f3d027:

    # vanta_char "Are you...practicing your moos?"
    vanta_char "お前…モーモー鳴く練習してるのか？"

# game/chapter1.rpy:286
translate japanese chapter_1_2_da5b0796:

    # wilson_char "We have to sell it, Vanta. What kind of cow's gonna fall for your weak ass moo? Draw from the diaphragm, Vanta."
    wilson_char "ちゃんと演じきらないとダメだ、ベンタ。\nお前のショボいモーモーじゃ、どんな牛も引っかからないよ。腹から声を出せ、ベンタ！"

# game/chapter1.rpy:288
translate japanese chapter_1_2_8fd6702d:

    # vanta_char "Mooing in a cowboy costume is not on my bucket list for this year...but I've stopped questioning my life choices."
    vanta_char "カウボーイのコスチュームでモーモー鳴くのは、今年のやりたいことリストには入ってないんだが…まぁ、やるしかないか…"

# game/chapter1.rpy:290
translate japanese chapter_1_2_e68299d4:

    # "You wonder if Zali is having a quieter, less humiliating time with groceries."
    "あなたはふと、ザリが食料の買い出しをしながら、これよりも静かで屈辱の少ない時間を過ごしているのではないかと考える。"

# game/chapter1.rpy:295
translate japanese chapter_1_2_8895917d:

    # "The both of you get on all fours and begin mooing, trying to attract the calf back with your sounds. The farmer occasionally gives you both an enthusiastic thumbs up, taking photos of you the whole time."
    "二人は四つん這いになり、子牛を引き寄せようと必死にモーモー鳴き始めた。\n農夫は時々大きく親指を立て、満面の笑みで写真を撮り続けている。"

# game/chapter1.rpy:296
translate japanese chapter_1_2_5e869f83:

    # vanta_char "Wilson. This is absolutely the dumbest thing we've ever done.\nNothing—and I mean nothing—will ever be more stupid than this."
    vanta_char "ウィルソン。これは間違いなく、俺たちが今までやってきた中で一番バカなことだ。\n何も―本当に何も―これ以上にアホなことはない。"

# game/chapter1.rpy:298
translate japanese chapter_1_2_48e5d462:

    # "Wilson starts mooing maternally. You don't react."
    "ウィルソンが母牛のように優しくモーモー鳴き始める。\nあなたは無反応のまま。"

# game/chapter1.rpy:299
translate japanese chapter_1_2_83caaa14:

    # wilson_char "Come on, Vanta. That was your cue!"
    wilson_char "おい、ベンタ！今のお前の番だっただろ！"

# game/chapter1.rpy:300
translate japanese chapter_1_2_06eae0d1:

    # vanta_char "This is so stupid..."
    vanta_char "マジでくだらねぇ…"

# game/chapter1.rpy:301
translate japanese chapter_1_2_e93564a7:

    # wilson_char "Don't break RP!"
    wilson_char "ロールプレイを壊すな！"

# game/chapter1.rpy:303
translate japanese chapter_1_2_a8457830:

    # "You moo half-heartedly."
    "あなたは仕方なく、やる気のない一声でモーと鳴く。"

# game/chapter1.rpy:304
translate japanese chapter_1_2_099fec82:

    # wilson_char "Moo louder! You're a concerned father! Never give up, never what?"
    wilson_char "もっと大きく鳴け！お前は無責任な親父じゃなくて、子を心配する父親だろう！"

# game/chapter1.rpy:305
translate japanese chapter_1_2_94aa6786:

    # vanta_char "Oh my god... I don't even know what that sounds like!"
    vanta_char "そんな鳴き方、俺には分からねぇよ！"

# game/chapter1.rpy:306
translate japanese chapter_1_2_bbaac225:

    # wilson_char "You just have to immerse yourself in the character. Come on, try again."
    wilson_char "キャラに入り込むだけでいいんだ。ほら、もう一回やってみな。"

# game/chapter1.rpy:312
translate japanese chapter_1_2_67e06060:

    # "You moo again, channeling your inner alpha cow, if that's even a thing. Wilson nods enthusiastically, joining in with his motherly moos."
    "あなたは再びモーと鳴く。\nもし「荒くれ牛」なんてものがいるとすれば、そんな感じの鳴き方だろう。\nウィルソンは満足げにうなずき、母牛のような優しいモーモーを重ねる。"

# game/chapter1.rpy:313
translate japanese chapter_1_2_26207232:

    # "Rapid camera flashes go off in the distance. But before the shame can sink in, you spot a small brown calf poking its head out from a bush."
    "遠くでカメラのフラッシュが連続して光る。\nしかし、恥ずかしさが襲ってくる前に、あなたは茂みの中から小さな茶色の子牛がひょっこり顔を出しているのに気が付いた。"

# game/chapter1.rpy:315
translate japanese chapter_1_2_02f8562f:

    # "The calf moos shyly. Wilson lights up in excitement."
    "子牛は恥ずかしそうにモーと鳴く。ウィルソンの目が輝く。"

# game/chapter1.rpy:316
translate japanese chapter_1_2_947e77a7:

    # wilson_char "Moo! My son is back!"
    wilson_char "モー！僕の息子が帰ってきた！"

# game/chapter1.rpy:318
translate japanese chapter_1_2_2b4f86a5:

    # vanta_char "What do you mean your son? He clearly came out because of my moo!"
    vanta_char "は？お前の息子？明らかに俺のモーで出てきただろ！"

# game/chapter1.rpy:320
translate japanese chapter_1_2_79aced30:

    # wilson_char "Nah. He's my son. I carried him for nine months."
    wilson_char "いや、この子は僕の息子だ。僕が九ヶ月かけて育てたんだからな。"

# game/chapter1.rpy:321
translate japanese chapter_1_2_eb13cb1b:

    # vanta_char "You—"
    vanta_char "お前ー"

# game/chapter1.rpy:327
translate japanese chapter_1_2_6e7cb5ca:

    # farmer_char "Well, I'll be damned, I didn't think you'd be so good at this cowboys business. Ever thought about ranching?"
    farmer_char "いやぁ、まさかこんなに牛追いが上手いとは思わなかったよ。牧場経営に興味はないか？"

# game/chapter1.rpy:329
translate japanese chapter_1_2_4986aa88:

    # wilson_char "You know, I could see myself as a cowboy. Just a simple life, mooing at sunset and grazing in the fields... That's what cowboys do, right?"
    wilson_char "そうだなぁ…僕、カウボーイになれるかもしれない。\n夕陽の下でモーモー鳴いて、広い草原でのんびり草を食む…それがカウボーイの生き様ってやつだろ？"

# game/chapter1.rpy:332
translate japanese chapter_1_2_3266b9b2:

    # vanta_char "I'm starting to think you actually don't know what a cowboy is."
    vanta_char "お前、それカウボーイの意味分かってないだろ。"

# game/chapter1.rpy:335
translate japanese chapter_1_2_8e613f9f:

    # wilson_char "What do you mean, Vanta? You don't wanna be my cow husband?"
    wilson_char "どういうことだよ、ベンタ？僕と一緒にカウ夫婦になりたくないのか？"

# game/chapter1.rpy:338
translate japanese chapter_1_2_5025d1c7:

    # "As the farmer thanks you both profusely and leads the calf back to its pen, you and Wilson finally peel off the absurd costumes."
    "農夫は感謝の言葉を何度も繰り返しながら、子牛を小屋へと連れて戻っていく。\nその間に、あなたとウィルソンはようやくこのバカげた着ぐるみを脱ぎ捨てる。"

# game/chapter1.rpy:343
translate japanese chapter_1_2_ede955f9:

    # "As the sun dips lower, warm hues paint the surroundings, and the inviting aroma of food drifts through the air, pulling you toward the promise of dinner. Whatever Zali's been cooking must be amazing. You quicken your pace to meet him."
    "太陽はさらに傾き、あたりを温かみのある色彩で包み込む。\nそして、食事の香ばしい匂いが空気に漂い、三人を夕食の待つ食卓へと誘う。\nザリが作っている料理は、きっととんでもなく美味しいに違いない。足早に歩みを進め、ザリの元へ急いだ。"

# game/chapter1.rpy:353
translate japanese chapter_1_2_1a588cf0:

    # "Entering the cute local supermarket, you browse the shelves, grabbing ingredients.\nEggs, flour, sausages, tomatoes, spinach...and of course—a baguette. It's not a Krisis campsite dinner without a French classic."
    "可愛らしい地元のスーパーに入り、棚を見て回りながら食材を手に取る。\n卵、小麦粉、ソーセージ、トマト、ほうれん草…そしてもちろん、バゲット。\nフランスの伝統料理なしではクライシスのキャンプ飯とは言えない。"

# game/chapter1.rpy:356
translate japanese chapter_1_2_71fc0b34:

    # zali_char "Alright, I think these should be enough..."
    zali_char "よし、これで十分かな…"

# game/chapter1.rpy:361
translate japanese chapter_1_2_4403fbb7:

    # "Back at the cabin, you and Zali start prepping. Vegetables are laid out, and you're already elbow-deep in washing them."
    "キャビンに戻ると、あなたとザリは準備を始める。\n野菜が並べられ、あなたはすでに腕まくりして夢中で洗っているところだ。"

# game/chapter1.rpy:365
translate japanese chapter_1_2_9fe2d065:

    # zali_char "Vanta, I have aprons here. Let me put one on for you. Hold still, don't move."
    zali_char "ベンタ、エプロンがあるよ。つけてあげるからじっとして。動かないで。"

# game/chapter1.rpy:367
translate japanese chapter_1_2_3c242ff0:

    # vanta_char "You're really enjoying this, huh? Tying knots and whatnot."
    vanta_char "楽しんでるな？結び目とか、やけにこだわってないか？"

# game/chapter1.rpy:373
translate japanese chapter_1_2_4b072108:

    # "His voice is steady, calm, matching the ease of his actions, and for a moment, the sounds of the camp fade into the background."
    "落ち着いた声と流れるような手つきが妙に合っていて、その瞬間、キャンプの音が遠のいた気がする。"

# game/chapter1.rpy:375
translate japanese chapter_1_2_0b74c4f5:

    # "You find yourself watching him, momentarily thrown off by the quiet confidence he carries. Honestly, he's a little too good at this—should you be concerned about how often he practices tying knots?"
    "あなたはつい彼を見つめてしまう。\nその静かな自信に、一瞬、意識が逸れる。いや、ちょっと上手すぎないか…？\n結び方の練習でもしてるのか？"

# game/chapter1.rpy:381
translate japanese chapter_1_2_a46c666a:

    # "You shake off the thought and refocus on the task at hand."
    "その考えを振り払い、目の前の作業に集中する。"

# game/chapter1.rpy:383
translate japanese chapter_1_2_ff7bf797:

    # zali_char "I'll cut the sausages. Let's make spinach, tomato baked eggs with sausages."
    zali_char "ソーセージ切るよ。ほうれん草とトマトのベイクドエッグ、ソーセージ付きでいこう。"

# game/chapter1.rpy:385
translate japanese chapter_1_2_f324e755:

    # vanta_char "Oooo....さすが the sausage guy... I'm excited for this."
    vanta_char "おおぉ…さすがソーセージ担当…これは期待できるな。"

# game/chapter1.rpy:387
translate japanese chapter_1_2_fe514b6b:

    # "The two of you fall into a rhythm that would put a cooking show to shame. The campfire crackles warmly, ingredients are prepped, and dinner simmers, filling the air with a mouthwatering aroma."
    "二人の手際はまるで料理番組のよう。\n焚き火がパチパチと心地よい音を立て、食材が整い、料理が煮込まれ、空気には食欲をそそる香りが広がる。"

# game/chapter1.rpy:390
translate japanese chapter_1_2_6f8b4ae5:

    # vanta_char "Mmm mmm MMM! Smells like a masterpiece in the making."
    vanta_char "う～ん…うん！これは傑作の予感がするな。"

# game/chapter1.rpy:391
translate japanese chapter_1_2_fc9bcae6:

    # "You glance up and spot a streak of flour smudged across Zali's chest."
    "ふと顔を上げると、ザリの胸元に白い粉がべったりついているのが目に入る。"

# game/chapter1.rpy:394
translate japanese chapter_1_2_1a38acfb:

    # vanta_char "Oi, Zali. You planning to serve yourself as a dessert, too? You've got flour all over you."
    vanta_char "おい、ザリ。自分をデザートにする気か？粉まみれだぞ。"

# game/chapter1.rpy:395
translate japanese chapter_1_2_74c3c208:

    # "Zali looks down, patting his chest absently."
    "ザリは胸元を見下ろし、軽く手で払う。"

# game/chapter1.rpy:401
translate japanese chapter_1_2_10d6c90c:

    # zali_char "I guess you found the secret menu. I can be your dessert if you want."
    zali_char "ふふ、隠しメニューを見つけちゃったね。デザートになってもいいけど？"

# game/chapter1.rpy:403
translate japanese chapter_1_2_ffae8a5c:

    # vanta_char "Here, let me—"
    vanta_char "ほら、じっとして…"

# game/chapter1.rpy:404
translate japanese chapter_1_2_8351482e:

    # "You grab a towel, stepping closer."
    "あなたはタオルを手に取り、一歩近づく。"

# game/chapter1.rpy:406
translate japanese chapter_1_2_b081bd1b:

    # "You and Zali continue making dinner, the aroma wafting through the air, carried by a gentle breeze, mingling with the crackling firewood."
    "二人は引き続き夕食の準備を進める。\n焚き火の煙と食欲をそそる香りが、そよ風に乗って広がっていく。"

# game/chapter1.rpy:412
translate japanese chapter_1_2_654dd510:

    # vanta_char "Ahh...! The wind! There's sand in my eyes."
    vanta_char "うわっ…！風が…目に砂が入った！"

# game/chapter1.rpy:413
translate japanese chapter_1_2_23797418:

    # "You blink rapidly and turn your head away as the breeze carries a fine grit of dust across your face."
    "あなたは瞬きを繰り返しながら、顔を背けた。しかし、風が舞い上げた砂ぼこりが視界を曇らせる。"

# game/chapter1.rpy:415
translate japanese chapter_1_2_02bd269a:

    # "Zali drops everything and strides over, his expression concerned as he leans in."
    "ザリはすぐさま手を止め、心配そうに歩み寄る。"

# game/chapter1.rpy:423
translate japanese chapter_1_2_798155fe:

    # zali_char "Let me have a look..."
    zali_char "見せて…"

# game/chapter1.rpy:424
translate japanese chapter_1_2_dd0e7003:

    # "The distance between the two of you shrinks dramatically. Your faces are unnecessarily close, the warmth of his breath brushing your skin."
    "距離がぐっと縮まる。顔が無駄に近い。彼の息遣いすら肌に感じるほど。"

# game/chapter1.rpy:425
translate japanese chapter_1_2_8144832b:

    # "His hand hovers near your face, his fingers hesitating like they're caught between instinct and restraint."
    "手が顔の前で一瞬止まり、本能的な動きとためらいの間で揺れているようだ。"

# game/chapter1.rpy:426
translate japanese chapter_1_2_af53c8a3:

    # "The moment stretches, fragile and electric, like the world itself is holding its breath, waiting to see who will move first."
    "その瞬間、世界が息をのんだように静まりかえる。\nどちらが先に動くのか、まるで試されているみたいに。"

# game/chapter1.rpy:435
translate japanese chapter_1_2_30461e62:

    # wilson_char "I'm back. Wow, whatever you guys are cooking smells so—WAIT. What are you doing?\nOh my god, I was helping a farmer find his cows and you two are here kissing?"
    wilson_char "戻ったよ！わぁ、良い匂い…って、ちょっと待て、何してんだ！？\nおいおい、僕が農家の手伝いで牛を探してる間に、お前らここでキスしてたのか！？"

# game/chapter1.rpy:436
translate japanese chapter_1_2_86cc6989:

    # "Wilson's voice shatters the moment like a bucket of cold water. Perfect—or horrible—timing, really."
    "ウィルソンの声が、冷や水でもかけたかのようにその空気をぶち壊す。\nタイミングが良すぎる…いや、悪すぎる。"

# game/chapter1.rpy:439
translate japanese chapter_1_2_4f36965f:

    # vanta_char "W—What?"
    vanta_char "は、ハァ！？"

# game/chapter1.rpy:440
translate japanese chapter_1_2_6a09b508:

    # vanta_char "It's sand! I just... I got sand in my eyes, okay?"
    vanta_char "違う、砂だ！ただの砂！目に入っただけだから！！"

# game/chapter1.rpy:442
translate japanese chapter_1_2_21a6d4fa:

    # wilson_char "Right, whatever you say, man. Kissing without me? Unforgivable..."
    wilson_char "…はいはい、そういうことにしとくよ。\n僕抜きでキスとか、許せないな…"

# game/chapter1.rpy:443
translate japanese chapter_1_2_271efdbb:

    # "Wilson crosses his arms, throwing a mock glare at you."
    "ウィルソンは腕を組み、ふざけた視線を向けてくる。"

# game/chapter1.rpy:444
translate japanese chapter_1_2_58649743:

    # "The sun dips lower as the three of you reunite at the campsite, laughter echoing through the golden light filtering between the trees. The inviting aroma of food fills the air, drawing you all toward the promise of dinner."
    "太陽が沈み始め、金色の光が木々の間を照らす中、キャンプサイトには笑い声が響く。\n食欲をそそる料理の香りに誘われ、三人は夕食の時間へと引き込まれていった。"

# game/chapter1.rpy:457
translate japanese chapter_1_3_3774232c:

    # "After dinner, the three of you gather around the campfire. The flickering flames cast a warm glow, warding off the evening chill."
    "夕食の後、三人は焚き火の周りに集まった。\n揺れる炎が暖かな光を放ち、夜の冷え込みを和らげてくれる。"

# game/chapter1.rpy:461
translate japanese chapter_1_3_7f3d36a2:

    # "You pull out a bag of marshmallows, smiling as you pass them around with roasting sticks. Moments like this call for a classic treat—roasted marshmallows under the open sky."
    "あなたはマシュマロの袋を取り出し、微笑みながら串と一緒にみんなへと配る。\nこういう時間には、やっぱり焚き火で焼くマシュマロが欠かせない。"

# game/chapter1.rpy:473
translate japanese chapter_1_3_80a28568:

    # zali_char "Goodness! This is giga fire! Yes, I can have five more."
    zali_char "わぁぁ！これ最高すぎる！あと五つは余裕でいけるよ。"

# game/chapter1.rpy:474
translate japanese chapter_1_3_35d06080:

    # vanta_char "Ahh! It's been a while since we've relaxed like this, just enjoying the moment."
    vanta_char "はあ〜、こんなふうにのんびりできたの、久しぶりだな。"

# game/chapter1.rpy:475
translate japanese chapter_1_3_33004051:

    # zali_char "Gosh! Yeah, you're right!"
    zali_char "ほんとだね！"

# game/chapter1.rpy:480
translate japanese chapter_1_3_065002bc:

    # zali_char "Yeah, it's really peaceful here. The fire, the sky, and the stars...it's a kind of calm you don't find anywhere else."
    zali_char "うん、ここは本当に落ち着くね。\n焚き火の音、広がる空、輝く星…こういう穏やかさは、他ではなかなか味わえないよ。"

# game/chapter1.rpy:481
translate japanese chapter_1_3_09b9fa27:

    # "You take a deep breath, the faint sweetness of roasted marshmallows filling your senses."
    "あなたは深く息を吸い込み、焼きマシュマロのほのかな甘い香りを感じる。"

# game/chapter1.rpy:486
translate japanese chapter_1_3_a04e0740:

    # "It's been a while since you've had a moment like this—relaxed, unhurried, and shared with those who matter most."
    "こんな風に、のんびりと、心からリラックスして、大切な仲間と過ごすのは久しぶりだ。"

# game/chapter1.rpy:487
translate japanese chapter_1_3_639b7747:

    # "You have your friends by your side, who (arguably) know you better than most other people. Actually, not just friends—your found family, within arm's reach."
    "あなたの隣には、誰よりも君を理解している（かもしれない）仲間たちがいる。\nいや、仲間なんてものじゃない。すぐそばにいる、君が見つけた家族そのものだ。"

# game/chapter1.rpy:488
translate japanese chapter_1_3_a102d844:

    # "This kind of moment makes you smile and appreciate the choices that brought you here. It's a reminder that life's best joys are often found in the simplest things."
    "こんな時間があるからこそ、ここへ来るまでの選択が間違っていなかったと実感できる。\n人生の最高の喜びは、案外こんな些細なところにあるものだ。"

# game/chapter1.rpy:489
translate japanese chapter_1_3_2b2f86fd:

    # vanta_char "We hardly ever get a break, now that I think about it. Even the last time we had a vacation, we were still working our asses off."
    vanta_char "改めて考えると、俺たちってほとんど休んでないよな。\n前に休暇を取ったときでさえ、結局死ぬほど働いてたし。"

# game/chapter1.rpy:490
translate japanese chapter_1_3_332684c3:

    # wilson_char "I mean, there's always danger around every corner. Even where we sit, anything can happen. Evil never takes a break, so we shouldn't either."
    wilson_char "まあ、どこにだって危険は潜んでるからね。\n今こうして座ってるこの場所ですら、何が起こるかわからない。\n悪は休まない—だから、俺たちも気を抜いちゃいけないんだ。"

# game/chapter1.rpy:491
translate japanese chapter_1_3_4defb7ff:

    # zali_char "That may be true...which is why we should enjoy moments like this while we can!"
    zali_char "それはそうかもしれない…だからこそ、こういう瞬間を楽しめるうちに楽しむべきだよね！"

# game/chapter1.rpy:492
translate japanese chapter_1_3_42916347:

    # wilson_char "You're right, Zali."
    wilson_char "ザリ、お前の言うとおりだよ。"

# game/chapter1.rpy:493
translate japanese chapter_1_3_3b59bdc4:

    # "You three enjoy your roasted marshmallows while engaging in a much-needed mental check in with each other."
    "三人は焼きマシュマロを楽しみながら、お互いを労る時間を過ごす。"

# game/chapter1.rpy:497
translate japanese chapter_1_3_4285dba7:

    # wilson_char "I love you guys, genuinely."
    wilson_char "お前らのこと、本当に大好きだよ。"

# game/chapter1.rpy:499
translate japanese chapter_1_3_f8630d0a:

    # zali_char "Awwnn, I love you too!"
    zali_char "えぇ～？私も大好きだよ！"

# game/chapter1.rpy:505
translate japanese chapter_1_3_e248c8f5:

    # wilson_char "You know what, never mind! Zali, I love YOU!"
    wilson_char "あー！もうどうでもいい！ザリ、お前が大好きだ！"

# game/chapter1.rpy:506
translate japanese chapter_1_3_41bc4bda:

    # zali_char "D'aww, stahp it~!"
    zali_char "やだ〜、やめてよ〜！"

# game/chapter1.rpy:508
translate japanese chapter_1_3_3edfc7ae:

    # vanta_char "Damn, I'm sorry! I love you too, man."
    vanta_char "くそ、悪かったよ！俺もお前のこと好きだよ！"

# game/chapter1.rpy:515
translate japanese chapter_1_3_299547a7:

    # "After some light banter, you clean up the leftovers and set them aside. With the fire dying down, you head back into the cabin to prepare for the night."
    "軽い冗談を交わした後、三人で残りの食事を片付け、火が消えかけるのを見届けながらキャビンへ戻り、夜の準備をする。"

# game/chapter1.rpy:519
translate japanese chapter_1_3_898f4cfa:

    # "Night falls. The shared bed creaks slightly as the three of you sleep soundly. Suddenly, a loud noise breaks the silence—rustling leaves, guttural growls, and the heavy crash of something being overturned."
    "夜が更ける。三人で使っているベッドがかすかに軋みながら、穏やかな眠りにつく。\nしかし、その静寂を破るように突如として大きな音が響く—葉擦れの音、低く唸るような唸り声、そして何かが重く倒れる音。"

# game/chapter1.rpy:522
translate japanese chapter_1_3_42413e2b:

    # wilson_char "Hmm...?"
    wilson_char "んん…？"

# game/chapter1.rpy:525
translate japanese chapter_1_3_12e50729:

    # vanta_char "Hmm... Wilson stop moving... You're hogging the blanket."
    vanta_char "ん…ウィルソン、動くなって…毛布独り占めすんなよ…"

# game/chapter1.rpy:528
translate japanese chapter_1_3_7656cb67:

    # zali_char "Huh? Wait, guys, guys. I think something is out there..."
    zali_char "え？ちょっと待って、二人とも。なんか外にいる気がする…"

# game/chapter1.rpy:530
translate japanese chapter_1_3_3bc748f5:

    # "Zali sits up, his sharp instincts catching the unusual sounds outside. He glances towards the window. Who would be hanging outside of their camp at this godforsaken hour?"
    "ザリはすぐに起き上がり、鋭い勘で外の異様な音を捉えた。\n窓の方に目を向ける。こんな時間に誰がキャンプ場の外をうろつくっていうんだ…？"

# game/chapter1.rpy:533
translate japanese chapter_1_3_350666ce:

    # "Your breath catches in your throat as your eyes adjust to the darkness. There, near the dying embers of the campfire, looms a massive shadow. The Bigfoot—or what you are convinced is Bigfoot—is rummaging through the leftover food."
    "目が暗闇に慣れてくると同時に、あなたは息をのむ。\n消えかけた焚き火のそばに、巨大な影が立っている。それは—ビッグフット、もしくはあなたがそう確信してしまう何かが、残った食料を漁っている。"

# game/chapter1.rpy:534
translate japanese chapter_1_3_de0d92c1:

    # "It stands tall—too tall. Seven feet, maybe more. And it's covered in thick, matted hair."
    "その体躯は尋常じゃない—大きすぎる。おそらく2メートルか、それ以上。全身がゴワゴワとした濃い体毛に覆われている。"

# game/chapter1.rpy:537
translate japanese chapter_1_3_5741d10a:

    # vanta_char "Yes, well. Looks like Bigfoot traveled here just to crash our glamping trip."
    vanta_char "そうだな…どうやらビッグフットは、わざわざ俺たちの贅沢キャンプをぶち壊しに来たらしい。"

# game/chapter1.rpy:538
translate japanese chapter_1_3_ddc423ad:

    # "Despite the sarcasm in your tone, you can't help but feel uneasy. Looking at the size and shape of whatever this thing is, it's like nothing you've ever seen before."
    "あなたの声には皮肉が混じっているものの、不安を拭いきれない。\nあのサイズ、あの形状…どんな生物なのか見当もつかないが、これまで見たことのない何かであることは確かだ。"

# game/chapter1.rpy:539
translate japanese chapter_1_3_5aae8247:

    # "Wilson is now awake, rubbing the sleep from his eyes. He looks at you both, still groggy."
    "ウィルソンも目を覚まし、眠そうに目をこすりながらあなたたちを見る。"

# game/chapter1.rpy:541
translate japanese chapter_1_3_1b67ff8d:

    # wilson_char "Guys... What's so important that we're breaking up the homie sleep?"
    wilson_char "おいみんな…そんなに大事なことって何だよ、仲間との安眠タイムを邪魔してまでさ。"

# game/chapter1.rpy:542
translate japanese chapter_1_3_8aa6e9ce:

    # zali_char "Wilson... It's Bigfoot. I think."
    zali_char "ウィルソン…ビッグフットだと思う。"

# game/chapter1.rpy:543
translate japanese chapter_1_3_276732d1:

    # "You pull away from the window, turning to Zali and Wilson."
    "あなたは窓から視線を外し、ザリとウィルソンの方を向く。"

# game/chapter1.rpy:546
translate japanese chapter_1_3_9a7a164a:

    # vanta_char "Alright. Let's grab something. Duty calls."
    vanta_char "よし、何か武器になりそうなものを持て。任務開始だ。"

# game/chapter1.rpy:557
translate japanese chapter_1_3_bbfe9f5c:

    # vanta_char "LMAO. I guess this is what we've got."
    vanta_char "ウケる、これしかないのかよ。"

# game/chapter1.rpy:558
translate japanese chapter_1_3_3a3c11ff:

    # "As the tank of the group, you take the lead, stepping in front of Zali and Wilson. You put your hand on the doorknob, take a deep breath, and open the door."
    "チームのタンクであるあなたが先頭に立ち、ザリとウィルソンを背後にかばう。\nドアノブに手をかけ、深く息を吸い、意を決してドアを開ける。"

# game/chapter1.rpy:571
translate japanese chapter_1_example_qte_debug_b11d77e1:

    # "Your eyes meet Bigfoot's."
    "あなたの視線とビッグフットの視線がぶつかる。"

# game/chapter1.rpy:573
translate japanese chapter_1_example_qte_debug_cdf3977e:

    # "The creature lets out a loud growl, its massive form tensing before it charges straight at the three of you."
    "その巨大な体が緊張し、大きく唸り声を上げると同時に、三人に向かって突進してくる。"

# game/chapter1.rpy:574
translate japanese chapter_1_example_qte_debug_3fbebf56:

    # "Waking up in the middle of the night and fight a giant monster? Say less!"
    "夜中に起こされて、いきなり巨大な怪物とバトル？言われなくてもやってやる。"

# game/chapter1.rpy:603
translate japanese chapter_1_example_clear_b3fb0fbc:

    # "You all leap just in time, your excellent reflexes saving you from the charging creature."
    "ギリギリのタイミングで全員が跳びのき、優れた反射神経のおかげで突進してくる怪物を回避する。"

# game/chapter1.rpy:613
translate japanese chapter_1_example_timeout_a33c4710:

    # "You don't jump quickly enough, and Bigfoot's massive punch lands squarely on your chest."
    "素早く跳べず、ビッグフットの巨大な拳がまともに胸にめり込む。"

# game/chapter1.rpy:614
translate japanese chapter_1_example_timeout_f1a7527c:

    # vanta_char "URGHHH!! That...hurt..."
    vanta_char "うぐっ！！ い…痛ぇ…"

# game/chapter1.rpy:615
translate japanese chapter_1_example_timeout_605e1d82:

    # "But as the Ace and Tyrant of Krisis, you shake it off—it'll take more than that to faze you."
    "だが、クライシスのエースであり暴君であるあなたが、こんなもので怯むわけがない。\n痛みを振り払い、立ち上がる。こんなことでは倒れない。"

# game/chapter1.rpy:625
translate japanese chapter_1_wilson_qte_9fe6d43b:

    # "Bigfoot turns its gaze towards Wilson, its eyes full of rage. It charges towards Wilson."
    "ビッグフットの視線がウィルソンに向けられた。\nその目は怒りが満ちている。次の瞬間、ウィルソン目掛けて突進してきた。"

# game/chapter1.rpy:626
translate japanese chapter_1_wilson_qte_001f883f:

    # "Facing Bigfoot barreling towards him, the former hitman decides to—"
    "猛スピードでビッグフットが迫る中、元ヒットマンの彼は—。"

# game/chapter1.rpy:646
translate japanese chapter_1_wilson_timeout_b9d07d61:

    # "Wilson freezes, unable to react in time. Bigfoot's massive arm swings in a brutal arc, sending him sprawling to the ground."
    "ウィルソンは一瞬動けなくなる。\n反応が間に合わず、ビッグフットの巨大な腕が容赦なく振り下ろされ、彼は地面に吹き飛ばされる。"

# game/chapter1.rpy:647
translate japanese chapter_1_wilson_timeout_b493adf9:

    # zali_char "WILSON—!!!!"
    zali_char "ウィルソンーー!!!!"

# game/chapter1.rpy:657
translate japanese chapter_1_wilson_fail_b493adf9:

    # zali_char "WILSON—!!!!"
    zali_char "ウィルソンーー!!!!"

# game/chapter1.rpy:667
translate japanese chapter_1_wilson_clear_9784e087:

    # "Wilson steps aside with the precision of a man who's tango'd with death more times than he cares to count."
    "ウィルソンは、一度や二度では数えきれないほど死線をくぐり抜けてきた男らしく、精密な動きで横へと身をかわす。"

# game/chapter1.rpy:668
translate japanese chapter_1_wilson_clear_b01e1cf8:

    # "Bigfoot's charge narrowly misses him, leaving claw marks in the ground instead."
    "ビッグフットの突進はギリギリで外れ、代わりに鋭い爪痕が地面に深く刻まれた。"

# game/chapter1.rpy:669
translate japanese chapter_1_wilson_clear_57d5ef70:

    # wilson_char "F—That was close!"
    wilson_char "くっ…危なかった！"

# game/chapter1.rpy:670
translate japanese chapter_1_wilson_clear_be1f996f:

    # "Wilson nimbly dodges the attack—exactly what you'd expect from a hitman. Meanwhile, Zali raises the frying pan high above his head, banging it loudly to get Bigfoot's attention."
    "ウィルソンは華麗に攻撃をかわす。まさにヒットマンの貫禄。\nその間にザリはフライパンを高く掲げ、ビッグフットの注意を引こうと大きく叩いて音を鳴らす。"

# game/chapter1.rpy:679
translate japanese chapter_1_zali_qte_0a392e1a:

    # "Bigfoot locks its rage-filled eyes on Zali. He quickly wraps a bandage around the pan's handle, creating an improvised meteor hammer."
    "ビッグフットの怒りの視線がザリにロックオンされる。\nザリは素早くフライパンの柄に包帯を巻きつけ、即席のメテオハンマーを作り上げた。"

# game/chapter1.rpy:680
#translate japanese chapter_1_zali_qte_a19fe0c7:

    # "He starts swinging the pan in a steady rhythm, its arc cutting through the air. Timing is everything now. Zali looks at its crotch—"
    # "彼はフライパンを一定のリズムで振り始める。\nその軌道が空気を切り裂く。今、重要なのはタイミングだ。\nザリは相手の股間を見据え—"

# game/chapter1.rpy:696
#translate japanese chapter_1_zali_qte_1_2_2e25a67d:

    # zali_char "Take this! Where are you looking at?"
    # zali_char "くらえ！どこ見てるの？"

# game/chapter1.rpy:708
#translate japanese chapter_1_zali_qte_1_3_3620ea1e:

    # zali_char "HA! Oh that's gonna hurt! Now last one..."
    # zali_char "ハッ！ これは痛そうだね！さあ、仕上げだよ…"

# game/chapter1.rpy:724
translate japanese chapter_1_zali_fail_fc538419:

    # vanta_char "ZALI—!!!!"
    vanta_char "ザリーーー!!!!"

# game/chapter1.rpy:733
translate japanese chapter_1_zali_timeout_d76434b7:

    # "Zali took too long to move and got attacked."
    "ザリは動くのが遅すぎて、攻撃を受けてしまった。"

# game/chapter1.rpy:744
translate japanese chapter_1_zali_clear_d238aefa:

    # zali_char "Phew!! Easy peasy!"
    zali_char "ふぅ！ 楽勝だね！"

# game/chapter1.rpy:748
translate japanese chapter_1_zali_clear_bb8ef080:

    # "Zali's improvised meteor hammer stuns Bigfoot, leaving it concussed and stumbling directly towards you."
    "ザリの即席メテオハンマーがビッグフットを見事に打ち抜き、眩暈を起こさせる。\n怪物はふらつきながら、今度はあなたの方へと向かってきた。"

# game/chapter1.rpy:749
translate japanese chapter_1_zali_clear_bfc60998:

    # "All you've got is a stick, but you're confident, and you've handled worse."
    "武器はただの棒しかないが、あなたは自信がある。\n今までだって、もっと厄介な相手を捌いてきた。"

# game/chapter1.rpy:751
translate japanese chapter_1_zali_clear_01aaaabe:

    # "You dart forward, facing the creature head-on as its massive fist swings towards you."
    "一気に前へと飛び出し、振り下ろされる巨拳と正面から対峙する。"

# game/chapter1.rpy:762
translate japanese chapter_1_vanta_qte_624be87e:

    # "You see its fist swinging from the right, you decide to—"
    "右から拳が振りかぶられるのを見て、あなたは—"

# game/chapter1.rpy:784
translate japanese chapter_1_vanta_qte_1_2_f20387e2:

    # vanta_char "Light work, light work."
    vanta_char "余裕、余裕。"

# game/chapter1.rpy:786
translate japanese chapter_1_vanta_qte_1_2_f94a1b10:

    # "You bounce lightly on your feet to stay nimble."
    "身軽さを活かし、足元を弾ませながら素早く動く。"

# game/chapter1.rpy:792
translate japanese chapter_1_vanta_qte_1_2_a325f065:

    # "You study Bigfoot's movements carefully, anticipating the next attack. This time, its uses the other arm!"
    "あなたはビッグフットの動きを注意深く観察し、次の攻撃を予測する。\n今度は反対の腕を使ってきた！"

# game/chapter1.rpy:793
translate japanese chapter_1_vanta_qte_1_2_28864d1a:

    # "You ready yourself, and—"
    "身構え、—"

# game/chapter1.rpy:815
translate japanese chapter_1_vanta_qte_1_3_0e3106ef:

    # vanta_char "I can do this all day... Come at me."
    vanta_char "一日中でもやってやるよ…かかってこい。"

# game/chapter1.rpy:822
translate japanese chapter_1_vanta_qte_1_3_62eb61fb:

    # "Bigfoot's erratic swings become wilder, it's going straight to your stomach! You—"
    "ビッグフットの不規則な振りがますます荒くなり、今度は真っ直ぐ腹部を狙ってきた！\nあなたは—"

# game/chapter1.rpy:841
translate japanese chapter_1_vanta_fail_01fdaca2:

    # "You jump straight into its punch. It's too late to jump away again—"
    "あなたはビッグフットの拳に真正面から飛び込んでしまう。\nもう後ろへ跳んで避けるには遅すぎる―"

# game/chapter1.rpy:842
translate japanese chapter_1_vanta_fail_af05a9d7:

    # zali_char "VANTA—!!!!"
    zali_char "ベンターー!!!!"

# game/chapter1.rpy:851
translate japanese chapter_1_vanta_timeout_1a2c1082:

    # "Your feet are stuck to the ground, Bigfoot's strike is about to land on your face—"
    "あなたの足が地面に張り付いたように動かない。\nビッグフットの一撃が君の顔面に迫る―"

# game/chapter1.rpy:852
translate japanese chapter_1_vanta_timeout_af05a9d7:

    # zali_char "VANTA—!!!!"
    zali_char "ベンターー!!!!"

# game/chapter1.rpy:866
translate japanese chapter_1_vanta_clear_8e5792be:

    # vanta_char "Alright, let's wrap this up so I can head back to bed with my homies, shall we?"
    vanta_char "よし、そろそろ決着をつけよう。\n早く片付けて、仲間とキャビンに戻って寝るとするか。"

# game/chapter1.rpy:874
translate japanese chapter_1_vanta_clear_6ce311af:

    # "Spotting an opening, you move in with accuracy. You run in with a sharp knee strike, landing squarely on Bigfoot's chest. Without hesitation, you pivot smoothly and backhand the stick into its neck, ending the fight with a decisive blow."
    "隙を見つけたあなたは、正確に動き出す。鋭い膝蹴りを繰り出し、ビッグフットの胸にクリーンヒットさせる。さらに、迷いなく体を回転させ、棒をバックハンドでその首元に叩き込む。\n決定的な一撃だった。"

# game/chapter1.rpy:882
translate japanese chapter_1_vanta_clear_5f7a3c83:

    # vanta_char "All in a night's work..."
    vanta_char "なに、これも仕事のうちさ。"

# game/chapter1.rpy:886
translate japanese chapter_1_vanta_clear_642db186:

    # zali_char "Yeah! I can secure it to that tree over there. It's not going anywhere."
    zali_char "そうだね！あそこの木に固定しておけば、大人しくしてるだろう。"

# game/chapter1.rpy:888
translate japanese chapter_1_vanta_clear_e2c4506b:

    # vanta_char "Man... Let's get back to sleep..."
    vanta_char "はぁ…早く寝ようぜ…"

# game/chapter1.rpy:899
translate japanese chapter_1_vanta_clear_59619716:

    # "In the dim glow of the A.S.H. office, a new mission notification pings onto the mission board. A familiar name flashes in bold letters:"
    "薄暗いA.S.Hのオフィスで、ミッションボードに新しい任務の通知音が鳴り響く。\n太字で浮かび上がるのは、見覚えのある名前だった—。"

translate japanese strings:

    # game/chapter1.rpy:125
    old "Take a Picture With Your Phone"
    new "スマホで写真を撮る"

    # game/chapter1.rpy:234
    old "That leaves you to make a choice: help Zali pick up groceries and head back to camp, or join Wilson in tracking down the missing cows for the distraught farmer.{fast}"
    new "さて、あなたの選択だ。ザリと一緒に食材を買ってキャンプに戻るか、ウィルソンと一緒に行方不明の牛を探しに行くか。{fast}"

    # game/chapter1.rpy:234
    old "Join Wilson to Search for the Missing Cows"
    new "ウィルソンと一緒に牛探しへ"

    # game/chapter1.rpy:234
    old "Go Grocery Shopping With Zali"
    new "ザリと食料品の買い出し"

translate japanese strings:

    # game/chapter1.rpy:69
    old "Brake"
    new "ブレーキ"

translate japanese strings:

    # game/chapter1.rpy:595
    old "Jump Apart"
    new "跳びのく"

    # game/chapter1.rpy:637
    old "Dodge"
    new "避ける"

    # game/chapter1.rpy:638
    old "Throw Flashlight"
    new "懐中電灯を投げる"

    # game/chapter1.rpy:773
    old "Jump Left"
    new "左へジャンプする"

    # game/chapter1.rpy:774
    old "Jump Right"
    new "右へジャンプする"

    # game/chapter1.rpy:833
    old "Jump Up"
    new "上へジャンプする"

    # game/chapter1.rpy:834
    old "Duck Down"
    new "しゃがむ"# TODO: Translation updated at 2025-06-08 22:27

# game/chapter1.rpy:554
translate japanese chapter_1_3_99bf1ba8:

    # "The three of you jump out of bed, throw on some clothes,\nand grab whatever tools are within reach."
    "あなたたち三人はベッドから飛び起き、急いで服を着る。\nそして手近な道具を手に取った。"
# TODO: Translation updated at 2025-06-09 01:20

# game/chapter1.rpy:680
translate japanese chapter_1_zali_qte_9cfe039c:

    # "He starts swinging the pan in a steady rhythm, its arc cutting through the air. Timing is everything now. Zali looks at its {size=60}crotch{/size}—"
    "彼はフライパンを一定のリズムで振り始める。その軌道が空気を切り裂く。\n今、重要なのはタイミングだ。ザリは相手の{size=60}股間{/size}を見据え—"

# game/chapter1.rpy:696
translate japanese chapter_1_zali_qte_1_2_e7525233:

    # zali_char "Hey! Where are you looking at? {size=60}Eyes{/size}. On. Me."
    zali_char "ねぇ！どこ見てるの？\nちゃんと{size=60}その目{/size}で私を見て…"

# game/chapter1.rpy:708
translate japanese chapter_1_zali_qte_1_3_c89f1d41:

    # zali_char "HA! Oh that's gonna hurt! Now let's deal with those dangerous little {size=60}claws{/size} of yours..."
    zali_char "ハッ！ これは痛そうだね！\nさて、その危なっかしい{size=60}小さな爪{/size}もどうにかしないと…"

# TODO: Translation updated at 2025-06-14 23:40

# game/chapter1.rpy:173
translate japanese chapter_1_2_7749ddb6:

    # "A group of forest rangers stand outside the grocery store, their conversation growing louder as you approach. A farmer, clearly upset, joins them, gesturing at his broken fence and mentioning strange footprints he found near his farm."
    "食料品店の前には数人の森林警備隊員が立っており、あなたたちが近づくにつれて会話の声が大きくなっていく。そこへ、明らかに苛立った様子の農夫が加わり、壊された柵のことや、自分の農場の近くで見つけた奇妙な足跡について身振り手振りで訴えている。"

# game/chapter1.rpy:302
translate japanese chapter_1_2_82561a91:

    # wilson_char "Moo louder! You're a concerned father! Never back down, never what?"
    wilson_char "モーって強く鳴け！お前は心配してるお父さんだろ！\n諦めるな、諦めたらそこで試合……なんだっけ？"

# game/chapter1.rpy:325
translate japanese chapter_1_2_00980a9d:

    # farmer_char "Well, I'll be damned, I didn't think you'd be so good at this cowboy business. Ever thought about ranching?"
    farmer_char "いやぁ、まさかこんなにカウボーイ仕事が上手いとは思わなかったよ。牧場経営に興味はないか？"

# game/chapter1.rpy:491
translate japanese chapter_1_3_90e1623a:

    # "You three enjoy your roasted marshmallows while engaging in a much-needed mental check-in with each other."
    "三人は焼きマシュマロを楽しみながら、お互いを労る時間を過ごす。"

