﻿# TODO: Translation updated at 2025-05-21 11:46

# game/chapter2.rpy:17
translate japanese chapter_2_09278cdf:

    # wilson_char "\"A good friend of mine, Rich Lady, is hosting a high-profile event at her manor in Paris.\nShe is also a big fan of my one-of-a-kind art piece, 'Real.' Naturally, she wants to borrow it for display next week.\""
    wilson_char "「僕の友人の リッチレディが、パリの邸宅でいま注目のイベントを開催するんだ。\n彼女は僕の唯一無二のアート作品『Real』の大ファンでもあって、まぁ当然、来週の展示のためにそれを貸してほしいとお願いをしてきたんだ。」"

# game/chapter2.rpy:24
translate japanese chapter_2_741d34fa:

    # wilson_char "{size=40}To France!{/size}"
    wilson_char "{size=40}目的地はフランス！{/size}"

# game/chapter2.rpy:26
translate japanese chapter_2_b37a0845:

    # zali_char "{size=45}On y va!{/size}"
    zali_char "{size=45}On y va!（さあ、出発だ！）{/size}"

# game/chapter2.rpy:36
translate japanese chapter_2_d5c7780d:

    # "Ah yes. The land of love, art, delicious food, and—of course—the birthplace of the one and only Vezalius Bandage."
    "ああ、愛と芸術と美食の国、そして―\nもちろん、唯一無二のヴェザリウス バンデージ生誕の土地。"

# game/chapter2.rpy:37
translate japanese chapter_2_6419b5a9:

    # "After successfully delivering the painting to the Parisian manor, the three of you step out into the heart of Paris."
    "作品を無事にパリの邸宅へと届けたあと、三人はパリの中心部へと足を踏み出す。"

# game/chapter2.rpy:65
translate japanese chapter_2_f76c70bb:

    # "It's Rich Lady. You pick up the phone and put it on speaker."
    "リッチレディからだ。あなたは電話を取り、スピーカーモードにする。"

# game/chapter2.rpy:75
translate japanese chapter_2_2cf6e41f:

    # manor_owner_char "... Well, you probably wouldn't know this, but a few years ago, there was a series of high-profile thefts across the city—paintings, jewels, priceless artifacts—all of them vanishing without a trace."
    manor_owner_char "…おそらく知らないでしょうけれど、数年前、この街では連続窃盗事件が起きていたの。\n絵画、宝石、貴重な美術品―すべて跡形もなく消えたの。"

# game/chapter2.rpy:76
translate japanese chapter_2_ece3dfa3:

    # manor_owner_char "Museums, private collections, even high-security vaults weren't safe. And the thief?\nHe always left a note signed 'Phantom Thief.'"
    manor_owner_char "美術館、個人コレクション、さらには厳重な警備が施された金庫ですら標的になったわ。\nそして犯人はいつも【怪盗】のサインが入った予告状を残していた。"

# game/chapter2.rpy:98
translate japanese chapter_2_64187c3e:

    # "She seems much calmer now, her eyes filled with determination. The panic from earlier is nowhere to be seen."
    "彼女は先ほどのパニックが嘘のように落ち着きを取り戻し、その瞳には強い決意が宿っていた。"

# game/chapter2.rpy:103
translate japanese chapter_2_819f1525:

    # manor_owner_char "But guess what? Turns out, the comedian I hired is also a hero! Small world, huh?\nWouldn't it be amazing for you to work with him?"
    manor_owner_char "でも驚いたわ！\nなんと、私が雇ったコメディアン、実はヒーローだったの！世間は狭いわね！\n君たちも彼と一緒に仕事できるなんて最高でしょう？"

# game/chapter2.rpy:108
translate japanese chapter_2_009336e8:

    # vanta_char "Sounds good, we'll be ther—No, I don't want to say that. Your plan sounds solid.\nSo... Another hero? I wonder who that is..."
    vanta_char "ふっ…ヒーローは遅れてやってくるもんだ—いや、なんでもない…\nえっと、あなたの作戦は信頼できそうですね。\nで…他のヒーロー？誰だろう…気になるな…"

# game/chapter2.rpy:122
translate japanese chapter_2_a1246420:

    # wandv_char "M... Mana?!"
    wandv_char "マ…マナ？！"

# game/chapter2.rpy:134
translate japanese chapter_2_db4c9fa5:

    # manor_owner_char "Wow, it seems like you already know each other—this should go even more smoothly!"
    manor_owner_char "まあ、もう顔なじみなのね？それなら、思ったよりスムーズにいきそうだわ。"

# game/chapter2.rpy:141
translate japanese chapter_2_18ac9feb:

    # zali_char "Yeah, Mana and I even defused a bomb together once...totally went according to plan. Obviously, nothing exploded. No one panicked. Flawless, even."
    zali_char "うん、マナとは爆弾処理を一緒にやったこともあるんだよ…もちろん、完全に計画通りだったよ。\n爆発なんて起きなかったし、誰もパニックになんてなってないし。\n完璧だった、うん。"

# game/chapter2.rpy:143
translate japanese chapter_2_6060875c:

    # mana_char "Ah... Yeah. I, uh...definitely remember that. Haha...ha..."
    mana_char "あ…ああ。 えっと…もちろん、覚えてるで。ハハ…ハハ…"

# game/chapter2.rpy:147
translate japanese chapter_2_c47bdeb4:

    # wilson_char "Anyway! With the four of us, stopping the Phantom Thief should be easy peasy.\nRight, guys?"
    wilson_char "とにかく！僕たち四人が揃えば、怪盗を止めるなんて楽勝だろ？な、みんな？"

# game/chapter2.rpy:148
translate japanese chapter_2_f5917a49:

    # "A chorus of “YES!” erupts, filling the room with energy. Rich Lady watches, amusement flickering across her face as she visibly relaxes."
    "「YES！」の声が部屋に響き渡り、勢いよく空気が活気づく。\nリッチレディはその様子を見て、楽しそうに微笑みながら、少し緊張がほぐれたようだ。"

# game/chapter2.rpy:157
translate japanese chapter_2_6c68785f:

    # "The night of the party arrives, and with it, the weight of the mission. The Phantom Thief\nhas never been caught—but tonight, that changes."
    "そして、ついにパーティーの夜がやってきた。\nこの怪盗は今まで一度も捕まったことがない―でも今夜、その歴史が変わる。"

# game/chapter2.rpy:169
translate japanese chapter_2_e7687a24:

    # "As the doors shut behind the heroes, Rich Lady lingers for a moment, a sly, knowing smile tugging at her lips."
    "扉が閉まると、リッチレディは少しの間その場に留まり、どこか意味ありげな笑みを浮かべた。"

# game/chapter2.rpy:177
translate japanese chapter_2_87865b9f:

    # mana_char "Uh... Krisis? You guys good in there?"
    mana_char "…おい、クライシス。大丈夫か？"

# game/chapter2.rpy:182
translate japanese chapter_2_0e5742b2:

    # "And let's just say...their disguises aren't exactly what they expected."
    "そして…まあ、一言で言えば、想像していた変装とは、だいぶ違っていた。"

# game/chapter2.rpy:183
translate japanese chapter_2_675b89da:

    # wilson_char "..."
    wilson_char "…"

# game/chapter2.rpy:184
translate japanese chapter_2_27e0a79b:

    # zali_char "..."
    zali_char "…"

# game/chapter2.rpy:185
translate japanese chapter_2_2e688bd5:

    # vanta_char "..."
    vanta_char "…"

# game/chapter2.rpy:212
translate japanese chapter_2_c2113716:

    # wilson_char "So...when you said 'staff uniforms,' did you just casually forget to mention that we'd be in maid outfits?"
    wilson_char "…で、スタッフの制服って言った時さ、まさかメイド服だとは一言も言ってなかったよな？"

# game/chapter2.rpy:213
translate japanese chapter_2_67644519:

    # "Rich Lady grins warmly, without a hint of remorse."
    "リッチレディは、全く悪びれる様子もなく、にこやかに微笑む。"

# game/chapter2.rpy:222
translate japanese chapter_2_3af92b10:

    # "With the party underway, it's time to put aside distractions—your mission is to protect the Real painting."
    "パーティーが始まり、気を引き締める時が来た。\n任務はただ一つ―『Real』の絵を守ること。"

# game/chapter2.rpy:235
translate japanese chapter_2_8cc1715c:

    # "Mana's breath catches as he takes in the masterpiece before him, his eyes slowly widening with admiration."
    "マナは息をのみ、目を見開いてその傑作を見つめる。"

# game/chapter2.rpy:240
translate japanese chapter_2_f1a128e1:

    # mana_char "Wow. This is indeed...a masterpiece. The angles, the compositions and the coloring... Whoa, even the saliva..."
    mana_char "…すごい。これは本当に…芸術や。\n構図、角度、色彩…おお、よだれまで…"

# game/chapter2.rpy:241
translate japanese chapter_2_e37b2180:

    # "Leaning in further, his eyes capture every corner. The drool glistening around the\nmouth is...definitely very well-rendered."
    "マナはさらに身を乗り出し、隅々まで目を凝らす。\n口元に輝くよだれの描写が…やけにリアルだ。"

# game/chapter2.rpy:243
translate japanese chapter_2_c9ead1f3:

    # "Then, something feels off. His eyes narrow as he reaches for the frame, tilting his head\nand peeking behind the painting."
    "だが、何かがおかしい。\n目を細め、額縁に手を伸ばし、首を傾げながら絵の裏側を覗き込む。"

# game/chapter2.rpy:245
translate japanese chapter_2_9798f4ac:

    # "His breath hitches, and his eyes widen as he spots a bomb—small, yet clearly not\nto be underestimated."
    "―その瞬間、息が詰まり、目が大きく見開かれた。\n爆弾。小型だが、決して侮れない。"

# game/chapter2.rpy:247
translate japanese chapter_2_6db398c7:

    # "Mana recognizes it instantly. He knows this type of bomb all too well. His eyes dart\nstraight to Zali."
    "マナは即座にそれを見抜く。\nこのタイプの爆弾は―彼にとって、あまりにも 見覚えがありすぎる。\n視線が反射的にザリへと向かう。"

# game/chapter2.rpy:253
translate japanese chapter_2_5ecf0d70:

    # "Zali looks at Mana, slightly confused, but steps forward regardless. Mana leans in,\nlowering his voice to a whisper."
    "突然名前を連呼され、ザリは一瞬戸惑ったような表情を浮かべるが、それでも前に出る。\nマナはそっと身を寄せ、声をひそめる。"

# game/chapter2.rpy:256
translate japanese chapter_2_69d902f8:

    # mana_char "Look here... A bomb. We need to move this painting to a corner and handle it right away."
    mana_char "…ここ見て。爆弾や。\nこの絵をすぐに隅へ移して、処理せんとまずいわ。"

# game/chapter2.rpy:259
translate japanese chapter_2_f8daf572:

    # zali_char "Of course. Let's move this over there. We've done this before, Mana. I know we can pull it off again, right?"
    zali_char "もちろん。じゃあ、これをあっちに運ぼう。マナ、これ前にもやったよね。\n今回もきっとうまくいくよ、そうでしょ？"

# game/chapter2.rpy:277
translate japanese chapter_2_e8569ccd:

    # wandv_char "{size=40}Whoa!! What's—{/size}"
    wandv_char "{size=40}うおっ！！ 何が―{/size}"

# game/chapter2.rpy:283
translate japanese chapter_2_a7c4c656:

    # wilson_char "Hah?? I mean, yeah, but— Ugh, shut up, let's just go..."
    wilson_char "はぁ！？ いや、まあ、そうだけど―うるさい、早く行くぞ…！"

# game/chapter2.rpy:289
translate japanese chapter_2_bef0a9ec:

    # zali_char "Wilson! Mana and I couldn't find any light source near us. We're holding the painting,\nbut if you can get to the fuse box—it's probably near the kitchen or in a utility room in mansions like this..."
    zali_char "ウィルソン！マナと私の近くに明かりになりそうなものが見当たらない。\n今は絵を持ってるけど、もしそっちでブレーカーにたどり着けるなら―\nたぶんこういう屋敷だと、キッチンの近くか物置き部屋みたいなところにあるはず…"

# game/chapter2.rpy:292
translate japanese chapter_2_0f7bab05:

    # "You and Wilson weave through the crowd, careful not to knock anyone over—or get crushed yourselves."
    "二人は混乱する群衆をかき分けながら、誰も怪我をしないように、そして自分たちも押しつぶされないように必死に進む。そのとき―"

# game/chapter2.rpy:294
translate japanese chapter_2_30ade051:

    # "A few meters away, the sharp crash of shattering glass cuts through the chaos.\nEvery hero stiffens, heads snapping toward the sound as tension thickens the air."
    "数メートル先で、鋭いガラスの割れる音が響き、空気が一気に張り詰めた。\n全員の動きが止まり、一斉に音のした方向へと振り向く。"

# game/chapter2.rpy:295
translate japanese chapter_2_8d80a2ed:

    # "Then, Rich Lady's frantic voice crackles through their earpieces."
    "直後、イヤホンにリッチレディの悲鳴が割り込んできた。"

# game/chapter2.rpy:297
translate japanese chapter_2_d1204856:

    # manor_owner_char "Someone's stealing my necklace! It's worth over $5 million!\n{size=40}My prized possessionnnn—{/size}"
    manor_owner_char "誰かが私のネックレスを盗んでる！ 500万ドル以上の価値があるのよ！ \n{size=40}私の最っっ高の宝物がぁぁぁ！！！{/size}"

# game/chapter2.rpy:302
translate japanese chapter_2_a506062e:

    # mana_char "Krisis, come in! It was never about the painting—that was just a decoy! Find the thief!\nThe necklace is the real target!"
    mana_char "クライシス、応答しろ！ 狙いは絵じゃない―あれはただの囮や！ \n本当のターゲットはネックレスや！ 怪盗を見つけろ！"

# game/chapter2.rpy:315
translate japanese chapter_2_88cb7fb8:

    # "Wilson moves quickly, navigating the dimly lit corridor toward the kitchen. The emergency lights flicker weakly, casting distorted shadows against the mansion's ornate walls.\nHis heels click against the polished floor as he picks up the pace—"
    "ウィルソンは薄暗い廊下を素早く進み、キッチンへと向かう。\n非常灯が弱々しく点滅し、豪華な屋敷の壁にゆがんだ影を落としている。\n磨かれた床の上でヒールの音が響き、彼はさらにペースを上げる―"

# game/chapter2.rpy:321
translate japanese chapter_2_5433bc54:

    # wilson_char "{size=40}Oh my god! My dress—! UGHHHHH!!{/size}"
    wilson_char "{size=40}ちょっと! 僕のドレスが!! もぉーーーー!!{/size}"

# game/chapter2.rpy:322
translate japanese chapter_2_1a4785ed:

    # "Wilson tugs once, twice—before the entire suit of armor lurches forward and crashes\nto the ground with a deafening clang."
    "ウィルソンは一度、二度と力を込めて引っ張る。\nその瞬間、甲冑全体が前のめりに傾き、轟音とともに床に崩れ落ちた。"

# game/chapter2.rpy:328
translate japanese chapter_2_c42589b7:

    # wilson_char "Ughhh, I swear, I'm the clumsiest maid in this mansion."
    wilson_char "うわぁ…もう最悪だ。僕、この屋敷で一番ドジなメイドじゃないか？"

# game/chapter2.rpy:330
translate japanese chapter_2_84a107ce:

    # "Wilson stands up and gives his dress a quick shake, then hurries on. The fuse box isn't going to find itself!"
    "ウィルソンは立ち上がり、ドレスの裾をさっと払うと、そのまま足早に進んでいく。\n―ブレーカーは自分で見つかってくれるわけじゃないからね！"

# game/chapter2.rpy:348
translate japanese chapter_2_1b927edf:

    # "Wilson flips the fuse box open, his eyes scanning the mess of switches and buttons.\nNo labels. No instructions anywere."
    "ブレーカーのカバーを開け、中を確認する。\nスイッチとボタンがごちゃごちゃに入り乱れ、ラベルも説明も一切なし。"

# game/chapter2.rpy:417
translate japanese chapter_2_2_014e2a61:

    # "Back at the painting, Mana and Zali exchange glances as the lights flick back on."
    "絵の前。部屋が再び明るくなり、マナとザリが互いに視線を交わす。"

# game/chapter2.rpy:421
translate japanese chapter_2_2_d57969dd:

    # mana_char "This is slightly different to the bombs we defused before!"
    mana_char "これは前に解除した爆弾とは少し違うぞ！"

# game/chapter2.rpy:428
translate japanese chapter_2_2_40391da1:

    # "Zali takes a deep breath, steadying his nerves. He can't let the pressure get to him—\nhe has to stay focused."
    "ザリは深く息を吸い込み、気持ちを落ち着かせる。\nこのプレッシャーに負けるわけにはいかない、集中しなければ。"

# game/chapter2.rpy:465
translate japanese chapter_2_zali_flashing_2_2a3f8664:

    # "Mana presses the buttons in the correct order. A new set of colors begins flashing—\nit's not over yet!"
    "マナはボタンを正しい順番で押す。すると、新しい色のセットが点滅し始める— \nまだ終わりじゃない！"

# game/chapter2.rpy:483
translate japanese chapter_2_zali_flashing_2_76f46f90:

    # "Rich Lady's voice suddenly comes through their ear piece. Both Zali and Mana freeze for a second as they try to focus on memorizing the sequence."
    "突然、リッチレディの声がイヤホン越しに響く。\nザリとマナは一瞬動きを止め、点滅する順番を覚えようと集中する。"

# game/chapter2.rpy:508
translate japanese chapter_2_zali_flashing_3_c3a59889:

    # "With Zali's laser focus, he manages to press the buttons correctly, even with a few unexpected interruptions."
    "ザリは驚異的な集中力で、多少の邪魔が入りつつも正しいボタンを押していく。"

# game/chapter2.rpy:546
translate japanese chapter_2_zali_timeout_1d4f7443:

    # "Oh no—the time ran out! For a split second, nothing happens. Then—"
    "あっ―時間切れだ！一瞬、何も起こらない。だがその直後―"

# game/chapter2.rpy:550
translate japanese chapter_2_zali_timeout_f3985afb:

    # mana_char "ZALI—!!!"
    mana_char "ザリーーーッ！！！"

# game/chapter2.rpy:571
translate japanese chapter_2_zali_clear_70987418:

    # "Zali presses the final buttons. A green light flickers on—the beeping stops.\nSilence. Then, relief."
    "ザリが最後のボタンを押す。\nすると、緑のライトが点滅し、警告音が止まる。\n—静寂。そして、安堵。"

# game/chapter2.rpy:591
translate japanese chapter_2_vanta_qte_1_ff3a6fbc:

    # "The Phantom Thief is fast, darting through the crowd. You need to act now—with your unmatched reflexes, you could totally jump over the table like a cool action hero...\nor, you know, just shove your way through the guests."
    "怪盗は素早く群衆の中を駆け抜けていく。\n今すぐ行動しなければ―君の卓越した反射神経があれば、カッコいいアクションヒーローのようにテーブルを飛び越えることだってできる…あるいは、まあ、普通にゲストたちをかき分けて進んでもいいけど。"

# game/chapter2.rpy:615
translate japanese chapter_2_vanta_1_1_751f329e:

    # "You leap over the table in one sleek motion. No distractions. No second chances.\nJust you, the chase, and the prize they think they can steal."
    "あなたは軽やかにテーブルを飛び越える。\n迷っている暇はない。やり直しもきかない。\nあるのはただ―自分と追跡、そしてやつが奪えると思っている獲物だけだ。"

# game/chapter2.rpy:634
translate japanese chapter_2_vanta_timeout_1_36c024a6:

    # "You missed the opportunity to jump over the table, you push through the crowd instead, following the thief."
    "テーブルを飛び越えるチャンスを逃し、代わりに群衆をかき分けて、怪盗の後を追いかける。"

# game/chapter2.rpy:642
translate japanese chapter_2_vanta_qte_2_e72faabd:

    # "The thief is slipping away, heading straight for the exit. You spot a chance to intercept—dramatically dive through the window, or use the door like a reasonable person."
    "怪盗は出口に向かって逃げていく。あなたは、進路を塞ぐチャンスを見つける。\nドラマチックに窓から飛び込むか、それとも常識的にドアを使うか―選ぶのはあなた次第だ。"

# game/chapter2.rpy:665
translate japanese chapter_2_vanta_2_1_79f36043:

    # "Pivoting sharply, you charge toward the window and throw yourself through it.\nThe impact shatters the glass, shards scattering in every direction as you twist mid-air.\nThe night air rushes past you before you hit the ground, rolling to absorb the impact."
    "鋭く方向転換し、窓に向かって駆け出すと、それにそのまま体ごと突っ込んだ。\nガラスが砕け散り、無数の破片が四方に飛び散る。\n空中で体をひねり、夜風を切りながら、着地時の衝撃を和らげるため転がった。"

# game/chapter2.rpy:677
translate japanese chapter_2_vanta_2_2_5a75b82f:

    # "You push harder, legs burning as you sprint toward the exit. The thief is just ahead,\nslipping through the doorway. You grit your teeth and force your body to keep moving."
    "あなたはさらに力を込め、脚が焼けるように痛む中、出口へ向かって全力で駆ける。\n怪盗はすぐ目の前、扉の隙間をすり抜けようとしている。\nあなたは歯を食いしばり、体を無理やり動かし続けた。"

# game/chapter2.rpy:678
translate japanese chapter_2_vanta_2_2_8e8c5750:

    # "Your chest rises and falls heavily—you're exhausted. Chasing someone through a mansion full of people has drained every ounce of energy in your body, but you refuse to let them get away."
    "胸は激しく上下し、息も絶え絶え。人であふれた屋敷の中を走り回ったせいで、体力はほとんど尽きかけている。\nそれでも、決して逃がすわけにはいかない。"

# game/chapter2.rpy:689
translate japanese chapter_2_vanta_timeout_2_8e8c5750:

    # "Your chest rises and falls heavily—you're exhausted. Chasing someone through a mansion full of people has drained every ounce of energy in your body, but you refuse to let them get away."
    "胸は激しく上下し、息も絶え絶え。人であふれた屋敷の中を走り回ったせいで、体力はほとんど尽きかけている。\nそれでも、決して逃がすわけにはいかない。"

# game/chapter2.rpy:702
translate japanese chapter_2_3_9b37b387:

    # "You yank the necklace free, holding it up in victory. Think chasing a thief in a maid dress\nis impossible? Nah-uh! Light work. Just another Tuesday."
    "ネックレスを勢いよく引きちぎり、勝利の証のように掲げる。\nメイド服で怪盗を追うなんて無理？ いやいや、楽勝だろ。いつものことだよ。"

# game/chapter2.rpy:710
translate japanese chapter_2_3_3e5637ad:

    # "Just as you finish tying the thief's hands behind their back, you hear hurried footsteps approaching. Rich Lady, Mana, Zali, and Wilson rush toward you. Their faces are lit\nwith relief and awe."
    "ちょうど怪盗の手を背中に回して縛り終えたところで、バタバタと足音が響く。\nリッチレディ、マナ、ザリ、ウィルソンが駆け寄ってくる。\n驚きと安堵が入り混じった表情を浮かべながら—"

# game/chapter2.rpy:726
translate japanese chapter_2_3_574054cf:

    # "Rich Lady retrieves the stolen necklace, holding it up to the moonlight with teary eyes."
    "リッチレディは嬉しそうに盗まれたネックレスを受け取り、光にかざしながら涙ぐむ。"

# game/chapter2.rpy:727
translate japanese chapter_2_3_d70ae5c6:

    # manor_owner_char "Oh, my beloved $5 million treasure! And the Real painting is also unharmed!\nTonight, we honor the hero!"
    manor_owner_char "愛しき500万ドルの宝物よ…！ そして『Real』も無事だった…！\n今夜はこの英雄を称えましょう！"

# game/chapter2.rpy:730
translate japanese chapter_2_3_bab50f25:

    # "Mana steps forward, pulling something from his pocket—a sealed envelope."
    "騒ぎが落ち着くと、マナが前に出てポケットから封筒を取り出す。"

# game/chapter2.rpy:731
translate japanese chapter_2_3_446460ec:

    # mana_char "Actually, there's something I want to give to you guys in person."
    mana_char "実は、直接みんなに渡したいものがあるんや。"

# game/chapter2.rpy:736
translate japanese chapter_2_3_4bdc6367:

    # wilson_char "Ooo...Fancy! You sure this isn't just an elaborate excuse to see me again?"
    wilson_char "お洒落だな これ、また僕たちを働かせるための口実じゃないだろうな？"

# game/chapter2.rpy:739
translate japanese chapter_2_3_78e88354:

    # zali_char "Well, Vanta? What do you think? We haven't been in Japan together in a while, have we?"
    zali_char "どう、ベンタ？また新しい冒険に出る準備はできてる？"

# TODO: Translation updated at 2025-06-04 22:01

# game/chapter2.rpy:10
translate japanese chapter_2_ec3b34e6:

    # "The short-lived peace of your retreat is officially over. It was nice while it lasted."
    "あなたの静かな休息は、正式に終わりを迎える。短い間だったが、いい時間だった。"

# game/chapter2.rpy:14
translate japanese chapter_2_e3c473d2:

    # "Back at A.S.H., the three of you stand around the mission board, reading the latest brief—this time from none other than Shu Yamino."
    "A.S.H. に戻ると、あなたたち三人はミッションボードの前に立ち、\n新しい任務の概要に目を通していた。\n今回の依頼人は、なんとあの闇ノシュウ だ。"

# game/chapter2.rpy:15
translate japanese chapter_2_f8317f13:

    # "No rest for the world's greatest heroes."
    "世界最高のヒーローに休息はない。"

# game/chapter2.rpy:16
translate japanese chapter_2_2e812d27:

    # vanta_char "\"Dear Krisis, I heard you just got back from your well-deserved trip to Canada. I hope you enjoyed the break, because now, I have a mission for you.\""
    vanta_char "「親愛なるクライシスへ。カナダでの旅行から戻ったばかりだと聞いた。\n休暇を楽しめたなら何よりだよ。\nさて、さっそくだけど、今度は僕から君たちに任務があるんだ。」"

# game/chapter2.rpy:18
translate japanese chapter_2_a53646d0:

    # zali_char "\"As you know, my work is extremely valuable—priceless, even. I trust you three to guard it with your lives as you escort it to France and ensure its safety over the next few weeks.\""
    zali_char "「君たちも知ってのとおり、僕の作品には値段がつけられないほどの価値がある。\nだからこそ、君たち三人にフランスへの輸送と数週間の警備を託したい。\n命をかけて守ってくれ。」"

# game/chapter2.rpy:19
translate japanese chapter_2_0cd8800e:

    # vanta_char "\"Thanks in advance for your hard work. Wishing you a smooth mission. Shu Yamino.\""
    vanta_char "「先にお礼を言っておくよ。任務が上手くいくことを願ってる。―闇ノシュウ」"

# game/chapter2.rpy:20
translate japanese chapter_2_89919034:

    # "You lean back in your chair. A high-profile art escort mission? That's new."
    "椅子にもたれかかりながら考える。―高額なアート作品の護送任務？ \nずいぶんと珍しい内容だ。"

# game/chapter2.rpy:22
translate japanese chapter_2_ecf57e4a:

    # vanta_char "Alright, boys—all hands on deck—or paint, I guess."
    vanta_char "よし、お前ら、戦闘準備…いや、今回は全員筆を取れ、かな。"

# game/chapter2.rpy:38
translate japanese chapter_2_d7295815:

    # "The city buzzes with life—locals stroll along cobbled streets, the aroma of fresh coffee drifts from bustling cafés, and the golden afternoon sun casts a warm glow over the historic architecture."
    "街は活気に満ちている。\n石畳の道を行き交う人々、賑わうカフェから漂う淹れたてのコーヒーの香り、黄金色の午後の日差しが歴史ある建築を温かく照らしていた。"

# game/chapter2.rpy:41
translate japanese chapter_2_0607faaf:

    # zali_char "Feels good to be back somewhere familiar."
    zali_char "馴染みのある場所に戻ってくると、なんだかホッとするね。"

# game/chapter2.rpy:44
translate japanese chapter_2_8de37484:

    # wilson_char "Finally, Paris! And—oh my god—I can smell fresh bread and pastries!"
    wilson_char "ついにパリ！ \nそれに―おー！パンと焼き菓子の香りがする！"

# game/chapter2.rpy:47
translate japanese chapter_2_3912414e:

    # vanta_char "Do we want to get some snacks? God, long flights make me hungry."
    vanta_char "…軽く食べるか？ \n長時間のフライトって、やたら腹が減るんだよな。"

# game/chapter2.rpy:48
translate japanese chapter_2_f1527f9b:

    # "Your stomach growls at the thought of food, leading you to the nearest boulangerie."
    "食べ物のことを考えた途端、腹の虫が鳴り始め、あなたは最寄りの パン屋 へと向かう。"

# game/chapter2.rpy:49
translate japanese chapter_2_aeb0b3e1:

    # "Stepping into the bakery, you're met with the buttery scent of freshly baked croissants and the quiet shuffle of locals picking up their pastries."
    "店の扉をくぐると、焼きたてのクロワッサンのバターの香りがふわりと漂い、地元の人々が静かにパンを選んでいる姿が目に入る。"

# game/chapter2.rpy:50
translate japanese chapter_2_f030324e:

    # "As you browse the pastry counter, your phone buzzes in your pocket. You pull it out and glance at the screen."
    "パンのショーケースを眺めていると、ポケットの中でスマホが振動した。\n取り出して画面を確認する。"

# game/chapter2.rpy:52
translate japanese chapter_2_abf7d016:

    # vanta_char "... Oh brother. What in the world?"
    vanta_char "…まったく、いったい何だよ。"

# game/chapter2.rpy:55
translate japanese chapter_2_2060e6cc:

    # "Wilson and Zali immediately lean in, their curiosity piqued as they look over your shoulder."
    "ウィルソンとザリもすぐに身を乗り出し、あなたの肩越しに画面を覗き込む。"

# game/chapter2.rpy:56
translate japanese chapter_2_ee323680:

    # wilson_char "\"Hello, Krisis. It seems you have been warmly welcomed to the wonderful and vibrant Paris. I do hope you enjoy what you can—because soon enough, the prize will be mine. Consider this fair warning before I snatch it from right under your noses. All the worst, Phantom Thief.\""
    wilson_char "「やあ、クライシス。華やかで素晴らしいパリへようこそ。今のうちに楽しんでおくといい。\n―だが、そう長くは続かない。なぜなら、その宝はすぐに私のものになるのだから。\nこれは君たちの目の前からそれを奪う前の親切な警告と受け取ってくれたまえ。\n―最悪の幸運を。怪盗より」"

# game/chapter2.rpy:58
translate japanese chapter_2_54ccca8b:

    # zali_char "A direct threat to our mission... But what? Phantom Thief?"
    zali_char "私たちの任務へ真っ向からの脅迫…でも、何？怪盗だって？"

# game/chapter2.rpy:60
translate japanese chapter_2_6959c398:

    # wilson_char "Well, there goes snack time. Why does this keep happening?"
    wilson_char "せっかくの休憩タイムが台無しじゃないか。どうしてこうなるんだ。"

# game/chapter2.rpy:62
translate japanese chapter_2_e194e21c:

    # vanta_char "I guess we just gotta ball. No time for croissants, boys—duty calls, again."
    vanta_char "…まあ、仕方ない。やるしかないな。\nクロワッサンどころじゃない、また任務だ。"

# game/chapter2.rpy:64
translate japanese chapter_2_5a16ce90:

    # "Just then, your phone vibrates again—this time, an incoming call. You're surprised by the caller on screen."
    "ちょうどその時、スマホがもう一度振動する。今度は…着信だ。\n画面に表示された名前に、思わず驚く。"

# game/chapter2.rpy:71
translate japanese chapter_2_cd0eb4da:

    # manor_owner_char "Hello heroes! I'm sorry to call you so suddenly, did you happen to receive a message from the Phantom Thief?"
    manor_owner_char "ごきげんよう、ヒーローの皆さん！ 急に電話してごめんなさい。\nもしかして、怪盗からメッセージが届いたかしら？"

# game/chapter2.rpy:73
translate japanese chapter_2_d2e36568:

    # vanta_char "Hello ma'am. Yes, we did! We are just about to inform you and head over."
    vanta_char "どうも、ご婦人。はい、届いてますよ！ \nこれから連絡して、そちらに向かうところでした。"

# game/chapter2.rpy:74
translate japanese chapter_2_94ef8721:

    # "There's a small pause on the other end, like she is carefully choosing her words."
    "電話の向こうで、彼女が一瞬言葉を選ぶように沈黙する。"

# game/chapter2.rpy:77
translate japanese chapter_2_86993953:

    # manor_owner_char "He was never caught. If this message really is from him... I... I need you here immediately! You must protect the painting! Please!"
    manor_owner_char "彼は一度も捕まらなかった。\nもし今回のメッセージが本物なら…すぐに来てちょうだい！ 絶対に絵を守って！"

# game/chapter2.rpy:78
translate japanese chapter_2_6d97fde4:

    # "Her voice rises with panic."
    "彼女の声が焦りと不安で震え始める。"

# game/chapter2.rpy:79
translate japanese chapter_2_2b6f5188:

    # manor_owner_char "What if our security isn't enough? What if he's already planted traps? What if he lied about the date and—oh my god, what if the painting is already gone?! I need to check—"
    manor_owner_char "もし警備が不十分だったら？ もしもう仕掛けが施されていたら？ それに…もし日付が嘘だったら？ もしすでに絵が盗まれていたら―！？\n今すぐ確認しなきゃ…！"

# game/chapter2.rpy:84
translate japanese chapter_2_d40f2158:

    # zali_char "S'il vous plaît, madam. Take a deep breath. Rest assured, Krisis is on the case."
    zali_char "S'il vous plaît,（お願いします） マダム。\n落ち着いて、深呼吸を。安心してください、我々クライシスが既に動いています。"

# game/chapter2.rpy:86
translate japanese chapter_2_da561393:

    # wilson_char "We'll be there shortly. If this Phantom Thief is really back, he won't be getting away so easily this time."
    wilson_char "すぐに現地に向かいます。\nもし本当にあの怪盗が戻ってきたのなら、今度はそう簡単には逃がしませんよ。"

# game/chapter2.rpy:88
translate japanese chapter_2_c10298a6:

    # vanta_char "Exactly. We've got this. We're heading there now."
    vanta_char "その通り。俺たちに任せてください。今すぐ向かいます。"

# game/chapter2.rpy:97
translate japanese chapter_2_b218734d:

    # manor_owner_char "Ah, Krisis! You got here fast, I am so glad. I want to tell you about my perfect plan to stop the Phantom Thief!"
    manor_owner_char "ああ、クライシス！ 早く来てくれて本当に嬉しいわ。\n実は、怪盗を止めるための完璧な作戦を考えたの！"

# game/chapter2.rpy:101
translate japanese chapter_2_ce8d246b:

    # zali_char "Okay great, walk us through your plan!"
    zali_char "いいですね、では作戦のご説明を。"

# game/chapter2.rpy:102
translate japanese chapter_2_9f7d9eb5:

    # manor_owner_char "Alright! So, when I was planning this party, I thought—why not bring in some entertainment? A comedy show sounded like a great idea!"
    manor_owner_char "ええ！パーティーを計画しているときに思ったの。\n「せっかくだし、エンターテイメントも用意しよう！」ってね。\nコメディショーなんて最高だと思わない？"

# game/chapter2.rpy:104
translate japanese chapter_2_3142bad4:

    # manor_owner_char "He should be arriving any moment now. Oh, you're going to love him—I promise."
    manor_owner_char "彼はもうすぐ到着するはず。きっと気に入るわ、私が保証する。"

# game/chapter2.rpy:105
translate japanese chapter_2_ff5c7705:

    # manor_owner_char "Now, here's the plan. I need all of you to go undercover—either as party staff or as guests. This way, the Phantom Thief won't know exactly who I've hired for security."
    manor_owner_char "さて、作戦の説明に入りましょ。\nあなたたちにはパーティースタッフかゲストのどちらかに変装してもらうわ。\nこうすれば、怪盗も私が雇った警備の正体までは分からないはずよ。"

# game/chapter2.rpy:112
translate japanese chapter_2_49749631:

    # "Before you can finish your thoughts, the sound of the door creaking open behind you makes you turn instinctively."
    "考えをまとめる前に、背後でドアがきしむ音がして、思わず振り返る。"

# game/chapter2.rpy:113
translate japanese chapter_2_3f233464:

    # "First, you see sleek brown shoes. Then, a red-and-blue plaid suit, layered under a stylish brown coat. Your gaze travels upward, and your breath catches—"
    "まず目に入ったのは、洗練された茶色の革靴。次に、赤と青のチェック柄のスーツ。\nその上にはスタイリッシュなブラウンのコートが重ねられている。\n視線を上げた瞬間、息をのむ―"

# game/chapter2.rpy:126
translate japanese chapter_2_297349f3:

    # zali_char "Wow! Mana-san? I did not expect to see you here of all places! You are, of course, a world class comedian."
    zali_char "わっ！マナさん！？まさかこんなところで会うなんて！\nさすがは世界的コメディアンだね。"

# game/chapter2.rpy:128
translate japanese chapter_2_0e22cc5f:

    # mana_char "Haha, yeah! Hello Krisis boys! Bet you didn't see this one coming. Surprise!"
    mana_char "ハハッ、そやな！やあ、クライシスの諸君！\nまさかここで俺に会うとは思わんかったやろ？サプラーイズ！"

# game/chapter2.rpy:130
translate japanese chapter_2_551ab7cc:

    # "All of you exchange happy smiles before pulling him into a quick group hug. A JP hero was the last thing you expected to meet in France—but that only makes it more exciting. Getting to work alongside Mana is a rare opportunity."
    "みんなで嬉しそうに笑い合いながら、彼を囲んで抱き合う。\nまさかフランスで日本のヒーローに会うなんて思ってもみなかった。\nだからこそ、余計にワクワクする。マナと一緒に仕事ができるなんて、滅多にないチャンスだ。"

# game/chapter2.rpy:135
translate japanese chapter_2_f29d9f6e:

    # "You chuckle and swing an arm over Mana's shoulder."
    "笑いながら、マナの肩に腕を回す。"

# game/chapter2.rpy:137
translate japanese chapter_2_e63ac733:

    # vanta_char "You could say he's like our brother from another country. We may be in different divisions, but we've had each other's backs before."
    vanta_char "まあ、言うなれば異国の兄弟みたいなもんさ。\n所属は違っても、何度か助け合ったことがあるんだ。"

# game/chapter2.rpy:151
translate japanese chapter_2_0c9f7996:

    # manor_owner_char "Alright, let's head to the dining room, enjoy a good meal and finalize the plan for the day."
    manor_owner_char "よし、それじゃあダイニングルームに向かいましょう。\nしっかり食事を取って、今日の作戦の最終確認をするわよ。"

# game/chapter2.rpy:160
translate japanese chapter_2_b5e5a287:

    # manor_owner_char "Your disguises are ready. We've prepared individual changing rooms for each of you, and the outfits have been tailored to your exact measurements. Put them on and let me know if anything needs adjusting."
    manor_owner_char "変装の準備はできているわ。\nそれぞれの個室を用意しておいたから、指定された衣装に着替えて。すべてあなたたちの体型にぴったり合わせて仕立ててあるわ。もし調整が必要なら、すぐに教えてちょうだい。"

# game/chapter2.rpy:161
translate japanese chapter_2_6b551562:

    # "With a nod, the three of you step into your assigned rooms, while Mana waits outside."
    "軽く頷き、三人はそれぞれの部屋へと足を踏み入れた。マナは外で待機する。"

# game/chapter2.rpy:165
translate japanese chapter_2_1a585efc:

    # "Mana, fitting seamlessly into his outfit, will attend as an esteemed guest. Meanwhile, Krisis will blend in as staff, working behind the scenes."
    "マナは違和感なく衣装を着こなし、名誉あるゲストとして参加する。\n一方、クライシスはスタッフとして紛れ込み、裏方で動くことになった。"

# game/chapter2.rpy:173
translate japanese chapter_2_abaafedf:

    # "While waiting for Krisis to change, Mana exhales and adjusts his cuffs, taking in the grand surroundings. He doesn't need a disguise—his presence alone grants him access."
    "クライシスの三人が着替えている間、マナは息を吐き、袖口を整えながら、豪華な内装をじっくりと眺める。彼には変装の必要はない。彼の存在そのものが、すでに招待状の代わりとなるからだ。"

# game/chapter2.rpy:174
translate japanese chapter_2_04c7885b:

    # "But then—silence."
    "だが―静寂。"

# game/chapter2.rpy:176
translate japanese chapter_2_5fcf6278:

    # "Mana glances at the other doors, his brows furrowing slightly. Why are they taking so long?"
    "マナはほかのドアに目をやり、少し眉をひそめる。\n―どうしてこんなに時間がかかってるんだ？"

# game/chapter2.rpy:180
translate japanese chapter_2_77d65967:

    # "No response."
    "返事はない。"

# game/chapter2.rpy:181
translate japanese chapter_2_c4e27b1f:

    # "Then—slowly, hesitantly, the doors creak open."
    "次の瞬間―ゆっくりと、ためらいがちに、扉が軋みながら開いていく。"

# game/chapter2.rpy:207
translate japanese chapter_2_7c879c27:

    # "Mana tries—and fails—to suppress a snicker, laughter bubbling out as he takes in the expressions on all of your faces."
    "マナは必死に笑いをこらえようとするが、結局抑えきれず、吹き出してしまう。\nクライシスの三人の表情を見て、ますます笑いが止まらない。"

# game/chapter2.rpy:214
translate japanese chapter_2_acd63970:

    # manor_owner_char "Oh, did I forget to mention the exact roles? Must've slipped my mind. But look at you three—absolutely fabulous!"
    manor_owner_char "あら、ごめんなさい。具体的な役職について言い忘れたかしら？ うっかりしてたわね。\nでも見て、あなたたち三人…最高に素敵じゃない！"

# game/chapter2.rpy:217
translate japanese chapter_2_e0193d76:

    # mana_char "I have to say... You all look amazing. I am in awe... Especially Wilson..."
    mana_char "いや、本当に…すごいわ…特にウィルソン…"

# game/chapter2.rpy:221
translate japanese chapter_2_a6cacfe2:

    # "Realizing there's no way out, you accept your fate and commit to the maid spirit."
    "逃げ道がないことを悟り、観念して 『メイドの心』 を受け入れる。\nこうなったら、もうやるしかない。"

# game/chapter2.rpy:223
translate japanese chapter_2_1d2f6b81:

    # "And speaking of which..."
    "それはそうと…"

# game/chapter2.rpy:227
translate japanese chapter_2_45d22fa5:

    # wilson_char "Mana, you haven't seen the Real painting in person before, have you? Trust me, you need to. It's a masterpiece."
    wilson_char "マナ、君は『Real』 を実際に見たことはないだろ？ \n絶対に一度は見ておくべきだよ。間違いなく傑作だから。"

# game/chapter2.rpy:228
translate japanese chapter_2_71e9e128:

    # mana_char "I haven't, but I'd love to!"
    mana_char "まだ見たことないけど、興味あるな！ めっちゃ見たいわ。"

# game/chapter2.rpy:234
translate japanese chapter_2_dd02bf42:

    # "The four of you make your way to where the renowned painting is displayed in all its glory."
    "四人は絵が展示されている部屋へと向かう。そこには、名高きアートが堂々と飾られていた。"

# game/chapter2.rpy:236
translate japanese chapter_2_902e9e8e:

    # "He steps in closer, his gaze tracing the intricate details."
    "ゆっくりと歩み寄り、細部をじっくりと追う。"

# game/chapter2.rpy:249
translate japanese chapter_2_837aa7af:

    # mana_char "Zali! Zali! Zali!"
    mana_char "ザリ！ ザリ！ ザリ！"

# game/chapter2.rpy:257
translate japanese chapter_2_3c3a1e3d:

    # "Both Wilson and you hear Mana's voice through the earpiece. The three of you exchange glances but keep your expressions neutral. Trying not to show any signs of distress, you maintain your professional smiles."
    "マナの声がイヤホンを通して聞こえ、ウィルソンとあなたはすぐに目を合わせる。\nしかし、表情は変えず、平静を装ったままプロとしての笑顔を保つ。"

# game/chapter2.rpy:260
translate japanese chapter_2_f94b08a7:

    # "Zali and Mana lift the painting off the wall, carefully carrying it toward a secluded corner of the room, away from the guests. They turn the painting over, eyes locking onto the red light pulsing behind it."
    "ザリとマナは慎重に額縁を持ち上げ、人目につかない部屋の隅へと運ぶ。\n裏返すと、赤い光が静かに点滅しているのが目に入る。"

# game/chapter2.rpy:261
translate japanese chapter_2_e53bb798:

    # zali_char "Mana, the last time we defused this type of bomb—"
    zali_char "マナ、このタイプの爆弾を解除したときって―"

# game/chapter2.rpy:269
translate japanese chapter_2_676a0f7e:

    # "All of a sudden, the room goes dark. Panic erupts as people scramble, bumping into each other in confusion."
    "突然、部屋が真っ暗になる。\n一瞬にしてパニックが広がり、ゲストたちは混乱しながら互いにぶつかり合う。"

# game/chapter2.rpy:270
translate japanese chapter_2_7499b5bf:

    # mana_char "わあ—これは最悪や..."
    mana_char "わあ―これは最悪や…"

# game/chapter2.rpy:271
translate japanese chapter_2_595e79d1:

    # "Mana and Zali freeze, they immediately scanning for a source of light—without it, defusing the bomb would be impossible."
    "マナとザリは即座に動きを止め、光源を探す。\nしかし、暗闇の中では爆弾の解除は不可能に近い。"

# game/chapter2.rpy:278
translate japanese chapter_2_f7caeab6:

    # "Despite the darkness making it hard to see, you and Wilson remain steady, expertly weaving through the frantic crowd."
    "視界が悪いにもかかわらず、あなたとウィルソンは冷静に動き、混乱する人々の間をすり抜ける。"

# game/chapter2.rpy:279
translate japanese chapter_2_b5721e12:

    # wilson_char "Any idea where the fuse box could be?"
    wilson_char "ブレーカーの場所、心当たりあるか？"

# game/chapter2.rpy:280
translate japanese chapter_2_93489e66:

    # vanta_char "Not really! Your guess is as good as mine."
    vanta_char "いや、俺も分かんねぇよ。"

# game/chapter2.rpy:281
translate japanese chapter_2_8a28c5b6:

    # wilson_char "Let's try the kitchen first!"
    wilson_char "まずはキッチンを探ってみよう！"

# game/chapter2.rpy:282
translate japanese chapter_2_ffcfd1a6:

    # vanta_char "... You just want food, don't you?"
    vanta_char "…お前、ただ飯が食いたいだけだろ？"

# game/chapter2.rpy:284
translate japanese chapter_2_7d56aa8c:

    # vanta_char "Alright then! Let's go!"
    vanta_char "よし、行こう！"

# game/chapter2.rpy:301
translate japanese chapter_2_24285394:

    # "The moment the price is mentioned, Mana's eyes widen—this was a setup. He wastes no time, relaying new orders to the team."
    "値段が告げられた瞬間、マナの目が見開かれる。―これは仕組まれた罠だ。\n彼は一瞬の迷いもなく、新たな指示を出す。"

# game/chapter2.rpy:305
translate japanese chapter_2_c2f6e37a:

    # vanta_char "God dammit! On it! Willy, You got the fuse box?"
    vanta_char "くそっ！了解！ウィリー、ブレーカーの方はどうだ？"

# game/chapter2.rpy:307
translate japanese chapter_2_711c4fe3:

    # wilson_char "Yup! Leave it to me!"
    wilson_char "ああ！任せてよ！"

# game/chapter2.rpy:308
translate japanese chapter_2_ef80ba16:

    # "The power is out, and the room is in chaos. You don't have time to wait for the lights to come back—every second wasted is a step closer to the thief escaping with the necklace."
    "停電により、部屋は混乱の渦に包まれる。明かりが戻るのを待つ時間はない―\n一秒の遅れが、怪盗の逃亡を許すことになる。"

# game/chapter2.rpy:309
translate japanese chapter_2_e965ee05:

    # "You and Wilson split up—he rushes to restore power, while you push through the frantic crowd, barely dodging guests scrambling in all directions."
    "あなたとウィルソンは二手に分かれ、彼は電力の復旧へと向かい、あなたは混乱する群衆の中を突き進む。逃げ惑うゲストたちをギリギリで避けながら、視界の悪い中を進む。"

# game/chapter2.rpy:310
translate japanese chapter_2_4c21c570:

    # "The darkness makes it impossible to see clearly, but you don't need to. The thief is moving fast—you just have to be faster."
    "だが、はっきりと見る必要はない。怪盗は速い―ならば、それより速く動くだけだ。"

# game/chapter2.rpy:319
translate japanese chapter_2_e17a6394:

    # "Then, resistance. His dress jerks him to a sudden stop."
    "その時、抵抗を感じ、突然動きが止まった。"

# game/chapter2.rpy:320
translate japanese chapter_2_6d9ee4f9:

    # "He glances back and realizes—the blade of a decorative suit of armor has caught the fabric, pinning him in place."
    "振り返ると、装飾用の甲冑の剣がドレスの布を引っ掛け、完全に動きを封じていた。"

# game/chapter2.rpy:333
translate japanese chapter_2_e2edd319:

    # wilson_char "Great. Just great. First, I get assaulted by medieval decor, and now my dress is ruined."
    wilson_char "最高だな、本当に。中世のインテリアに襲われた挙句、今度はドレスまで台無しだ。"

# game/chapter2.rpy:336
translate japanese chapter_2_02a2e70b:

    # "Before he can complain further, Zali's voice crackles through his earpiece."
    "さらに文句を言おうとした瞬間、イヤホンからザリの声が飛び込んできた。"

# game/chapter2.rpy:339
translate japanese chapter_2_a3b12c99:

    # zali_char "Wilson! How long is it going to take you to get to the fuse box? Mana and I don't have enough light sources to defuse the bomb!"
    zali_char "ウィルソン! ブレーカーまでどれくらいかかる!? \nマナと爆弾解除するには明かりが足りないんだ！"

# game/chapter2.rpy:342
translate japanese chapter_2_f9622474:

    # wilson_char "I think I'm getting there! Just give me a little more time to figure this out!"
    wilson_char "もう少しで着きそうだ！ ちょっとだけ時間をくれ！"

# game/chapter2.rpy:345
translate japanese chapter_2_f5f18738:

    # zali_char "Okay! Be quick, but also don't hurt yourself, okay?"
    zali_char "オッケイ! 急いで、でも怪我しないようにね？"

# game/chapter2.rpy:348
translate japanese chapter_2_d33e6f82:

    # "Wilson finally reaches the kitchen. The heat from inactive stoves lingers, making the air thick. He keeps his hand against the wall, feeling his way through—then, his fingers hit something solid."
    "ウィルソンはようやくキッチンにたどり着く。\n使われていないコンロからの熱がまだ残っていて、空気はむっとしている。\n壁づたいに手を滑らせながら進み、やがて指先が何か固いものに触れる。"

# game/chapter2.rpy:349
translate japanese chapter_2_0fd8737d:

    # "A fuse box. Miraculously—or maybe suspiciously—it's unlocked."
    "ブレーカーだ。奇跡的に―いや、不自然に―鍵はかかっていない。"

# game/chapter2.rpy:354
translate japanese chapter_2_wilson_qte_3e7b8ada:

    # wilson_char "Jesus Christ... Okay, right. Here goes nothing..."
    wilson_char "まじかよ… よし、やるしかないな…"

# game/chapter2.rpy:400
translate japanese chapter_2_wilson_timeout_6deeaad2:

    # "Sparks fly as Wilson fumbles with the switches, causing a momentary delay before the power finally surges back on."
    "ウィルソンがスイッチをまごつきながら操作すると、火花が散り、一瞬の遅れが生じる。しかし、ついに電力が復旧し、明かりが戻った。"

# game/chapter2.rpy:409
translate japanese chapter_2_wilson_clear_d5bfe298:

    # "The lights flicker once before steadily returning."
    "ライトが一度点滅した後、明るくなっていく。"

# game/chapter2.rpy:413
translate japanese chapter_2_2_138273e5:

    # "Wilson exhales, pushing the box shut as warm light spills through the halls."
    "ウィルソンは息を吐き、ブレーカーのカバーを閉じる。温かな光が廊下を照らし始める。"

# game/chapter2.rpy:414
translate japanese chapter_2_2_ea6d9e85:

    # wilson_char "Thank god that worked! Time to help the others!"
    wilson_char "助かった！ さあ、他のみんなを手伝わなきゃ！"

# game/chapter2.rpy:420
translate japanese chapter_2_2_ac34f0ab:

    # "On the bomb, four buttons are arranged in a square shape, their colors flashing in a specific sequence—one that feels eerily familiar—although, it's slightly different this time."
    "爆弾には四つのボタンが正方形に配置されており、それぞれの色が特定の順番で点滅している。\nどこかで見たようパターンだが、今回は少し違っている。"

# game/chapter2.rpy:422
translate japanese chapter_2_2_114e8abb:

    # mana_char "Wait, Zali... No way..."
    mana_char "待って、ザリ…まさか…"

# game/chapter2.rpy:425
translate japanese chapter_2_2_b3c1739e:

    # zali_char "Oh no... Ah, I see. Okay, I understand now."
    zali_char "やばい…ああ、なるほど もうわかった。"

# game/chapter2.rpy:426
translate japanese chapter_2_2_fa843437:

    # zali_char "We need to remember the order of the flashing colors, and press the exact same buttons."
    zali_char "点滅した色の順番を覚えて、同じボタンを正確に押さなきゃいけない。"

# game/chapter2.rpy:428
translate japanese chapter_2_2_7a6f8f21:

    # mana_char "Let's give it a go! I have faith in us, Zali!"
    mana_char "やってみよう！ザリ、俺たちならできるって信じてる！"

# game/chapter2.rpy:430
translate japanese chapter_2_2_88f7f61c:

    # "Zali takes a deep breath, steadying his nerves. He can't let the pressure get to him—\nhe has to lock in."
    "ザリは深く息を吸い込み、気持ちを落ち着かせる。\nこのプレッシャーに負けるわけにはいかない、集中しなければ。"

# game/chapter2.rpy:440
translate japanese chapter_2_zali_flashing_1_d77378df:

    # zali_char "I'm ready, Mana! Let's do this! It's flashing now..."
    zali_char "準備OKだ、マナ！やるぞ！ 今…点滅してる…！"

# game/chapter2.rpy:444
translate japanese chapter_2_zali_flashing_1_4efa4dca:

    # mana_char "Oh my god! Okay! I've got this!! Here I go..."
    mana_char "やばい！よし、いける！！ いくぞ…！"

# game/chapter2.rpy:467
translate japanese chapter_2_zali_flashing_2_4200fd78:

    # zali_char "Alright! That was great, Mana! Oh...there's more? Leave it to me!"
    zali_char "素晴らしい、マナ！ …え、まだ続くの？任せて！"

# game/chapter2.rpy:469
translate japanese chapter_2_zali_flashing_2_a24b8f10:

    # mana_char "Okay, okay!"
    mana_char "よし、よし！"

# game/chapter2.rpy:479
translate japanese chapter_2_zali_flashing_2_7498d02d:

    # manor_owner_char "My heroes! I was wondering if—"
    manor_owner_char "私のヒーローたち！ ちょっと聞きたいことが—"

# game/chapter2.rpy:485
translate japanese chapter_2_zali_flashing_2_6ab067bd:

    # zali_char "God dammit... Je suis désolé, I usually like ladies but not now! I need to focus!"
    zali_char "くっ…Je suis désolé（すまない）、私は普段はレディが好きだけど今は違う！集中しないと！"

# game/chapter2.rpy:511
translate japanese chapter_2_zali_flashing_3_29893eee:

    # zali_char "Oh my god, that was close. I almost lost my cool..."
    zali_char "やばかった…もう少しで冷静さを失うところだった…"

# game/chapter2.rpy:514
translate japanese chapter_2_zali_flashing_3_5c433f7d:

    # "However, the bomb is still ticking. Zali and Mana take another deep breath."
    "しかし、爆弾はまだカウントダウンを続けている。ザリとマナは深く息を吸い込む。"

# game/chapter2.rpy:520
translate japanese chapter_2_zali_flashing_3_f4fcfa34:

    # zali_char "Wait, was that yellow, blue, blue? or yellow, red, blue?"
    zali_char "待てよ、黄色、青、青？それとも黄色、赤、青？"

# game/chapter2.rpy:521
translate japanese chapter_2_zali_flashing_3_8b6c12dc:

    # mana_char "Hmmm... Was there a red? Or it could be yellow, red, yellow, blue?"
    mana_char "うーん…赤なんてあったか？ いや、黄色、赤、黄色、青だったかも？"

# game/chapter2.rpy:523
translate japanese chapter_2_zali_flashing_3_c6c5f9e4:

    # zali_char "No... I was pretty sure there was... Ahhh!! This is so hard! My memory!"
    zali_char "違う…確かにあったはず…あぁぁ！！\nこんなの無理だよ！記憶が…！"

# game/chapter2.rpy:548
translate japanese chapter_2_zali_timeout_7d12e17a:

    # "The red light flashes violently as the device lets out a sharp, high-pitched whine. Mana's breath catches—"
    "赤いランプが激しく点滅し、装置が鋭く甲高い音を発する。\nマナは息を呑む―"

# game/chapter2.rpy:558
translate japanese chapter_2_zali_failed_56b2fb1e:

    # "A wrong button was pressed. For a split second, nothing happens. Then—"
    "間違ったボタンが押された。\n一瞬、何も起こらない。そして―"

# game/chapter2.rpy:560
translate japanese chapter_2_zali_failed_7d12e17a:

    # "The red light flashes violently as the device lets out a sharp, high-pitched whine. Mana's breath catches—"
    "赤いランプが激しく点滅し、装置が鋭く甲高い音を発する。マナは息を呑む―"

# game/chapter2.rpy:562
translate japanese chapter_2_zali_failed_f3985afb:

    # mana_char "ZALI—!!!"
    mana_char "ザリーーーッ！！！"

# game/chapter2.rpy:578
translate japanese chapter_2_zali_clear_5d9615a0:

    # "Zali gently sets the bomb down before instantly pulling Mana into a tight hug. The two heroes cheer, letting out a collective sigh as the weight of the moment washes over them."
    "ザリはそっと爆弾を床に置くと、すぐにマナを強く抱きしめた。\n二人のヒーローは歓声を上げ、緊張が一気に解ける。"

# game/chapter2.rpy:579
translate japanese chapter_2_zali_clear_4d52d222:

    # zali_char "Oh my goodness! We actually did it!"
    zali_char "やった…！本当に解除できた…！"

# game/chapter2.rpy:580
translate japanese chapter_2_zali_clear_6ee31ce3:

    # mana_char "Was there ever any doubt? We always got this!"
    mana_char "疑いの余地なんてあったか？俺たちなら、いつだって成功するさ！"

# game/chapter2.rpy:581
translate japanese chapter_2_zali_clear_85fbbfa3:

    # "Only one thing left to do—for you to catch the Phantom Thief."
    "残るはただ一つ—怪盗を捕まえることだ！"

# game/chapter2.rpy:586
translate japanese chapter_2_zali_clear_d2f9d838:

    # vanta_char "Alright! You're not going anywhere! Not on my watch!"
    vanta_char "よし！逃がしはしない！俺が見てる限りはな！"

# game/chapter2.rpy:624
translate japanese chapter_2_vanta_1_2_7cd632d9:

    # "You keep moving, eyes locked on the thief. They're fast, but you follow closely."
    "あなたは怪盗から目を離さず進み続ける。\n相手は素早いが、あなたもすぐ後を追う。"

# game/chapter2.rpy:661
translate japanese chapter_2_vanta_2_1_4d1d94a0:

    # "You don't think. You just move. You just ball the hell out."
    "考える暇なんてない。ただ動く。ただ全力でぶつかっていく。"

# game/chapter2.rpy:666
translate japanese chapter_2_vanta_2_1_9d89efb7:

    # "You land in a crouch—just ahead of the thief."
    "しゃがみ込むように着地した場所は、ちょうど泥棒の目の前だ。"

# game/chapter2.rpy:677
translate japanese chapter_2_vanta_2_2_b7442eab:

    # "Through sheer determination, you push forward, closing the gap. The moment you see an opening, you bolt ahead and lunge, tackling the thief to the ground with all the strength you have left."
    "強い意志で前へと進み、距離を詰める。\n隙を見つけたその瞬間、全力で駆け出し、残された力を振り絞って怪盗に飛びかかり、地面に押さえつける。"

# game/chapter2.rpy:686
translate japanese chapter_2_vanta_timeout_2_e63eb21f:

    # "You push harder, legs burning as you sprint toward the exit. The thief is just ahead, slipping through the doorway. You grit your teeth and force your body to keep moving."
    "あなたはさらに力を込め、脚が焼けるように痛む中、出口へ向かって全力で駆ける。\n怪盗はすぐ目の前、扉の隙間をすり抜けようとしている。\nあなたは歯を食いしばり、体を無理やり動かし続けた。"

# game/chapter2.rpy:688
translate japanese chapter_2_vanta_timeout_2_b7442eab:

    # "Through sheer determination, you push forward, closing the gap. The moment you see an opening, you bolt ahead and lunge, tackling the thief to the ground with all the strength you have left."
    "強い意志で前へと進み、距離を詰める。\n隙を見つけたその瞬間、全力で駆け出し、残された力を振り絞って怪盗に飛びかかり、地面に押さえつける。"

# game/chapter2.rpy:698
translate japanese chapter_2_3_94faa639:

    # "Without hesitation, you push forward and lunge, wrapping your arms around them and slamming them to the ground."
    "ためらうことなく前に踏み込んで飛びかかり、相手を腕で抱え込んでそのまま地面に叩きつける。"

# game/chapter2.rpy:699
translate japanese chapter_2_3_e765b40e:

    # vanta_char "Game over, thief!"
    vanta_char "ゲームオーバーだ、怪盗！"

# game/chapter2.rpy:712
translate japanese chapter_2_3_bcc39804:

    # manor_owner_char "Oh my god! You actually caught the Phantom Thief!"
    manor_owner_char "まぁ！本当に怪盗を捕まえたの！？"

# game/chapter2.rpy:714
translate japanese chapter_2_3_0e29d2d5:

    # zali_char "Now that was very impressive, Vanta!"
    zali_char "いやぁ、すごいよベンタ！"

# game/chapter2.rpy:717
translate japanese chapter_2_3_f45cf538:

    # mana_char "Ah! As expected from the tyrant and the trusted Ace!"
    mana_char "さすがは暴君で信頼のエース！"

# game/chapter2.rpy:720
translate japanese chapter_2_3_c8e13159:

    # wilson_char "And in a maid dress? Holy—"
    wilson_char "しかもメイド服で！？ マジかよ—！"

# game/chapter2.rpy:731
translate japanese chapter_2_3_6af512af:

    # mana_char "Krisis, consider this your formal invitation to Japan. We, Oriens and Dytica are celebrating our second anniversary together, and you're on the guest list, of course."
    mana_char "クライシス、これは日本への招待状や。\nオリエンスとディティカが二周年のお祝いをするんやけど、もちろんクライシスにも来てほしい。"

# game/chapter2.rpy:743
translate japanese chapter_2_3_22877bd6:

    # "You take the invitation and tuck it into the pocket of your maid outfit. This mission was a great success, and one thing's certain—Krisis is going to Japan!"
    "あなたは招待状をメイド服のポケットにしまう。この任務は大成功だった。\nそして、ひとつだけ確かなことがある—クライシス、日本へ行く！"

translate japanese strings:

    # game/chapter2.rpy:604
    old "Jump Over"
    new "テーブルを越える"

    # game/chapter2.rpy:605
    old "Push Through"
    new "突き進む"

    # game/chapter2.rpy:653
    old "Jump Through"
    new "窓を突き破る"

    # game/chapter2.rpy:654
    old "Take the Door"
    new "扉へ向かう"# TODO: Translation updated at 2025-06-14 23:40

# game/chapter2.rpy:75
translate japanese chapter_2_a19464af:

    # vanta_char "Hello ma'am. Yes, we did! We were just about to inform you and head over."
    vanta_char "どうも、ご婦人。はい、届いてますよ！ \nちょうど今ご報告に伺おうとしていたところです。"

# game/chapter2.rpy:133
translate japanese chapter_2_efc8853d:

    # "All of you exchange happy smiles before pulling him into a quick group hug. A JP hero was the last person you expected to meet in France—but that only makes it more exciting. Getting to work alongside Mana is a rare opportunity."
    "みんなで嬉しそうに笑い合いながら、彼を囲んで抱き合う。まさかフランスで日本のヒーローに会うなんて思ってもみなかった。だからこそ、余計にワクワクする。マナと一緒に仕事ができるなんて、滅多にないチャンスだ。"

# game/chapter2.rpy:276
translate japanese chapter_2_647d5ec7:

    # "Mana and Zali freeze, they immediately start scanning for a source of light—without it, defusing the bomb would be impossible."
    "マナとザリは即座に動きを止め、光源を探す。\nしかし、暗闇の中では爆弾の解除は不可能に近い。"

# game/chapter2.rpy:762
translate japanese chapter_2_3_ff7241d9:

    # zali_char "Well, Vanta? What do you think? We haven't been to Japan together in a while, have we?"
    zali_char "どう、ベンタ？一緒に日本に行くのは、久しぶりだよね？"

