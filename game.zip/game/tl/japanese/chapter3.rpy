﻿# TODO: Translation updated at 2025-05-21 11:46

# game/chapter3.rpy:11
translate japanese chapter_3_93d3af88:

    # "The grand lobby of International Heroes HQ buzzes with acitivity. Buntings hang overhead, congratulatory banners stretch across the walls, and a faint chorus of laughter and chatter echoes through the halls."
    "国際ヒーロー本部の広々としたロビーは活気に満ちていた。\n頭上には旗が飾られ、壁一面には祝賀のバナーが掲げられ、廊下には笑い声と談笑がかすかに響いている。"

# game/chapter3.rpy:12
translate japanese chapter_3_7e8a587c:

    # "Two years. Somehow, it's already been two years since all eleven of you became heroes."
    "あれからもう二年。\n気づけば、十一人全員がヒーローになってから二年が経っていた。"

# game/chapter3.rpy:15
translate japanese chapter_3_17c17832:

    # wilson_char "Wow, it's been a while since we last came here. They've upgraded so many facilities."
    wilson_char "わあ、ここに来るの久しぶりだね。いろんな設備がアップグレードされてる。"

# game/chapter3.rpy:16
translate japanese chapter_3_0253491a:

    # wilson_char "Celebrating our two-year mark here feels kinda perfect, huh?"
    wilson_char "ここで二周年を祝えるなんて、なんかピッタリって感じじゃない？"

# game/chapter3.rpy:20
translate japanese chapter_3_d579ea62:

    # zali_char "Definitely! I miss Japan. Wait—where is Vanta?"
    zali_char "そうだね！日本が恋しかったよ。\n…って、あれ？べンタはどこ？"

# game/chapter3.rpy:21
translate japanese chapter_3_edd3de8c:

    # "Zali glances around and calls down the hallway."
    "ザリはあたりを見回し、廊下に向かって呼びかける。"

# game/chapter3.rpy:23
translate japanese chapter_3_b91f0ef7:

    # zali_char "Van~~ta~~ Are you coming with us?"
    zali_char "ベ〜ンタ〜〜 一緒に行く？"

# game/chapter3.rpy:27
translate japanese chapter_3_c021274f:

    # "A loud bang echoes from down the hall."
    "廊下からドン！と大きな音が響く。"

# game/chapter3.rpy:32
translate japanese chapter_3_de678d72:

    # vanta_char "Yes! I am coming!"
    vanta_char "はーい！今行く～！"

# game/chapter3.rpy:33
translate japanese chapter_3_86d439b2:

    # vanta_char "Shi—I mean, I'll be there in just a second."
    vanta_char "っ―じゃ、じゃなくて、すぐ向かう！"

# game/chapter3.rpy:34
translate japanese chapter_3_6d4edd11:

    # "You jog toward Zali and Wilson."
    "あなたはザリとウィルソンの方へ小走りで向かう。"

# game/chapter3.rpy:36
translate japanese chapter_3_2ab19e79:

    # vanta_char "Sorry guys! Phew, that was close. I was just grabbing my bag, then Usami showed up and—well, we ended up arm wrestling."
    vanta_char "ごめんみんな！ふぅ、危なかった〜。\nちょっとバッグを取りに戻ったら、宇佐美が来てさ―で、気づいたら腕相撲してた。"

# game/chapter3.rpy:37
translate japanese chapter_3_e9e56453:

    # wilson_char "That bang was you and Usami?"
    wilson_char "あのドン！って音、お前と宇佐美だったの？"

# game/chapter3.rpy:38
translate japanese chapter_3_e2152249:

    # vanta_char "Yeah! We kind of...cracked the table in half, haha. No winner, but hey—we ball. We will rematch someday."
    vanta_char "あぁ！ちょっと…テーブル真っ二つにしちゃった、はは。勝敗はなし。\nでもまあ、楽しかったし！いつかリベンジするよ。"

# game/chapter3.rpy:46
translate japanese chapter_3_15a213bf:

    # rai_char "{size=40}Yu!{/size} Ah! There you are—I thought you'd already left!"
    rai_char "ユウ！あっ、いた！もう出発しちゃったのかと思ったよ！"

# game/chapter3.rpy:50
translate japanese chapter_3_31a1201e:

    # wilson_char "Rai! I am still here. What's up?"
    wilson_char "ライ！まだいるよ。どうかしたの？"

# game/chapter3.rpy:51
translate japanese chapter_3_f5dcb5b7:

    # rai_char "Just wanted to give you guys these~"
    rai_char "これ、君たちに渡したくて。"

# game/chapter3.rpy:52
translate japanese chapter_3_1aa190d7:

    # "Rai hands over three elegant-looking envelopes."
    "ライは、上品なデザインの封筒を三つ差し出した。"

# game/chapter3.rpy:53
translate japanese chapter_3_de9d38f5:

    # wilson_char "Wait... Onsen passes? Really? Hazukashi... That's so kind of you, Chu!"
    wilson_char "えっ…温泉の入場券？本当に？\nは、恥ずかしい…でもありがとう、Chu！優しすぎるよ！"

# game/chapter3.rpy:57
translate japanese chapter_3_9bf2663e:

    # vanta_char "On god on god? For real for real?"
    vanta_char "マジでマジで？ガチのガチ？"

# game/chapter3.rpy:58
translate japanese chapter_3_cba1b453:

    # rai_char "Krisis has really put in the work this year. After everything that went down in Canada and France—that was crazy!"
    rai_char "クライシスは今年ほんとによく頑張ったよ。\n特にカナダとフランスであんなことがあったのに—あれはマジでやばかった！"

# game/chapter3.rpy:60
translate japanese chapter_3_e4219a33:

    # rai_char "Before tonight's celebration, take a breather, go relax. This place has a great reputation. Trust me!"
    rai_char "今夜のパーティの前に、少しリラックスしてきなよ。この温泉、評判いいんだよ。"

# game/chapter3.rpy:61
translate japanese chapter_3_36820381:

    # rai_char "Enjoy yourselves! I'll see Yu later at the party!"
    rai_char "楽しんできて！パーティでまた会おうね！"

# game/chapter3.rpy:64
translate japanese chapter_3_38315fec:

    # vandz_char "Woah! Thank you so much Rai!"
    vandz_char "わぁ～！ライ、本当にありがとう！"

# game/chapter3.rpy:71
translate japanese chapter_3_fd2d6213:

    # "You arrive at the onsen ryokan. The building stands quietly against a backdrop of gentle hills and swaying trees, its wooden beams and tiled roof exuding a timeless charm.\nA warm scent of cedar and minerals fills the air, welcoming you in."
    "あなたは温泉旅館に到着する。\n穏やかな丘と風に揺れる木々を背に、建物はひっそりと佇んでいた。木造の梁と瓦屋根が、どこか懐かしくも趣のある雰囲気を漂わせていて、杉の香りと温泉の鉱物の匂いがほんのりと漂い、あなたを優しく迎え入れる。"

# game/chapter3.rpy:72
translate japanese chapter_3_9ad10120:

    # "Slipping off your shoes at the entrance, you're guided down polished tatami-lined hallways by a cheerful staff member. The air inside is calm and still—the only sounds are the trickle of water and the occasional distant splash."
    "玄関で靴を脱ぐと、明るいスタッフに案内されて、磨き上げられた畳敷きの廊下を進んでいく。\n館内の空気は静かで落ち着いており、聞こえてくるのは水のせせらぎと、ときおり遠くで聞こえる水音だけ。"

# game/chapter3.rpy:76
translate japanese chapter_3_ae222b4d:

    # "Soon, you reach the changing room. Neatly arranged baskets, folded towels, and little wooden stools await. Steam curls from behind the curtains leading to the baths."
    "やがて、脱衣所にたどり着く。\n整然と並べられた籠、きれいに畳まれたタオル、そして小さな木の椅子が用意されていた。\nのれんの奥から湯けむりがゆるやかに立ち上っている。"

# game/chapter3.rpy:79
translate japanese chapter_3_0bc3acad:

    # vanta_char "Man, Rai was so nice giving us those onsen passes. Wilson... Just saying, Rai really likes you."
    vanta_char "ライが温泉のチケットくれたの、マジで優しかったよなぁ。\nウィルソン、ライって本当にお前のことが好きなんだと思うよ。"

# game/chapter3.rpy:83
translate japanese chapter_3_a942a0c8:

    # wilson_char "I know! I really like Rai, too! For real. I could use some goooood cracking down my spine."
    wilson_char "知ってるよ！僕もライのこと本当に好き、マジで！\nあー背骨がバキバキ鳴るくらい、いい感じにほぐされちゃおっかな〜。"

# game/chapter3.rpy:85
translate japanese chapter_3_06319f41:

    # "Wilson stretches dramatically—several joints cracking like nobody's business."
    "ウィルソンが大げさに体を伸ばすと、いくつもの関節がポキポキと鳴る。"

# game/chapter3.rpy:86
translate japanese chapter_3_cf5fe4d5:

    # vanta_char "Sheesh, Wilson. You sound like a microwave full of popcorn."
    vanta_char "おいウィルソン、それレンジでポップコーン作ってる時の音じゃん。"

# game/chapter3.rpy:90
translate japanese chapter_3_349c5c62:

    # zali_char "You want me to give you a massage after this, Wilson?"
    zali_char "あとでマッサージしてあげようか、ウィルソン？"

# game/chapter3.rpy:91
translate japanese chapter_3_91edb3f6:

    # wilson_char "YES! Zali, I know you always have my back, literally. Hehe, did you get it?"
    wilson_char "YES！ザリ、お前はいつも僕の背中を支えてくれる、文字通り！\nへへっ、今のわかった？"

# game/chapter3.rpy:95
translate japanese chapter_3_e5f9bdd2:

    # vanta_char "{size=45}Gay~~~{/size}"
    vanta_char "…夫婦か？"

# game/chapter3.rpy:103
translate japanese chapter_3_678ce885:

    # "You step into the changing room and start undressing. Zali is already ahead of you, wrapping his towel with effortless grace. Wilson hums as he follows suit, loosely tying his towel around his waist."
    "あなたは脱衣所に入り、服を脱ぎ始める。\nザリはす一足先に進んでいて、タオルを優雅に巻いていた。\nウィルソンは鼻歌まじりに後に続き、腰にタオルをゆるく巻きつける。"

# game/chapter3.rpy:104
translate japanese chapter_3_5a47de19:

    # "Then...you stare at your towel."
    "そして…あなたは自分のタオルをじっと見つめた。"

# game/chapter3.rpy:108
translate japanese chapter_3_68c6b9bd:

    # "You pick it up. Hold it out. Turn it around. Shake it once, shake it again, just in case it magically decides to get bigger."
    "それを手に取る。前にかざしてみる。ひっくり返してみる。一度振ってみる。もう一度振ってみる。もしかして、魔法みたいに大きくなるんじゃないかって期待して。"

# game/chapter3.rpy:109
translate japanese chapter_3_a42cd0d0:

    # vanta_char "Uhh. Is it just me, or is this towel criminally small?"
    vanta_char "…え、これって俺だけ？このタオル、犯罪的に小さくない？"

# game/chapter3.rpy:110
translate japanese chapter_3_307180bf:

    # zali_char "Haha! No way it's that bad. Turn around, let's see..."
    zali_char "ははっ！まさかそんなにひどいわけないでしょ。ちょっと背中向けて、見せてみて…"

# game/chapter3.rpy:115
translate japanese chapter_3_be923412:

    # "You turn around, revealing that the towel barely covers your behind—just one wrong move away from full exposure."
    "あなたはくるっと振り返る。\nタオルはお尻をかろうじて隠している程度で、少しでも動けば完全にアウトだ。"

# game/chapter3.rpy:116
translate japanese chapter_3_8a2ed35d:

    # vanta_char "Bro, I think my cake is too big. My ass is just out."
    vanta_char "なあ、俺のケツでかすぎるって。もう、丸出しなんだけど。"

# game/chapter3.rpy:117
translate japanese chapter_3_bbf6f483:

    # zali_char "You can take another towel, you know. One for the front, one for the back."
    zali_char "もう一枚タオル使ってもいいんだよ？前用と後ろ用でさ。"

# game/chapter3.rpy:118
translate japanese chapter_3_8a919686:

    # wilson_char "Or just rub it in. Ball it out. Own it like the king you are. Let the cheeks speak, Vaddy."
    wilson_char "あるいは、もう開き直っちゃえ。堂々と見せつけるんだ。\n王としての風格で受け止めろ、ケツに語らせろ、ヴァディ。"

# game/chapter3.rpy:119
translate japanese chapter_3_e91e1fb3:

    # vanta_char "I'm telling you, they've gyatt to be more considerate of people with fat cheeks like mine."
    vanta_char "まったくさ、俺みたいにケツがでかい人への配慮が足りないんだよ、まったく。"

# game/chapter3.rpy:120
translate japanese chapter_3_c97dbd07:

    # "There's a beat of silence before all of you burst into laughter."
    "一瞬の沈黙のあと、全員が一斉に笑い出す。"

# game/chapter3.rpy:121
translate japanese chapter_3_1df8d6c0:

    # zali_char "Goodness, Vanta. Here—there's another towel if you wanna use it."
    zali_char "まったく、ベンタったら。\nはい、もう一枚あるから、使いたかったらどうぞ。"

# game/chapter3.rpy:128
translate japanese chapter_3_d87f1c01:

    # "The three of you finally settle into the bath, easing into the steaming water with a collective sigh. Muscles relax, tension melts, and for a while, there's nothing but the\nquiet ripple of water and the occasional swirl of steam."
    "三人はついに湯船に落ち着き、湯気の立ちのぼるお湯に身を沈めながら、揃ってため息をついた。\n筋肉はほぐれ、緊張が溶けていく。しばらくの間、水面の静かな揺らぎと、ときおり立ち上るやわらかな湯気だけが、空間を満たしていた。"

# game/chapter3.rpy:129
translate japanese chapter_3_94c103f7:

    # "Time seems to blur in the warmth. You lean back, half-dozing, half-listening to Wilson yap something about konbini snacks."
    "温もりの中で、時間の感覚がぼやけていく。\nあなたは背もたれに身を預け、半分まどろみながら、ウィルソンがコンビニのお菓子について喋っているのをなんとなく聞いている。"

# game/chapter3.rpy:132
translate japanese chapter_3_2153cd2c:

    # "Eventually, the three of you start to rise from the bath, wrapping yourselves in towels once more. But as you head toward the changing room—"
    "やがて三人はゆっくりと湯船から立ち上がり、再びタオルを体に巻く。\nだが、更衣室へ向かうそのとき―"

# game/chapter3.rpy:135
translate japanese chapter_3_5f2ee044:

    # zali_char "... Wait. Where are my glasses?"
    zali_char "…ちょっと待って。私のメガネ、どこ？"

# game/chapter3.rpy:136
translate japanese chapter_3_c391290e:

    # wilson_char "Huh? Mine are gone too! I am sure that I left them sitting right on my shirt..."
    wilson_char "えっ？僕のもない！\nたしかにシャツの上に置いたはずなのに…"

# game/chapter3.rpy:137
translate japanese chapter_3_028b12c1:

    # "You check the shelf where you left yours. Empty. All three pairs—vanished."
    "自分のメガネを置いていた棚を確認する。\n…空っぽだ。三人分すべてのメガネが—消えている。"

# game/chapter3.rpy:138
translate japanese chapter_3_2fc69528:

    # "After searching every corner and finding absolutely nothing, you decide to head back to your room. Maybe someone picked up your glasses by mistake?"
    "隅々まで探しても何も見つからなかったため、あなたは部屋に戻ることにする。\nもしかして、誰かが間違えてメガネを拾ったのかもしれない？"

# game/chapter3.rpy:143
translate japanese chapter_3_a526f740:

    # "But the moment you slide open the door to your room—"
    "しかし、ふすまを開けて部屋に入った瞬間—"

# game/chapter3.rpy:144
translate japanese chapter_3_fc82411e:

    # "Three neatly folded kimono sit waiting on your bed. On top, a card catches your eye."
    "ベッドの上に、きれいに畳まれた浴衣が三着並んでいる。\nその上に華やかに飾られたカードが目を引いた。"

# game/chapter3.rpy:147
translate japanese chapter_3_5a10adde:

    # zali_char "Wow, these are gorgeous... Who left these here? Oh? It's Rai. Wilson, this must be for you."
    zali_char "わぁ、これすごく綺麗…誰が置いたんだろう？\nあれ？ライだ。ウィルソン、これはきっと君宛だよ。"

# game/chapter3.rpy:152
translate japanese chapter_3_6f8ab4d8:

    # wilson_char "\"Dear Yu. My heart beat is 240 bpm...this is just a small gift from me, I mean, from all of us.\nI hope you'll wear it to the party tonight. There's also another surprise hidden nearby...\nYou know what this means, don't you? Inami Rai, chu!\""
    wilson_char "「親愛なるユウへ。オレの心拍数は240bpm…これはオレ―いや、オレたちみんなからのささやかなプレゼントです。今夜のパーティーでこれを身につけてくれると嬉しいな。\n近くにもうひとつサプライズが隠してあるよ…どういう意味かわかるよね？伊波ライより、Chu！」"

# game/chapter3.rpy:154
translate japanese chapter_3_17e1dec4:

    # wilson_char "Wait... I don't know what this means! Another gift? Another surprise?"
    wilson_char "えっ…どういう意味！？もうひとつのプレゼント？もうひとつのサプライズ？"

# game/chapter3.rpy:156
translate japanese chapter_3_c64e7e00:

    # vanta_char "Honestly, I wouldn't be surprised if Rai just jumps out of nowhere—"
    vanta_char "正直、ライが急に飛び出してきても驚かないかも―"

# game/chapter3.rpy:165
translate japanese chapter_3_bf1b4ac0:

    # "Suddenly—BANG BANG BANG. Someone's knocking like they're trying to break the door down. You barely exchange glances before heading over."
    "その時―ドンドンドン！誰かがドアを壊す勢いでノックしてくる。\nお互い目を合わせる間もなく、急いで向かう。"

# game/chapter3.rpy:173
translate japanese chapter_3_eac70c04:

    # "As you open the door, you spot someone familiar. It is none other than—"
    "ドアを開けると、見覚えのある姿が目に入った。そこにいたのは―"

# game/chapter3.rpy:178
translate japanese chapter_3_1de395a4:

    # wilson_char "Rai? You're here? How—"
    wilson_char "ライ？ここに？どうやって―"

# game/chapter3.rpy:183
translate japanese chapter_3_b082cd06:

    # "Rai freezes mid-step at the sound of Wilson's voice. Then, he bolts."
    "ライはウィルソンの声を聞いた瞬間、足を止め、そしてそのまま走り出した。"

# game/chapter3.rpy:190
translate japanese chapter_3_8493d71e:

    # wilson_char "Wait! Why are you running away? I am Yu!!!"
    wilson_char "待って！なんで逃げるの！？僕だよ、ユウだよ！！"

# game/chapter3.rpy:191
translate japanese chapter_3_64d8185c:

    # vanta_char "What in the world...?"
    vanta_char "一体何が…？"

# game/chapter3.rpy:192
translate japanese chapter_3_fb724cb6:

    # zali_char "Did he just—run? Also, am I crazy, or was he holding our glasses?"
    zali_char "今、逃げた…？\nそれに私の勘違いじゃなければ、私たちのメガネを持っていたような…？"

# game/chapter3.rpy:193
translate japanese chapter_3_e7d9b3e8:

    # wilson_char "No...no way! Rai would never run from me! We're going after him."
    wilson_char "いや…まさか！\nライが僕から逃げるなんて、そんなはずない！追いかけよう！"

# game/chapter3.rpy:199
translate japanese chapter_3_bdfd0d07:

    # "Krisis takes off down the hallway in pursuit."
    "クライシスが廊下を駆け抜けて、ライを追う。"

# game/chapter3.rpy:202
translate japanese chapter_3_a834286d:

    # "Unbeknownst to you, back in your room, a pair of purple-pink eyes watches silently from behind the closet door. The owner of said eyes narrows them, lying in wait for the perfect moment to jump out."
    "そのころ、あなたの部屋では―クローゼットの扉の陰から、紫とピンクの混ざった瞳がじっとこちらを見つめていた。\nその目の持ち主は、瞳を細め、飛び出す完璧なタイミングを狙って身を潜めている。"

# game/chapter3.rpy:203
translate japanese chapter_3_fcc82b20:

    # "... That moment never comes."
    "…だが、その瞬間は永遠に訪れなかった。"

# game/chapter3.rpy:205
translate japanese chapter_3_867723b0:

    # "The second you storm out of the room, the closet creaks open."
    "あなたが部屋を飛び出したその瞬間、クローゼットがギィ…と音を立てて開く。"

# game/chapter3.rpy:208
translate japanese chapter_3_bc99d86d:

    # rai_char "Huh?! What just happened? I was gonna surprise Yu! I even practiced my big entrance!"
    rai_char "えっ！？なにが起きたの！？\nユウを驚かせるつもりだったのに！\nあの完璧な登場、めっちゃ練習したのに！！"

# game/chapter3.rpy:212
translate japanese chapter_3_04e6c932:

    # "The three of you sprint after Rai, racing down the hallway. But as you round the corner into the changing room corridor—"
    "あなたたち三人はライを追って廊下を全力で走る。\nだが更衣室の廊下の角を曲がった先に現れたのは―"

# game/chapter3.rpy:213
translate japanese chapter_3_158413e6:

    # "Bamboo baskets. Everywhere."
    "そこら中に散らばる、桶。"

# game/chapter3.rpy:214
translate japanese chapter_3_1a3ec900:

    # "Rai, with suspicious agility, bounds straight through without disturbing a single one."
    "ライは、怪しいほどの俊敏さで、桶をひとつも乱すことなくまっすぐ駆け抜けていく。"

# game/chapter3.rpy:219
translate japanese chapter_3_qte_baskets_25dbf849:

    # vanta_char "God dammit! Who put these here?! We need to get rid of them!"
    vanta_char "なんだよこれ！誰がこんなもん置いたんだよ！？片付けないと進めない！"

# game/chapter3.rpy:262
translate japanese chapter_3_qte_baskets_timeout_a76d81e8:

    # wilson_char "Jesus Christ! AHHH!!"
    wilson_char "ジーザス・クライスト！うわああ！！"

# game/chapter3.rpy:263
translate japanese chapter_3_qte_baskets_timeout_3ba8be4f:

    # zali_char "Oops! My foot, gosh!"
    zali_char "いてっ！足が…もうっ！"

# game/chapter3.rpy:264
translate japanese chapter_3_qte_baskets_timeout_74a69f46:

    # vanta_char "I swear, there weren't this many baskets earlier..."
    vanta_char "いやマジで、さっきまでこんなに桶なかったよな…"

# game/chapter3.rpy:265
translate japanese chapter_3_qte_baskets_timeout_8ef70eb7:

    # "You try to move through the baskets with grace...but that's not happening. Wilson bumps into one and stumbles. Zali gets his foot caught in a handle. You trip slightly, sending one flying through the air."
    "あなたは優雅に桶の間をすり抜けようとする…が、うまくはいかない。\nウィルソンはひとつにぶつかってよろけ、ザリは足を引っかけてしまう。\nあなたは軽くつまずき、ひとつの桶を宙に飛ばしてしまう。"

# game/chapter3.rpy:266
translate japanese chapter_3_qte_baskets_timeout_b6c7a240:

    # "You quickly regain your composure, dust yourself off, and start laughing."
    "すぐに体勢を立て直し、服についた埃を払って、三人は思わず笑い出す。"

# game/chapter3.rpy:277
translate japanese chapter_3_qte_baskets_clear_5bab054d:

    # "One by one, you three scoop up the baskets and toss them behind you. Zali catches one mid-air. Wilson spins one dramatically. You—you just stack them neatly."
    "あなたたち三人は、ひとつずつ桶を拾って次々と脇に放り投げていく。\nそのうちのひとつをザリは空中でキャッチ。\nウィルソンはやたら大げさにクルクル回す。\nそしてあなたは—ただきれいに積み重ねるだけ。"

# game/chapter3.rpy:282
translate japanese chapter_3_qte_baskets_clear_c4fc1aba:

    # zali_char "Phew! Nice and easy!"
    zali_char "ふぅ！スムーズだったね！"

# game/chapter3.rpy:283
translate japanese chapter_3_qte_baskets_clear_cbf6a604:

    # wilson_char "Great teamwork, guys!"
    wilson_char "いいチームワークだ、みんな！"

# game/chapter3.rpy:284
translate japanese chapter_3_qte_baskets_clear_a1d42206:

    # vanta_char "Alright. We up!"
    vanta_char "よし、行こう！"

# game/chapter3.rpy:288
translate japanese chapter_3_1_04a9ee3a:

    # "Then, something shiny catches your eye. It's Zali's glasses—laying peacefully on a shelf, near the edge of the corridor."
    "そのとき、何かがきらりと光って目に入る。\nザリのメガネだ。廊下の端、棚の上に、静かに置かれていた。"

# game/chapter3.rpy:289
translate japanese chapter_3_1_c36c6176:

    # zali_char "Oh! my glasses! They're just...here?"
    zali_char "あっ！私のメガネ！こんなとこにあったの？"

# game/chapter3.rpy:292
translate japanese chapter_3_1_237af8e5:

    # "Zali picks his glasses up and puts them on."
    "ザリはそれを手に取り、さっとかける。"

# game/chapter3.rpy:294
translate japanese chapter_3_1_5ab4a996:

    # wilson_char "Ahhhh~~ Which way did Rai go? That way?"
    wilson_char "あああ〜〜〜っ！！ライはどっちに行った！？あっち？"

# game/chapter3.rpy:296
translate japanese chapter_3_1_ea0c4340:

    # vanta_char "I think he went down that direction, no?"
    vanta_char "いや、あの方向に行ったんじゃないか？"

# game/chapter3.rpy:303
translate japanese chapter_3_1_bebb818f:

    # "You swing around the corner—and there he is. Rai, standing in the middle of the hallway."
    "角を勢いよく曲がると―そこにいた。廊下の真ん中に、ライが立っている。"

# game/chapter3.rpy:308
translate japanese chapter_3_1_25c377fb:

    # zali_char "Look! It's Rai!"
    zali_char "見て！ライだ！"

# game/chapter3.rpy:309
translate japanese chapter_3_1_a14cb4bf:

    # wilson_char "Rai! It's me! Is everything okay? You look..."
    wilson_char "ライ！ 僕だよ！大丈夫？なんか顔が…"

# game/chapter3.rpy:314
translate japanese chapter_3_1_66e3fef1:

    # "Wilson jogs forward. Rai lets out a squeak, spins on his heel, and dashes into the kitchen."
    "ウィルソンが駆け寄ると、ライは「ひゃっ」と小さな声を上げて、その場でくるっと向きを変え、キッチンへと駆け込んでいく。"

# game/chapter3.rpy:322
translate japanese chapter_3_1_0bd5a16a:

    # wilson_char "Why are you running away from me? Rai? Rai!"
    wilson_char "なんで逃げるの！？ライ？ライーー！！"

# game/chapter3.rpy:323
translate japanese chapter_3_1_9e4e8fb8:

    # zali_char "Wait, guys! Be careful. There are people working in the kitchen, we can't make a mess!"
    zali_char "ちょっと待って、みんな！キッチンにはスタッフがいるんだから、めちゃくちゃにしちゃダメだよ！"

# game/chapter3.rpy:324
translate japanese chapter_3_1_3d84e7b8:

    # wilson_char "Then we'll just have to be giga-careful! Come on, let's go!"
    wilson_char "じゃあ、超〜慎重に行くしかないね！さあ、行こう！"

# game/chapter3.rpy:325
translate japanese chapter_3_1_052307e2:

    # zali_char "Wilson, wait—"
    zali_char "ウィルソン、待って―"

# game/chapter3.rpy:330
translate japanese chapter_3_1_24dec637:

    # "Wilson takes off into the kitchen. Zali runs after him, leaving you groaning."
    "ウィルソンはキッチンへと飛び出していき、ザリもそれを追いかける。\nあなたは思わずため息をつく。"

# game/chapter3.rpy:334
translate japanese chapter_3_1_daa64f9f:

    # vanta_char "Ngh~~ The kitchen again? Alright, I am coming..."
    vanta_char "メイドの次は、シェフにでもなるつもりかよ…"

# game/chapter3.rpy:335
translate japanese chapter_3_1_d4d50370:

    # "That's what he said."
    "パリでの任務に続き、キッチンにはなにかと縁があるようだ。"

# game/chapter3.rpy:340
translate japanese chapter_3_1_989e006f:

    # "You reluctantly burst into the kitchen. Wilson is already hopping over counters like he's parkouring through a block game."
    "しぶしぶキッチンに飛び込むと、ウィルソンはすでにカウンターを飛び越えながら、まるで某ブロックゲームの中をパルクールでもしているかのように駆け回っている。"

# game/chapter3.rpy:342
translate japanese chapter_3_1_5c092916:

    # "The kitchen staff startle, dodging out of the way. Pots clatter. Something flies—"
    "キッチンスタッフは驚いて身をかわし、鍋がガシャガシャと音を立て、何かが宙を舞う—"

# game/chapter3.rpy:345
translate japanese chapter_3_1_ea541ae3:

    # "An egg whisk flies through the air, heading straight for a chef."
    "泡立て器が空中を飛び、シェフの顔面に一直線！"

# game/chapter3.rpy:347
translate japanese chapter_3_1_0f6eea5d:

    # vanta_char "{size=40}Oh my god!! Wilson!{/size}"
    vanta_char "うわっ、おい！！ウィルソン！！"

# game/chapter3.rpy:348
translate japanese chapter_3_1_22f26585:

    # wilson_char "{size=40}Ah! Gomenyasai!{/size}"
    wilson_char "あっ！ごめんにゃさい！！"

# game/chapter3.rpy:350
translate japanese chapter_3_1_1719b6ed:

    # zali_char "{size=40}Wilson! Behind you!{/size}"
    zali_char "ウィルソン！後ろ！！"

# game/chapter3.rpy:353
translate japanese chapter_3_1_47b9fd69:

    # "Wilson turns around, and—"
    "ウィルソンが振り返ると―"

# game/chapter3.rpy:377
translate japanese chapter_3_qte_1_timeout_f383f3cc:

    # "Wilson fumbles the catch. The whisk sails past his head and smacks a chef right in the face."
    "ウィルソンはキャッチに失敗する。泡立て器は彼の頭をかすめて飛び、シェフの顔面に直撃する。"

# game/chapter3.rpy:378
translate japanese chapter_3_qte_1_timeout_dd658eff:

    # wilson_char "{size=40}Sowwy!{/size}"
    wilson_char "{size=40}ごめ〜ん！{/size}"

# game/chapter3.rpy:389
translate japanese chapter_3_qte_1_clear_1b044c4c:

    # "Wilson catches the whisk just in time and tosses it cleanly into a nearby sink."
    "ウィルソンはギリギリのタイミングで泡だて器をキャッチし、そのまま綺麗に近くのシンクへと投げ入れる。"

# game/chapter3.rpy:390
translate japanese chapter_3_qte_1_clear_8c19dcc7:

    # wilson_char "UGHAHH! That was way too close!"
    wilson_char "うわああああ！マジで危なかったー！"

# game/chapter3.rpy:397
translate japanese chapter_3_2_d34b7234:

    # "Suddenly—BANG! A water tank hits the ground, flooding the floor. In the chaos, an octopus slips out."
    "その瞬間—ドン！水槽が床に落ち、辺り一面に水が広がる。\nその混乱の中、タコがするりと抜け出す。"

# game/chapter3.rpy:401
translate japanese chapter_3_2_8098a18a:

    # vanta_char "What? Is that an octopus? Gosh golly gee willikers... You can't be serious..."
    vanta_char "なに？あれって…タコ！？\nうわっ、マジかよ…冗談だろ…？"

# game/chapter3.rpy:402
translate japanese chapter_3_2_accaf6b6:

    # wilson_char "Well... Vanta, you fought a giant octopus before, right?"
    wilson_char "えーっと…ベンタ、前にも巨大なタコと戦ったことあるよね？"

# game/chapter3.rpy:407
translate japanese chapter_3_2_60f7dd67:

    # zali_char "{size=40}Don't worry! I got it!{/size}"
    zali_char "心配しないで！任せて！"

# game/chapter3.rpy:408
translate japanese chapter_3_2_ac1947a9:

    # "Zali dashes toward the octopus, passing by a bucket. The capable hero leaps toward the octopus, moving to catch it with—"
    "ザリがバケツの横を駆け抜け、タコに向かって突進する。頼れるヒーローは跳びかかり、タコを捕まえようとして―"

# game/chapter3.rpy:440
translate japanese chapter_3_qte_2_clear_d39b6d8d:

    # "Zali grabs the bucket, swings it, and dunks it over the octopus. It shrieks, flailing inside, but Zali holds firm, flipping it back into the tank with expert precision."
    "ザリはバケツをひっつかむと、そのまま勢いよく振りかぶり、タコの上に中の水ごとかぶせる。\nタコはまるで叫ぶようにもがくが、ザリはしっかりと押さえつけ、見事な手さばきでタコを水槽に戻す。"

# game/chapter3.rpy:443
translate japanese chapter_3_qte_2_clear_e0a89837:

    # wilson_char "Is there anything you're not good at, Zali?"
    wilson_char "ザリ、お前が苦手なことって何かあるの？"

# game/chapter3.rpy:451
translate japanese chapter_3_qte_2_wrong_a024a4c0:

    # "Zali dives forward and grabs for the octopus barehanded. It shrieks and slaps him in the face, slipping right through his fingers."
    "ザリは前に飛び出して、素手でタコをつかもうとする。\nタコは叫び声を上げて彼の顔を叩き、指の間をすり抜けて逃げていった。"

# game/chapter3.rpy:452
translate japanese chapter_3_qte_2_wrong_fb93ee4e:

    # zali_char "Ugh!! It got away!"
    zali_char "うわっ！！逃げられた！"

# game/chapter3.rpy:456
translate japanese chapter_3_qte_2_wrong_6b48d607:

    # vanta_char "Damn... Backshots from an octopus? Couldn't be me."
    vanta_char "くそっ…タコに不意打ちなんて、俺だったらあり得ないな。"

# game/chapter3.rpy:463
translate japanese chapter_3_3_41b2caba:

    # "Looking at Wilson, you eyes land on something on Wilson's head. Orange. Wiggly."
    "ウィルソンを見ると、彼の頭の上の【何か】へと視線が釘付けになる。\nそれが、うごめいている。"

# game/chapter3.rpy:464
translate japanese chapter_3_3_d36a4f2e:

    # vanta_char "Uh... Wilson?"
    vanta_char "あの…ウィルソン？"

# game/chapter3.rpy:466
translate japanese chapter_3_3_d1638504:

    # wilson_char "Yes, Vanta?"
    wilson_char "なに、ベンタ？"

# game/chapter3.rpy:468
translate japanese chapter_3_3_d73755b8:

    # vanta_char "{size=40}Don't. Move.{/size}"
    vanta_char "動かないで。"

# game/chapter3.rpy:469
translate japanese chapter_3_3_347fb051:

    # wilson_char "{size=40}What? What do you mean—don't—?!{/size}"
    wilson_char "え？どういう…動くなって—？！"

# game/chapter3.rpy:472
translate japanese chapter_3_3_cd57bd59:

    # "Wilson startles, stepping back. Right at that moment, the orange thing on his head twitches. It jumps—"
    "ウィルソンは驚いて後ずさる。\nその瞬間、頭の上の【それ】がピクッと動く。\nそして―跳ねた。"

# game/chapter3.rpy:475
translate japanese chapter_3_3_4d05cc19:

    # zali_char "{size=40}It's a crab! Vanta! Quick!{/size}"
    zali_char "カニだ！ベンタ！早く！"

# game/chapter3.rpy:476
translate japanese chapter_3_3_c6cb4328:

    # "You leap forward, you can't let anything happen to your thang!"
    "あなたは飛び出す。\nあなたの大切な存在に何かあってはならない！"

# game/chapter3.rpy:499
translate japanese chapter_3_qte_3_clear_e844ec92:

    # "You snatch the soaring crab! It wiggles aggressively."
    "あなたは空中でカニの片方のハサミを掴み取る！カニは激しくじたばたと動く。"

# game/chapter3.rpy:500
translate japanese chapter_3_qte_3_clear_8088c607:

    # "Before it can pinch you, you toss it over your shoulder. It lands in the tank without a splash."
    "挟まれる前に、あなたはカニを肩越しに投げる。\nそれは音も立てずに水槽へと着地した。"

# game/chapter3.rpy:503
translate japanese chapter_3_qte_3_clear_eb551119:

    # zali_char "Nice catch, Vanta!"
    zali_char "ナイスキャッチ、ベンタ！"

# game/chapter3.rpy:506
translate japanese chapter_3_qte_3_clear_dd1c637a:

    # vanta_char "Heh. That's just the kinda guy I am."
    vanta_char "へへっ。俺ってそういう男だからな。"

# game/chapter3.rpy:522
translate japanese chapter_3_qte_3_timeout_eb841974:

    # "You lunge for the crab and miss completely. It scuttles away with surprising speed, vanishing behind a stack of pans."
    "カニに飛びかかるが、まったくの空振り。\nカニは驚くほどのスピードで逃げ去り、鍋の山の裏に消える。"

# game/chapter3.rpy:524
translate japanese chapter_3_qte_3_timeout_f233f96f:

    # wilson_char "You could almost say it was—"
    wilson_char "これはまさに―"

# game/chapter3.rpy:526
translate japanese chapter_3_qte_3_timeout_b3f5152a:

    # vanta_char "No."
    vanta_char "ダメ。"

# game/chapter3.rpy:528
translate japanese chapter_3_qte_3_timeout_205bd9b8:

    # wilson_char "—Feeling crabby."
    wilson_char "神隠し（カニかくし）だな。"

# game/chapter3.rpy:530
translate japanese chapter_3_qte_3_timeout_a2529dd7:

    # vanta_char "That's it. You're done. Banned! Get out of here!"
    vanta_char "もういい。終了。出禁だ！今すぐ帰れ！！"

# game/chapter3.rpy:539
translate japanese chapter_3_4_267f82cb:

    # "As you catch your breath, your eyes land on something familiar on the kitchen counter."
    "息を整えながらふと目をやると、キッチンのカウンターに見覚えのあるものが目に入る。"

# game/chapter3.rpy:540
translate japanese chapter_3_4_f023d0eb:

    # vanta_char "My glasses? Huh! Mission accomplished, I guess."
    vanta_char "俺のメガネ？…よし！任務完了ってことかな。"

# game/chapter3.rpy:543
translate japanese chapter_3_4_44664fe9:

    # wilson_char "But where are my glasses? Also... Did Rai disappear again?"
    wilson_char "でも、僕のメガネはどこ？\nそれに…ライは、また消えたの？"

# game/chapter3.rpy:546
translate japanese chapter_3_4_4205ed15:

    # "The three of you step out of the kitchen and look around. Just outside your room, something catches the light. You see a glint on the floor by the door."
    "あなたたち三人はキッチンを出て、あたりを見回した。部屋のすぐ外で、何かが光を反射している。\nドアのそばの床に、キラッと光るものが見える。"

# game/chapter3.rpy:548
translate japanese chapter_3_4_97db28e6:

    # "You walk over. Wilson picks it up."
    "あなたが近づくと、ウィルソンがそれを拾い上げた。"

# game/chapter3.rpy:552
translate japanese chapter_3_4_f117be9c:

    # wilson_char "Oh! My glasses! They were here the whole time? I swear they weren't here when we left!"
    wilson_char "あっ！メガネ！ずっとここにあったの？出るときはなかったはずなのに！"

# game/chapter3.rpy:556
translate japanese chapter_3_4_8b758ab2:

    # "You open the door to your room."
    "あなたは部屋のドアを開ける。"

# game/chapter3.rpy:557
translate japanese chapter_3_4_0fd37200:

    # "And freeze."
    "―そして、固まる。"

# game/chapter3.rpy:560
translate japanese chapter_3_4_aaa6ea1a:

    # "Rai is sitting on your bed, legs swinging, looking at you with a surprised expression."
    "ライがあなたのベッドに座り、足をぶらぶらさせながら、驚いた顔でこちらを見ていた。"

# game/chapter3.rpy:564
translate japanese chapter_3_4_d387e2dd:

    # rai_char "Yu! Krisis! Where have you been?! I was hiding in the room to surprise you, but before I could come out you all ran off!"
    rai_char "ユウ！クライシス！どこ行ってたの！？\nサプライズしようと思って部屋に隠れてたのに、出る前にみんな行っちゃうんだもん！"

# game/chapter3.rpy:565
translate japanese chapter_3_4_c48dac7f:

    # wilson_char "Rai? What do you mean? We've been chasing you all over this place!"
    wilson_char "ライ？どういうこと？\n僕たちはずっと、ここで君を追いかけ回してたんだけど！？"

# game/chapter3.rpy:568
translate japanese chapter_3_4_b248862e:

    # zali_char "So you didn't take the glasses?"
    zali_char "えっ、じゃあメガネを取ったのは君じゃないの？"

# game/chapter3.rpy:569
translate japanese chapter_3_4_d12d9d62:

    # rai_char "What glasses? I just brought the kimono for Yu, so we can match at the party later."
    rai_char "メガネ？なにそれ？\nオレはユウに渡す着物を持ってきただけだよ。\nあとでパーティーでおそろいにしたくて。"

# game/chapter3.rpy:572
translate japanese chapter_3_4_b7e7fe2d:

    # wilson_char "What? That makes no sence, so I wasn't chasing you?"
    wilson_char "え？ちょっと待って、それおかしくない？\nじゃあ僕が追いかけてたの、誰！？"

# game/chapter3.rpy:575
translate japanese chapter_3_4_0646e58b:

    # vanta_char "It was totally Rai! Who else could it be?!"
    vanta_char "絶対に君だったって！他に誰がいるっていうんだ？！"

# game/chapter3.rpy:576
translate japanese chapter_3_4_012523be:

    # rai_char "No way..."
    rai_char "まさか…"

# game/chapter3.rpy:580
translate japanese chapter_3_4_8c3c8b57:

    # rai_char "You didn't just run into the legendary tanuki of this inn, did you?"
    rai_char "…君たち、もしかしてこの宿に伝わる『伝説のタヌキ』に会っちゃったんじゃない…？"

# TODO: Translation updated at 2025-06-04 22:01

# game/chapter3.rpy:214
translate japanese chapter_3_36082ae8:

    # "Wooden baskets. Everywhere."
    "そこら中に散らばる、桶。"

# game/chapter3.rpy:307
translate japanese chapter_3_qte_baskets_timeout_47283a85:

    # "You try to move through the baskets with grace...but that's not happening. Wilson bumps into one and stumbles. Zali gets his foot caught. You trip slightly, sending one flying through the air."
    "あなたは優雅に桶の間をすり抜けようとする…が、うまくはいかない。\nウィルソンはひとつにぶつかってよろけ、ザリは足を引っかけてしまう。\nあなたは軽くつまずき、ひとつの桶を宙に飛ばしてしまう。"

translate japanese strings:

    # game/chapter3.rpy:410
    old "Grab"
    new "つかめ"

    # game/chapter3.rpy:468
    old "A Bucket"
    new "バケツをつかむ"

    # game/chapter3.rpy:469
    old "His Hands"
    new "素手でつかむ"

    # game/chapter3.rpy:532
    old "Catch it"
    new "捕まえろ"

# game/chapter3.rpy:503
translate japanese chapter_3_3_52a48e59:

    # "Looking at Wilson, you eyes land on something on Wilson's head. It's wiggling."
    "ウィルソンを見ると、彼の頭の上の【何か】へと視線が釘付けになる。\nそれが、うごめいている。"# TODO: Translation updated at 2025-06-14 23:40

# game/chapter3.rpy:11
translate japanese chapter_3_2f2fb403:

    # "The grand lobby of International Heroes HQ buzzes with activity. Buntings hang overhead, congratulatory banners stretch across the walls, and a faint chorus of laughter and chatter echoes through the halls."
    "国際ヒーロー本部の広々としたロビーは活気に満ちていた。\n頭上には旗が飾られ、壁には祝賀のバナーが掲げられ、廊下には笑い声と談笑がかすかに響いている。"

# game/chapter3.rpy:20
translate japanese chapter_3_b0fb729c:

    # zali_char "Definitely! I've missed Japan. Wait—where is Vanta?"
    zali_char "そうだね！日本が恋しかったよ。\n…って、あれ？べンタはどこ？"

# game/chapter3.rpy:617
translate japanese chapter_3_4_141be9c9:

    # wilson_char "What? That makes no sense, so I wasn't chasing you?"
    wilson_char "え？ちょっと待って、それおかしくない？\nじゃあ僕が追いかけてたの、誰！？"

# game/chapter3.rpy:625
translate japanese chapter_3_4_9ceddfcf:

    # rai_char "I have heard rumors about a legendary tanuki in this ryokan."
    rai_char "この旅館には、伝説のタヌキがいるって噂、知ってる？"

# game/chapter3.rpy:626
translate japanese chapter_3_4_a8cefc1e:

    # rai_char "They say he used to play tricks on the guests, but that story's been around for ages...nothing's happened recently."
    rai_char "気に入った宿泊客にイタズラをするっていうんだけど、それもずっと昔の話で最近は何も起きてないみたい。"

# game/chapter3.rpy:629
translate japanese chapter_3_4_326290e9:

    # rai_char "You didn't just run into him, did you? Haha!"
    rai_char "まさか、君たち会っちゃったんじゃない？はは！"

# game/chapter3.rpy:632
translate japanese chapter_3_4_e3ad48ca:

    # rai_char "Anyway, I'll leave these kimono with you. Don't forget to wear them to the party later!"
    rai_char "とにかく、この着物はここに置いておくね。\n夜のパーティーには絶対着てきてね、特にユウはね！えへへ！"

# game/chapter3.rpy:634
translate japanese chapter_3_4_3f3ff9e9:

    # "You watch as Rai skips off cheerfully, leaving the room behind."
    "ライが楽しそうにスキップしながら部屋を後にするのを見送った。"

