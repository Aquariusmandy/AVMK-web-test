translate japanese strings:

    # game/inventory.rpy:240
    old "No matter the time or place, heroes never stop. \nKrisis, Heroes of the Night—Touch Down!"
    new "時間も場所も関係ない。\nヒーローの歩みは止まらない。\nクライシス、闇夜のヒーロー — Touch Down!"

    # game/inventory.rpy:258
    old "Find every hero and what they're hiding!"
    new "すべてのヒーローと、彼らが隠しているものを見つけましょう！"

    # game/inventory.rpy:258
    #old "Small heroes, Big adventure—find every hero!"
    #new "小さなヒーローたちを見つけましょう！"

    # game/inventory.rpy:268
    #old "Find every hero in the Photo Diary \nto unlock the Travel Gallery!"
    #new "フォトダイアリーで全てのヒーローを見つけてチャプターをクリアすると、\nトラベルギャラリーがアンロックされます！"
    
    # game/inventory.rpy:283
    old "A collection of shining moments, each one brought to \nlife by the brilliant creativity of the Vezcrewneers."
    new "それぞれの輝く瞬間が、ヴェズクルーニアーズの\n卓越した創造力によって彩られています。"

    # game/inventory.rpy:299
    old "Secret\nSnaps"
    new "{size=22}シークレット\nスナップ{/size}"

    # game/inventory.rpy:300
    old "Photo\nDiary"
    new "{size=22}フォト\nダイアリー{/size}"

    # game/inventory.rpy:301
    old "Travel\nGallery"
    new "{size=22}トラベル\nギャラリー{/size}"
# TODO: Translation updated at 2025-06-14 23:40

translate japanese strings:

    # game/inventory.rpy:258
    old "Click the photos on the left and find every hero!"
    new "左の写真から小さなヒーローたちを見つけましょう！"

    # game/inventory.rpy:268
    old "Find every hero in the Photo Diary and complete\nthe chapter to unlock the Travel Gallery!"
    new "フォトダイアリーで全てのヒーローを見つけて\nチャプターをクリアすると\nトラベルギャラリーがアンロックされます！"

