# TODO: Translation updated at 2025-06-04 19:59

translate japanese strings:

    # game/click_point.rpy:12
    old "Want to drive Wilson feral? \nTry a seductive half-snake enchantress. \nNo questions asked."
    new "ウィルソンを狂わせたい？\n誘惑的な半蛇の魔女を試してみて。\n質問は受け付けません。"

    # game/click_point.rpy:12
    old "Limited edition. Freshly squeezed. \nThirsty? You know you want a taste."
    new "限定版。しぼりたて。\nのどが渇いた？\n一口飲みたくなるでしょ。"

    # game/click_point.rpy:12
    old "Wilson's signature crepes... \nor are they pancakes? \nEither way, they're delicious. Probably."
    new "ウィルソンの看板メニュー、\nクレープ…それともパンケーキ？\nどっちにしても、おいしい。たぶん。"

    # game/click_point.rpy:12
    old "Said to mark both the beginning \nand end of Calamitycrow. \nA legendary orange licorice ice cream in Canada, \nallegedly worth a two-hour detour."
    new "カラミティクロウの始まりと終わりを示すと\n言われている。カナダでは伝説的な\nオレンジリコリス味のアイスクリームで、\n2時間の寄り道をする価値があるとか。"

    # game/click_point.rpy:12
    old "Willerton's pet żar-ptak. \nAlso known as KFC. \nHe's recently became a parent\n—totally unplanned."
    new "ウィラートンのペット、\nジャルプタク（火の鳥）。別名KFC。\n最近、まさかの親になった―\n完全に予定外。"

    # game/click_point.rpy:38
    old "Zali's favorite dessert. \nHomemade versions may spontaneously \nbecome...caramelized omelets."
    new "ザリのお気に入りのデザート。\n手作り版は意図せず……\nカラメルオムレツになることも。"

    # game/click_point.rpy:38
    old "\"Delicious!\nEveryone loves blue cheese!\" —Zali"
    new "「おいしい！ブルーチーズはみんな大好きだよ！」\n—ザリ"

    # game/click_point.rpy:38
    old "Tasty, nutritious, and wildly popular! \nFor more details, consult \nmedical hero Vezalius Bandage.\nSide effects: unknown. \nUse with reckless confidence."
    new "おいしくて栄養たっぷり、しかも大人気！\n 詳しくはメディックヒーロー、\nヴェザリウス・バンデージにご相談ください。\n副作用：不明。\n無謀な自信とともにご使用ください。"

    # game/click_point.rpy:38
    old "Fluffy, sweet, and absolutely irresistible. \nFrench toast with American butter \nand Canadian maple syrup—heroic perfection."
    new "ふわふわで甘くて、完全に抗えない。\nアメリカンバターと\nカナダ産メープルシロップを添えたフレンチトースト\n――ヒーロー級の完璧さ。"

    # game/click_point.rpy:38
    old "Rumored to be a navy-blue brief \ncovered in tiny flames.\nFor Krisis' eyes only."
    new "ネイビーブルーのブリーフに\n小さな炎が散りばめられていると噂される。\nクライシスだけが見ることを許されたアイテム。"

    # game/click_point.rpy:63
    old "A new recipe Vanta discovered recently.\n Nothing tastes better than \nwhen it's shared with the homies."
    new "ベンタが最近見つけた新レシピ。\n仲間と分け合って食べる味に勝るものなし。"

    # game/click_point.rpy:63
    old "The first dragon Vantus ever tamed. \nBrave. Loyal. Unforgotten. \nHis spirit lives on in every dragon that followed."
    new "ベンタスが最初に手懐けたドラゴン。\n勇敢で、忠実で、決して忘れられない存在。\nその魂は、後に続く\nすべてのドラゴンの中に生きている。"

    # game/click_point.rpy:63
    old "The most beloved beverage among Krisis.\nLemon sour or lemon soda? \nJust serve it in a giga pitcher!"
    new "クライシスの間で最も愛される飲み物。\nレモンサワー？それともレモンソーダ？\nとにかくメガジョッキで出すべし！"

    # game/click_point.rpy:63
    old "A dish Vanta loves to cook. \nJapanese? American? Who knows anymore. \nClaude didn't ask. He just inhaled it."
    new "ベンタのお気に入り料理。\n日本風？アメリカ風？もう誰にもわからない。\nクロードは気にせず、ただ一気に平らげた。"

    # game/click_point.rpy:63
    old "A trio of dog siblings from an enchanted town, \noften seen playing and goofing around together. \nTheir names feel eerily familiar..."
    new "魔法の町で暮らす犬の三兄弟。\nよく一緒に遊んだり、\nふざけたりしている姿を見かける。\n名前に妙な既視感が…。"

# TODO: Translation updated at 2025-06-04 20:08

translate japanese strings:

    # game/click_point.rpy:12
    old "Lamia?"
    new "ラミア？"

    # game/click_point.rpy:12
    old "Willy Milk"
    new "ウィリーミルク"

    # game/click_point.rpy:12
    old "Crêpes (or pancakes?)"
    new "クレープ（それともパンケーキ？）"

    # game/click_point.rpy:12
    old "Tiger Tail Ice Cream"
    new "タイガーテールアイスクリーム"

    # game/click_point.rpy:12
    old "Krisis Fantastic Chicken"
    new "クライシス・ファンタスティックチキン"

    # game/click_point.rpy:38
    old "Crème Brûlée"
    new "クレームブリュレ"

    # game/click_point.rpy:38
    old "Blue Cheese"
    new "ブルーチーズ"

    # game/click_point.rpy:38
    old "Zalitamin"
    new "ザリタミン"

    # game/click_point.rpy:38
    old "French Toast"
    new "フレンチトースト"

    # game/click_point.rpy:38
    old "Flame Underwear"
    new "フレイムアンダーウェア"

    # game/click_point.rpy:63
    old "Tamago Sando"
    new "たまごサンド"

    # game/click_point.rpy:63
    old "Josh"
    new "ジョシュ"

    # game/click_point.rpy:63
    old "Lemon Sour"
    new "レモンサワー"

    # game/click_point.rpy:63
    old "Sushi Bake"
    new "スシベイク"

    # game/click_point.rpy:63
    old "Vanvan, Yuyu, Banban"
    new "ヴァンヴァン、ユユ、バンバン"

# TODO: Translation updated at 2025-06-08 22:27

translate japanese strings:

    # game/click_point.rpy:12
    old "Crêpes (or pancakes?"
    new "クレープ（それともパンケーキ？）"