﻿# TODO: Translation updated at 2024-06-08 01:57

translate japanese strings:

    # game/screens.rpy:770
    old "Visit the A.S.H. Archive to see your progress,\nincluding Collected Items, Secret Snaps of amazing\nmoments caught in 4K, and extra memories of Krisis\nand the Vezcrewneers in the Seasonal Album!"
    new "これから取得済みアイテムや4K高画質CGなど、\n今までのバックログは全てA.S.H. アーカイブで確認出来ます。\nまたクライシスやヴェズクルーニアーズとの思い出もアルバムで閲覧可能です。"

    # game/screens.rpy:780
    old "Check Now!"
    new "今すぐチェック！"

    # game/screens.rpy:818
    old "Next Chapter"
    new "次のチャプターへ"

    # game/screens.rpy:1048
    old "Debug Quick Menu"
    new "Debug Quick Menu"

    # game/screens.rpy:1049
    old "Back"
    new "戻る"

    # game/screens.rpy:1050
    old "Skip"
    new "スキップ"

    # game/screens.rpy:1087
    old "Save"
    new "セーブ"

    # game/screens.rpy:1089
    old "Load"
    new "ロード"

    # game/screens.rpy:1091
    old "History"
    new "ログ"

    # game/screens.rpy:1093
    old "Settings"
    new "設定"

    # game/screens.rpy:1095
    old "Main Menu"
    new "メインメニュー"

    # game/screens.rpy:1097
    old "Quit"
    new "ゲーム終了"

    # game/screens.rpy:1151
    old "ResetInventory"
    new ""

    # game/screens.rpy:1163
    old "New Game"
    new "はじめから"

    # game/screens.rpy:1169
    old "Load Game"
    new "ロード"

    # game/screens.rpy:1170
    old "A.S.H. Archive"
    new "A.S.H. アーカイブ"

    # game/screens.rpy:1174
    old "End Replay"
    new ""

    # game/screens.rpy:1178
    old "Credits"
    new "クレジット"

    # game/screens.rpy:1304
    old "Setting"
    new "設定"

    # game/screens.rpy:1509
    old "About"
    new "ゲームについて"

    # game/screens.rpy:1517
    old "Version [config.version!t]\n"
    new "バージョン"

    # game/screens.rpy:1523
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "{a=https://www.renpy.org/}Ren 'Py{/a}で制作 [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:1563
    old "Page {}"
    new "ページ"

    # game/screens.rpy:1563
    old "Automatic saves"
    new "オートセーブ"

    # game/screens.rpy:1563
    old "Quick saves"
    new "クイックセーブ"

    # game/screens.rpy:1605
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%Y %B %d %A, %H:%M"

    # game/screens.rpy:1605
    old "empty slot"
    new "セーブスロット"

    # game/screens.rpy:1631
    old "<"
    new "<"

    # game/screens.rpy:1634
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:1637
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:1643
    old ">"
    new ">"

    # game/screens.rpy:1701
    old "Preferences"
    new ""

    # game/screens.rpy:1712
    old "Display"
    new "画面サイズ"

    # game/screens.rpy:1713
    old "Window"
    new "ウィンドウ"

    # game/screens.rpy:1714
    old "Fullscreen"
    new "フルスクリーン"

    # game/screens.rpy:1719
    old "Unseen Text"
    new "未読スキップ"

    # game/screens.rpy:1720
    old "After Choices"
    new "選択後も継続してスキップ"

    # game/screens.rpy:1721
    old "Transitions"
    new "場面転換まで"

    # game/screens.rpy:1725
    old "Language"
    new "言語"

    # game/screens.rpy:1727
    old "English"
    new "English"

    # game/screens.rpy:1728
    old "繁體中文"
    new "繁體中文"

    # game/screens.rpy:1729
    old "日本語"
    new "日本語"

    # game/screens.rpy:1743
    old "Text Speed"
    new "テキスト表示速度"

    # game/screens.rpy:1747
    old "Auto-Forward Time"
    new "オートモード"

    # game/screens.rpy:1754
    old "Music Volume"
    new "BGM調整"

    # game/screens.rpy:1761
    old "Sound Volume"
    new "効果音調整"

    # game/screens.rpy:1767
    old "Test"
    new "テスト"

    # game/screens.rpy:1782
    old "Mute All"
    new "すべてミュート"

    # game/screens.rpy:1905
    old "The dialogue history is empty."
    new "表示出来るログはありません"

    # game/screens.rpy:1965
    old "Help"
    new ""

    # game/screens.rpy:1974
    old "Keyboard"
    new ""

    # game/screens.rpy:1975
    old "Mouse"
    new ""

    # game/screens.rpy:1978
    old "Gamepad"
    new ""

    # game/screens.rpy:1990
    old "Enter"
    new ""

    # game/screens.rpy:1991
    old "Advances dialogue and activates the interface."
    new ""

    # game/screens.rpy:1994
    old "Space"
    new ""

    # game/screens.rpy:1995
    old "Advances dialogue without selecting choices."
    new ""

    # game/screens.rpy:1998
    old "Arrow Keys"
    new ""

    # game/screens.rpy:1999
    old "Navigate the interface."
    new ""

    # game/screens.rpy:2002
    old "Escape"
    new ""

    # game/screens.rpy:2003
    old "Accesses the game menu."
    new ""

    # game/screens.rpy:2006
    old "Ctrl"
    new ""

    # game/screens.rpy:2007
    old "Skips dialogue while held down."
    new ""

    # game/screens.rpy:2010
    old "Tab"
    new ""

    # game/screens.rpy:2011
    old "Toggles dialogue skipping."
    new ""

    # game/screens.rpy:2014
    old "Page Up"
    new ""

    # game/screens.rpy:2015
    old "Rolls back to earlier dialogue."
    new ""

    # game/screens.rpy:2018
    old "Page Down"
    new ""

    # game/screens.rpy:2019
    old "Rolls forward to later dialogue."
    new ""

    # game/screens.rpy:2023
    old "Hides the user interface."
    new ""

    # game/screens.rpy:2027
    old "Takes a screenshot."
    new ""

    # game/screens.rpy:2035
    old "Opens the accessibility menu."
    new ""

    # game/screens.rpy:2041
    old "Left Click"
    new ""

    # game/screens.rpy:2045
    old "Middle Click"
    new ""

    # game/screens.rpy:2049
    old "Right Click"
    new ""

    # game/screens.rpy:2053
    old "Mouse Wheel Up"
    new ""

    # game/screens.rpy:2057
    old "Mouse Wheel Down"
    new ""

    # game/screens.rpy:2063
    old "Right Trigger\nA/Bottom Button"
    new ""

    # game/screens.rpy:2067
    old "Left Trigger\nLeft Shoulder"
    new ""

    # game/screens.rpy:2071
    old "Right Shoulder"
    new ""

    # game/screens.rpy:2075
    old "D-Pad, Sticks"
    new ""

    # game/screens.rpy:2079
    old "Start, Guide, B/Right Button"
    new ""

    # game/screens.rpy:2083
    old "Y/Top Button"
    new ""

    # game/screens.rpy:2086
    old "Calibrate"
    new ""

    # game/screens.rpy:2153
    old "Yes"
    new "はい"

    # game/screens.rpy:2154
    old "No"
    new "いいえ"

    # game/screens.rpy:2202
    old "Skipping"
    new "スキップ"

    # game/screens.rpy:2513
    old "Auto"
    new "オート"

    # game/screens.rpy:2514
    old "Menu"
    new "メニュー"
# TODO: Translation updated at 2024-06-17 18:03

translate japanese strings:

    # game/screens.rpy:1461
    old "{font=GlowSansSC-Normal-Regular.ttf}讀檔{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}讀檔{/font}"

    # game/screens.rpy:1462
    old "{font=GlowSansSC-Normal-Regular.ttf}對話歷史{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}對話歷史{/font}"

    # game/screens.rpy:1463
    old "{font=GlowSansSC-Normal-Regular.ttf}設定{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}設定{/font}"

    # game/screens.rpy:1464
    old "{font=GlowSansSC-Normal-Regular.ttf}致謝名單{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}致謝名單{/font}"

    # game/screens.rpy:1467
    old "{font=GlowSansSC-Normal-Regular.ttf}主選單{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}主選單{/font}"

    # game/screens.rpy:1475
    old "{font=GlowSansSC-Normal-Regular.ttf}退出{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}退出{/font}"

    # game/screens.rpy:1477
    old "{font=GlowSansSC-Normal-Regular.ttf}ロード{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}ロード{/font}"

    # game/screens.rpy:1478
    old "{font=GlowSansSC-Normal-Regular.ttf}ログ{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}ログ{/font}"

    # game/screens.rpy:1480
    old "{font=GlowSansSC-Normal-Regular.ttf}クレジット{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}クレジット{/font}"

    # game/screens.rpy:1483
    old "{font=GlowSansSC-Normal-Regular.ttf}メインメニュー{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}メインメニュー{/font}"

    # game/screens.rpy:1491
    old "{font=GlowSansSC-Normal-Regular.ttf}戻る{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}戻る{/font}"

    # game/screens.rpy:1619
    old "{font=GlowSansSC-Normal-Regular.ttf}存檔{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}存檔{/font}"

    # game/screens.rpy:1627
    old "{font=GlowSansSC-Normal-Regular.ttf}セーブ{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}セーブ{/font}"

    # game/screens.rpy:2099
    old "Play Credits"
    new "クレジットを見る"

    # game/screens.rpy:2114
    old "Do you want to watch the video?"
    new "クレジットを再生しますか？"

    # game/screens.rpy:2226
    old "delete"
    new "delete"

    # game/screens.rpy:2330
    old "視窗化"
    new "視窗化"

    # game/screens.rpy:2331
    old "全螢幕"
    new "全螢幕"

    # game/screens.rpy:2333
    old "ウィンドウ"
    new "ウィンドウ"

    # game/screens.rpy:2334
    old "フルスクリーン"
    new "フルスクリーン"

    # game/screens.rpy:2805
    old "Are you sure you want to start a new game?"
    new "新しくゲームを始めますか？\n現在のデータは失われます。"

# TODO: Translation updated at 2024-06-18 13:39

translate japanese strings:

    # game/screens.rpy:2241
    old "{size=20}delete save{/size}"
    new "{size=20}セーブを削除{/size}"
# TODO: Translation updated at 2024-06-19 00:13

translate japanese strings:

    # game/screens.rpy:1922
    old "{size=20}Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]{/size}"
    new "{size=20}{a=https://www.renpy.org/}Ren 'Py{/a}で制作 [renpy.version_only].\n\n[renpy.license!t]{/size}"

# TODO: Translation updated at 2024-06-19 14:34

translate japanese strings:

    # game/screens.rpy:1501
    old "{font=GlowSansSC-Normal-Regular.ttf}ゲーム終了{/font}"
    new "{font=GlowSansSC-Normal-Regular.ttf}ゲーム終了{/font}"

# TODO: Translation updated at 2024-06-21 00:27

translate japanese strings:

    # game/screens.rpy:1034
    old "Your A.S.H. Archive has been updated with the latest achievements!"
    new "A.S.H. アーカイブで実績が更新されました！"

# TODO: Translation updated at 2025-04-18 14:14

translate japanese strings:

    # game/screens.rpy:1291
    old "QTE_CA_00"
    new "QTE_CA_00"

    # game/screens.rpy:1292
    old "QTE_CA_01"
    new "QTE_CA_01"

    # game/screens.rpy:1293
    old "QTE_FR_01"
    new "QTE_FR_01"

    # game/screens.rpy:1294
    old "QTE_FR_03"
    new "QTE_FR_03"

    # game/screens.rpy:1472
    old "讀檔"
    new "讀檔"

    # game/screens.rpy:1473
    old "對話歷史"
    new "對話歷史"

    # game/screens.rpy:1474
    old "設定"
    new "設定"

    # game/screens.rpy:1475
    old "致謝名單"
    new "致謝名單"

    # game/screens.rpy:1478
    old "主選單"
    new "主選單"

    # game/screens.rpy:1486
    old "退出"
    new "退出"

    # game/screens.rpy:1488
    old "ロード"
    new "ロード"

    # game/screens.rpy:1489
    old "ログ"
    new "ログ"

    # game/screens.rpy:1491
    old "クレジット"
    new "クレジット"

    # game/screens.rpy:1494
    old "メインメニュー"
    new "メインメニュー"

    # game/screens.rpy:1502
    old "ゲーム終了"
    new "ゲーム終了"

    # game/screens.rpy:1635
    old "存檔"
    new "存檔"

    # game/screens.rpy:1643
    old "セーブ"
    new "セーブ"

    # game/screens.rpy:2055
    old "{size=20}delete{/size}"
    new "{size=20}削除{/size}"

# TODO: Translation updated at 2025-05-21 11:46

translate japanese strings:

    # game/screens.rpy:676
    old "Krisis Journal"
    new "クライシス日記"

translate japanese strings:

    # game/screens.rpy:249
    old "Congratulations! Moo~~~"
    new "おめでとう！モォ〜〜〜〜〜！"

    # game/screens.rpy:252
    old "Your Krisis Journal has been updated! Peek inside \nfor new Photo Diary moments, 4K-worthy Secret \nSnaps, and Travel Gallery souvenirs with the Vezcrewneers!"
    new "『クライシス日記』が更新されました！\n新しいフォトダイアリーの瞬間、4K画質のシークレットスナップ、\nそしてヴェズクルーニアーズとの旅のギャラリーが追加されています！"

    # game/screens.rpy:258
    old "Congratulations! Oui ball!!"
    new "おめでとう！Oui ball!!"

    # game/screens.rpy:261
    old "Your Krisis Journal has been updated with\nthe latest achievements!"
    new "あなたの『クライシス日記』が更新されました！"

    # game/screens.rpy:267
    old "Giga Congratulations!"
    new "超おめでとう！"

    # game/screens.rpy:270
    old "You did it, hero. The Krisis Journal now holds every memory from your journey. Go relive the magic!"
    new "やったね、ヒーロー！『クライシス日記』には、\nあなたの旅のすべての思い出が詰まってます。\nさあ、もう一度あの魔法を味わいましょう！"

    # game/screens.rpy:686
    old "Chapter 1"
    new "一章スタート"

    # game/screens.rpy:687
    old "Chapter 2"
    new "二章スタート"

    # game/screens.rpy:688
    old "Chapter 3"
    new "三章スタート"

