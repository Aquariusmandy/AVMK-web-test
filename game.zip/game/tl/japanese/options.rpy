﻿# TODO: Translation updated at 2024-06-08 01:57

translate japanese strings:

    # game/options.rpy:14
    old "Full_alpha_2"
    new "Full_alpha_"
# TODO: Translation updated at 2024-06-17 18:03

translate japanese strings:

    # game/options.rpy:14
    old "BetaTest"
    new "BetaTest"

# TODO: Translation updated at 2025-04-18 14:14

translate japanese strings:

    # game/options.rpy:14
    old "Krisis En Voyage"
    new "Krisis En Voyage"

