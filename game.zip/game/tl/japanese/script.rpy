﻿
# TODO: Translation updated at 2025-04-18 14:14

translate japanese strings:

    # game/script.rpy:261
    old "Vantacrow"
    new "ベンタクロウ"

    # game/script.rpy:262
    old "Wilson"
    new "ウィルソン"

    # game/script.rpy:263
    old "Vezalius"
    new "ヴェザリウス"

    # game/script.rpy:264
    old "Wilson & Vantacrow"
    new "{size=30}ウィルソン & ベンタクロウ{/size}"

    # game/script.rpy:265
    old "Vantacrow & Vezalius"
    new "{size=30}ベンタクロウ & ヴェザリウス{/size}"

    # game/script.rpy:266
    old "Vezalius & Wilson"
    new "{size=230}ヴェザリウス & ウィルソン{/size}"

    # game/script.rpy:267
    old "Vantacrow & Crew"
    new ""

    # game/script.rpy:268
    old "Farmer"
    new "農夫"

    # game/script.rpy:269
    old "Forest Ranger"
    new "森林警備員"

    # game/script.rpy:270
    old "Rich Lady"
    new "リッチレディ"

    # game/script.rpy:271
    old "Mana"
    new "マナ"

    # game/script.rpy:272
    old "Rai"
    new "ライ"

    # game/script.rpy:647
    old "{font=final}{size=120}EHHHHHH!!?{/size}{/font}"
    new "{font=final}{size=120}ええええええっ!!?{/size}{/font}"