
translate mandarin strings:

    # game/qte.rpy:154
    old "Try again my hero!"
    new "再試一次吧，英雄！"

   

