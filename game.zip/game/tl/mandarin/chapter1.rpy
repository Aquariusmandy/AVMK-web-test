﻿# TODO: Translation updated at 2025-05-21 11:56

# game/chapter1.rpy:14
translate mandarin chapter_1_9dde5f4b:

    # "Hey, your name is Vantacrow Bringer."
    "嘿，你的名字是 Vantacrow Bringer。"

# game/chapter1.rpy:15
translate mandarin chapter_1_7e2b3532:

    # "The Tyrant and Ace of Krisis that works under A.S.H.—or the Astronomically Sexy Heroes."
    "你是 A.S.H.（或宇宙無敵性感英雄團）所屬，Krisis 的暴君兼王牌。"

# game/chapter1.rpy:16
translate mandarin chapter_1_0618aa75:

    # "Well, you've been saving old women and beating up bad guys with your exceptional fists."
    "一直以來你都用著你非凡的拳頭拯救老奶奶和打擊惡勢力。 "

# game/chapter1.rpy:17
translate mandarin chapter_1_3e03de08:

    # "But today? Today is different."
    "但今天？今天可不同往常。"

# game/chapter1.rpy:18
translate mandarin chapter_1_50543284:

    # "Instead of heading into the A.S.H. office like usual, you're in a car. Driving, actually."
    "你今天並沒有像平常一樣去 A.S.H. 辦公室，而是開著車，在路上奔馳。"

# game/chapter1.rpy:19
translate mandarin chapter_1_99014dd5:

    # "Sitting next to you is your teammate, the former hitman Yu Q. Wilson, and in the back, the medic hero, Vezalius Bandage."
    "坐在你旁邊的是你的隊友，前殺手 Yu Q. Wilson，而在後面的是醫療英雄 Vezalius Bandage。"

# game/chapter1.rpy:22
translate mandarin chapter_1_5077bc57:

    # vanta_char "Wilson, I gotta say—this road trip was a really good call."
    vanta_char "Wilson，我得說——這次的公路旅行真是個好主意。"

# game/chapter1.rpy:26
translate mandarin chapter_1_f6c57937:

    # wilson_char "Right? With the Vezcrewneers on holiday, there's no way we are gonna sit around in an empty office all day."
    wilson_char "對吧？Vezcrewneers 都放假了，我們怎麼可以整天待在空蕩蕩的辦公室裡。"

# game/chapter1.rpy:31
translate mandarin chapter_1_346f36b5:

    # zali_char "Exactly! The sun's out, the timing is perfect—I love a good summer getaway!"
    zali_char "確實！陽光正好，這時機簡直完美——我喜歡夏日出遊！"

# game/chapter1.rpy:36
translate mandarin chapter_1_7d9e48cc:

    # "It is a beautiful summer day in Canada. The trees sway gently in the warm breeze, their leaves shimmering under the golden sunlight, casting dappled shadows across the forest. The air carries a faint, earthy scent of pine and wildflowers."
    "這是個加拿大美麗的夏天。樹木在暖風中輕柔搖曳，葉片在金色陽光下閃閃發亮，往森林裡投射斑駁的陰影。空氣承載著微弱的松木與野花的清新香氣。"

# game/chapter1.rpy:37
translate mandarin chapter_1_c3bb6ea5:

    # "This is your first time driving in Canada—not that you're nervous. As an experienced driver, this is exactly how you want to spend the day—with your homies, cruising down the open road on a perfect summer day."
    "這是你第一次在加拿大開車——你才不緊張呢。身為一個老司機，這正是你想度日的方式——在完美的夏日和你的好 homie 駛過開闊的路段。"

# game/chapter1.rpy:38
translate mandarin chapter_1_9472b343:

    # "The three of you belt out lyrics to Super Duper, Wilson tossing out random hypotheticals, and Zali's laughter filling the gaps."
    "你們三人大聲唱著 Super Duper 的歌詞，Wilson 拋出各種天馬行空的的假說，而 Zali 的笑聲填補了空隙。"

# game/chapter1.rpy:40
translate mandarin chapter_1_20e188ee:

    # wilson_char "Zali, can you grab me a snack? Vanta, want some water?"
    wilson_char "Zali，可以幫我拿個零食嗎？Vanta，要喝水嗎？"

# game/chapter1.rpy:42
translate mandarin chapter_1_01ea1371:

    # vanta_char "Wilson, I swear to god, eat your snack in one bite. If you leave crumbs everywhere—"
    vanta_char "Wilson，算我求你了，一口吃完你的零食。如果你把屑屑掉得到處都是——"

# game/chapter1.rpy:44
translate mandarin chapter_1_50cb6f5e:

    # zali_char "Haha! Here you go...and here's the water."
    zali_char "哈哈！給你⋯⋯還有你的水。"

# game/chapter1.rpy:47
translate mandarin chapter_1_9a61ab37:

    # wilson_char "Thanks, Mommy—I mean, Zali... Wait, Vanta!"
    wilson_char "謝了，Mommy——我是說，Zali……等等，Vanta！"

# game/chapter1.rpy:48
translate mandarin chapter_1_fc6b879b:

    # wilson_char "There's a deer up ahead!"
    wilson_char "前面有隻鹿！"

# game/chapter1.rpy:58
translate mandarin chapter_1_1_8cd855ec:

    # "You see it—a deer. Your reflexes kick in."
    "你看到了——是一隻鹿。是時候考驗反應了。"

# game/chapter1.rpy:78
translate mandarin tutorial_timeout_45079c71:

    # "You brake a moment too late, jolting the car. The deer makes it across safely, but Zali fumbles the bottle, sending water flying straight into Wilson's face."
    "你太晚煞車，導致車子顛簸。雖然鹿安全抵達了路的另一邊，但 Zali 沒拿穩瓶子，水濺了\nWilson 一臉。"

# game/chapter1.rpy:80
translate mandarin tutorial_timeout_12d88a79:

    # wilson_char "Gah! My face! I knew it—I'm not safe even in the passenger seat!"
    wilson_char "哇！我的臉！我就知道——我就連在副駕也無法倖免！"

# game/chapter1.rpy:83
translate mandarin tutorial_timeout_5e7d52ce:

    # vanta_char "Sorry about that, bro."
    vanta_char "抱歉啦，兄弟。"

# game/chapter1.rpy:94
translate mandarin tutorial_clear_6be43a09:

    # "You slam the brakes ahead of time, easily avoiding the deer as it darts across the road."
    "你即時踩下了煞車，並輕易在那頭鹿飛奔過去時閃過。"

# game/chapter1.rpy:96
translate mandarin tutorial_clear_584ee927:

    # wilson_char "Nice! Awwn, the deer is sho cyute!"
    wilson_char "太好了！噢，這隻鹿也太口愛了吧！"

# game/chapter1.rpy:99
translate mandarin tutorial_clear_a9f61f8e:

    # zali_char "There, Vanta, your water here."
    zali_char "Vanta，水給你。"

# game/chapter1.rpy:102
translate mandarin tutorial_clear_c760d7e8:

    # vanta_char "Thanks, Zali!"
    vanta_char "謝啦，Zali！"

# game/chapter1.rpy:107
translate mandarin chapter_1_2_9bcb70d7:

    # "After the unexpected deer encounter (and Wilson's running commentary), you finally arrive at your destination."
    "在與一隻鹿不期而遇（以及 Wilson 源源不絕的評論）後，你們終於抵達了目的地。"

# game/chapter1.rpy:111
translate mandarin chapter_1_2_fd0b80bf:

    # "Towering mountains rise in the distance, a crystal-clear lake sparkles at its center, and cozy cabins nestle along the edges, blending naturally into the serene landscape."
    "遠處矗立著高聳的山，中央清澈的湖面波光粼粼。舒適的屋子依偎著山的邊緣，自然地融入這寧靜的風景。"

# game/chapter1.rpy:114
translate mandarin chapter_1_2_5e996afc:

    # wilson_char "Wow! This is so nice! I love a Canadian summer."
    wilson_char "哇！這也太讚了吧！我超愛加拿大的夏天。"

# game/chapter1.rpy:117
translate mandarin chapter_1_2_84e03dcb:

    # zali_char "Oh yeah! The cabin looks quite big as well. We are lucky to get a cabin this size last minute."
    zali_char "對啊！而且屋子看起來也很大。沒想到我們還能在最後一刻訂到這麼大的木屋。"

# game/chapter1.rpy:121
translate mandarin chapter_1_2_4a415756:

    # "You pull up outside the cabin, stepping out into the fresh mountain air. The three of you grab your bags, Wilson striding ahead to the door and pushing it open."
    "你們在屋外停車，在踏出車外那刻便被山中清新的空氣迎接。你們三人拿起包包，Wilson 大步向門走去並推開了門。"

# game/chapter1.rpy:122
translate mandarin chapter_1_2_0b892c3b:

    # "As you pause to enjoy the scenery, your gaze drifts to the swaying treetops and the\nsunlight spilling across the peaks. The view is simply breathtaking, a moment worth holding onto forever."
    "正當你停下來享受景致時，你的視線飄向搖曳的樹梢和灑落在山峰上的陽光。這風景簡直美得令人屏息，值得永久珍藏。"

# game/chapter1.rpy:133
translate mandarin chapter_1_2_85482238:

    # "You pull out your phone and snap a quick picture of the landscape, capturing the golden afternoon hues. Sliding your phone back into your pocket, you walk toward the cabin."
    "你掏出手機並快速拍了張風景照，成功捕捉了金色的午後景致。將手機放回口袋後，你繼續\n前往小屋。"

# game/chapter1.rpy:137
translate mandarin chapter_1_2_bd9ba639:

    # wilson_char "Wait what? Umm, guys? So..."
    wilson_char "等等，什麼？嗯……大家……所以……"

# game/chapter1.rpy:139
translate mandarin chapter_1_2_3faa6ffa:

    # vanta_char "Hmm? What's wrong?"
    vanta_char "嗯？怎麼了？"

# game/chapter1.rpy:140
translate mandarin chapter_1_2_3b5b02ce:

    # "You drop the luggage by the door, following Wilson's voice. Your eyes scan the cabin's interior—warm, cozy, and... Oh. One big bed? Really?"
    "聽見 Wilson 的聲音後，你把行李放在門邊，視線掃過屋子的內裡——溫馨、舒適，還有……哦！一張大床？真的假的？"

# game/chapter1.rpy:141
translate mandarin chapter_1_2_08461e11:

    # wilson_char "There's...only one bed..."
    wilson_char "這裡……只有一張床……"

# game/chapter1.rpy:144
translate mandarin chapter_1_2_4a36edfd:

    # zali_char "Ah, I can sleep on the couch—"
    zali_char "啊，那我可以睡沙發——"

# game/chapter1.rpy:147
translate mandarin chapter_1_2_7ec0d30f:

    # vanta_char "Nope, not happening. It looks like the bed's big enough for the three of us, though."
    vanta_char "不行，不可以。這張床看起來大到可以睡下我們三個。"

# game/chapter1.rpy:149
translate mandarin chapter_1_2_9991f5eb:

    # wilson_char "I call left side!"
    wilson_char "我要睡左邊！"

# game/chapter1.rpy:153
translate mandarin chapter_1_2_5a3aa98c:

    # "Before anyone could object, Wilson walks to the bed and plops onto it, rolling over to\nthe left side."
    "在任何人來得及反駁前，Wilson 便直直走過去，跳上床後滾到左邊。"

# game/chapter1.rpy:155
translate mandarin chapter_1_2_b296198f:

    # vanta_char "Do you have a preference, Zali?"
    vanta_char "Zali，你有特別想要的位置嗎？"

# game/chapter1.rpy:157
translate mandarin chapter_1_2_ef65b016:

    # zali_char "No, not really. I can take the spot next to Wilson."
    zali_char "我都可以，那我睡 Wilson 旁邊好了。"

# game/chapter1.rpy:158
translate mandarin chapter_1_2_4b554111:

    # vanta_char "Alright, sure, I will be on the right side."
    vanta_char "好，那我睡右邊。"

# game/chapter1.rpy:162
translate mandarin chapter_1_2_69c01c46:

    # wilson_char "Shall we unpack and find some food before it gets dark?"
    wilson_char "我們天黑前是不是應該先整理行李，然後再去覓食啊？"

# game/chapter1.rpy:165
translate mandarin chapter_1_2_c462a460:

    # "Agreeing with Wilson, you settle into the cabin and begin unpacking. The warmth of the room contrasts with the crisp air outside. After sorting out your bags, you three head into town to grab ingredients for the dinner tonight."
    "你們同意了 Wilson 的提議，之後在屋內安頓下來並整理好行李。房裡的溫暖與室外傍晚冷冽的空氣相互映襯。整理好行李後，你們三人進到小鎮裡採購今天晚餐的食材。"

# game/chapter1.rpy:171
translate mandarin chapter_1_2_b3e9ff5c:

    # "As you make your way toward the shop, something catches your attention—random piles of timber debris scattered near people's homes. There hasn't been a storm recently, making the sight unusual."
    "在你們朝商店走去時，有什麼東西吸引了你們的注意力——散落於住宅周圍的木材碎片。最近這裡並沒有暴風雨，因此這景象顯得十分詭異。"

# game/chapter1.rpy:174
translate mandarin chapter_1_2_6526bcf4:

    # vanta_char "That's weird. What exactly happened here?"
    vanta_char "奇怪，到底發生了什麼事？"

# game/chapter1.rpy:175
translate mandarin chapter_1_2_61f1b00b:

    # "A group of forest rangers stands outside the grocery store, their conversation growing louder as you approach. A farmer, clearly upset, joins them, gesturing at his broken fence and mentioning strange footprints he found near his farm."
    "雜貨店外站著一群森林護管員，而他們對話的音量在你們靠近時逐漸上升。一位面露沮喪的農夫加入他們，他指向毀損的圍籬，且提到了他在農場附近發現的怪異腳印。"

# game/chapter1.rpy:176
translate mandarin chapter_1_2_8abb259c:

    # vanta_char "Do you think all this wood and debris has something to do with what they're talking about?"
    vanta_char "你們覺得這些碎木和他們在討論的事有關嗎？"

# game/chapter1.rpy:180
translate mandarin chapter_1_2_9fa6e9f5:

    # wilson_char "What if something happened? Oh... Don't tell me that's why we could book the last cabin on such short notice..."
    wilson_char "是不是出事了？哦……別跟我說這就是為什麼我們可以臨時訂到房……"

# game/chapter1.rpy:184
translate mandarin chapter_1_2_c7826e0a:

    # zali_char "Hmm... Let's check it out. Maybe there's something we can help with."
    zali_char "去看看吧，說不定我們能幫上忙。"

# game/chapter1.rpy:189
translate mandarin chapter_1_2_8d2234ca:

    # "You three walk up to the forest rangers and the farmer, introducing yourselves as heroes from A.S.H.—here for a camping trip."
    "你們三個走向那群森林護管員和農夫，並進行自我介紹——你們是 A.S.H. 的英雄，今天正好\n來這裡露營。"

# game/chapter1.rpy:192
translate mandarin chapter_1_2_17a5d887:

    # forest_ranger_char "Heroes? Isn't this perfect timing? You guys might be able to help us investigate..."
    forest_ranger_char "英雄？這時機太完美了吧？你們應該可以幫忙調查……"

# game/chapter1.rpy:194
translate mandarin chapter_1_2_55a24edf:

    # zali_char "What happened? Is everything okay?"
    zali_char "怎麼了？沒事吧？"

# game/chapter1.rpy:195
translate mandarin chapter_1_2_b58471d0:

    # forest_ranger_char "Something—or someone—is going through our village, tearing apart fences and breaking into storage sheds. It's leaving a mess everywhere."
    forest_ranger_char "有什麼東西——還是什麼人——來過我們的村子，破壞了圍籬，又闖進了倉庫，把到處都搞得\n亂七八糟。"

# game/chapter1.rpy:198
translate mandarin chapter_1_2_7ed3de24:

    # wilson_char "How long has this been going on? Is this area home to bears or something? But those footprints... Hmm..."
    wilson_char "這件事已經發生多久了？這裡很接近熊的棲息地嗎？但那些腳印……嗯……"

# game/chapter1.rpy:199
translate mandarin chapter_1_2_d07e16c3:

    # forest_ranger_char "These started showing up a few days ago, right after some villagers reported strange noises at night. Whatever made them must have been enormous. I've never seen anything like them."
    forest_ranger_char "幾天前村民回報晚上有奇怪的噪音，之後腳印就馬上出現了。噪音來源一定是某種龐然大物，我從來沒見過這種東西。"

# game/chapter1.rpy:200
translate mandarin chapter_1_2_6d9f05ef:

    # "Wilson walks over to one of the massive footprints, crouching to examine it closely. His fingers trace the edges, and his brow furrows as he inspects the depth and the odd contours of its shape."
    "Wilson 走向其中一個巨大的腳印，並蹲下仔細觀察。他用手指沿著邊緣撫摸，並在看見它的深度和詭異的形狀與輪廓後皺起眉頭。"

# game/chapter1.rpy:201
translate mandarin chapter_1_2_397bed70:

    # wilson_char "I mean... I know it's cliché but... Bigfoot in Canada?"
    wilson_char "我知道這已經是老哏了，但……加拿大也有大腳怪？"

# game/chapter1.rpy:204
translate mandarin chapter_1_2_7b878d61:

    # vanta_char "Hmm... It is interesting indeed. We'll help investigate and see if we can find this...thing."
    vanta_char "嗯，確實很奇特。我們會協助調查並看看我們能不能找到這個……東西。"

# game/chapter1.rpy:207
translate mandarin chapter_1_2_fcc47d56:

    # zali_char "We definitely don't want more damage to people's homes. If you notice anything unusual, let us know. Our cabin is just down the road."
    zali_char "我們絕對不希望居民受到更多傷害。如果你有注意到任何不尋常的事情，請通知我們。我們的小木屋就在道路盡頭。"

# game/chapter1.rpy:208
translate mandarin chapter_1_2_63eee9a8:

    # forest_ranger_char "That would be a huge help! I knew we can always count on the heroes!"
    forest_ranger_char "幫大忙了！我就知道依靠英雄總不會錯。"

# game/chapter1.rpy:213
translate mandarin chapter_1_2_3cc4193f:

    # farmer_char "Could you guys help me, too?"
    farmer_char "你們也可以幫我嗎？"

# game/chapter1.rpy:215
translate mandarin chapter_1_2_cb621d33:

    # wilson_char "Sure! What's going on?"
    wilson_char "當然！發生什麼事了？"

# game/chapter1.rpy:216
translate mandarin chapter_1_2_12f45844:

    # farmer_char "Whatever this thing is, it destroyed my fences and scared off my cows—they're all over the place! I'm so worried... There's even a calf missing!"
    farmer_char "有東西破壞了我的籬笆，還嚇跑了我的牛。現在牠們到處亂跑！我很擔心……而且還有一隻小牛\n走失了！"

# game/chapter1.rpy:218
translate mandarin chapter_1_2_6d7b800e:

    # wilson_char "Animals in distress? Of course I'll help. I, for one, know cows very well. Mooing is kind of my specialty."
    wilson_char "有動物陷入危機了嗎？我們當然願意協助。就我而言，我很瞭解牛。Moo moo 叫可是我的專長呢。"

# game/chapter1.rpy:219
translate mandarin chapter_1_2_15ef97a7:

    # farmer_char "Oh really? Bless you, my boy! Come with me!"
    farmer_char "真的嗎？太感謝了，年輕人！跟我來！"

# game/chapter1.rpy:222
translate mandarin chapter_1_2_9659012f:

    # zali_char "Alright, guys, how about this? I'll grab the ingredients and head back to camp. If I see anything suspicious, I'll let you know."
    zali_char "那大家，這樣如何？我去採購食材，之後直接回到營地。如果有看到任何可疑的東西，我會馬上和你們聯絡。"

# game/chapter1.rpy:224
translate mandarin chapter_1_2_fe236532:

    # wilson_char "Sounds good! I'll go find the cows with this guy."
    wilson_char "就這樣說定了！我和這位小哥一起去找牛。"

# game/chapter1.rpy:231
translate mandarin chapter_1_2_e9e480d6:

    # "That leaves you to make a choice: help Zali pick up groceries and head back to camp,\nor join Wilson in tracking down the missing cows for the distraught farmer."
    "於是你必須做出選擇：幫 Zali 挑選食材後回到營區，或者和 Wilson 一起幫慌亂的農夫尋找\n失蹤的牛隻。"

# game/chapter1.rpy:244
translate mandarin chapter_1_2_72b42f5a:

    # "You decide to help Wilson find the cows. But before you can say anything, the farmer reaches into his back pocket and pulls out a comically large pair of cow costumes."
    "你決定幫 Wilson 一起找牛。但你還來不及出聲，農夫便從後口袋拿出兩件誇張大的乳牛裝。"

# game/chapter1.rpy:247
translate mandarin chapter_1_2_84da4eaf:

    # vanta_char "Wh— Do you just have those on hand?"
    vanta_char "什——你隨身攜帶這個嗎？"

# game/chapter1.rpy:250
translate mandarin chapter_1_2_3d97b8e6:

    # farmer_char "Of course! You never know when you'll need a good cow disguise."
    farmer_char "當然！你永遠不會知道你什麼時候會需要一套做工精良的乳牛裝。"

# game/chapter1.rpy:251
translate mandarin chapter_1_2_71dfae6e:

    # farmer_char "Anyway, thank you so much, boys. Oh, and while you're at it, you wouldn't mind taking a few special commemorative photos for me, would you? You know, for branding purposes."
    farmer_char "總之太感謝了。對了，你們應該不介意讓我拍幾張照片作紀念吧？這是為了品牌行銷。"

# game/chapter1.rpy:254
translate mandarin chapter_1_2_f321b96b:

    # wilson_char "I mean... Sure! Why not! Right, Vanta?"
    wilson_char "當然！有何不可！是吧，Vanta？"

# game/chapter1.rpy:258
translate mandarin chapter_1_2_89703e32:

    # "You have a very bad feeling about this."
    "你有糟糕的預感。"

# game/chapter1.rpy:259
translate mandarin chapter_1_2_a7dab79c:

    # "You look over to Wilson, expecting him to share your unease. Instead, his eyes light\nup with excitement."
    "你看向 Wilson，期望他能分擔你的不自在，然而他的雙眼卻因興奮而閃閃發光。"

# game/chapter1.rpy:261
translate mandarin chapter_1_2_06ad5655:

    # wilson_char "We get to be cowboys?! Awesome!"
    wilson_char "我們可以當牛仔？太讚了！"

# game/chapter1.rpy:262
translate mandarin chapter_1_2_c8347f24:

    # wilson_char "Come on Vanta, put on the suit! Oh man, I need to practice my moos."
    wilson_char "拜託，Vanta，換上套裝！噢，天啊！是時候練習 moo 了。"

# game/chapter1.rpy:264
translate mandarin chapter_1_2_56dac3dd:

    # vanta_char "Oh my god... You're just gonna go with it?! No questions asked?!"
    vanta_char "你就這樣接受了？你一點都不想吐槽嗎？"

# game/chapter1.rpy:265
translate mandarin chapter_1_2_968db1e7:

    # wilson_char "What's there to ask? We get to become cowboys and save this poor farmer's cows, too!"
    wilson_char "有什麼好吐槽的？我們可以當牛仔，還能拯救可憐農夫的牛耶！"

# game/chapter1.rpy:268
translate mandarin chapter_1_2_80ce8262:

    # farmer_char "It's really quite effective, these things! Why? I'd wear them myself, but I hurt my knees yesterday and can't exactly get on all fours today."
    farmer_char "這些東西啊，很有效哦！要不是我昨天膝蓋受傷，無法四肢著地，否則我絕對會親自穿上這套裝。"

# game/chapter1.rpy:271
translate mandarin chapter_1_2_50d0097f:

    # vanta_char "What do you mean on all fours?! I should've just gone with Zali..."
    vanta_char "四肢著地是什麼意思？！我當初應該跟 Zali 去買菜的……"

# game/chapter1.rpy:272
translate mandarin chapter_1_2_8ae8dee7:

    # "Wilson drags you along to change into your costumes, while you follow behind with much less enthusiasm."
    "Wilson 拉著你一起去換裝，而你興趣缺缺地跟在他身後。"

# game/chapter1.rpy:275
translate mandarin chapter_1_2_acd36d5a:

    # "Soon, the both of you return to the field in your new ultimate calf herding outfit. The farmer has set up a camera some distance away. He gives you both an eager thumbs up."
    "很快你們就穿著全新究極乳牛裝回到了田野。農夫已經在不遠處架設好了相機，他熱情地對你們\n比讚。"

# game/chapter1.rpy:279
translate mandarin chapter_1_2_c2c708b6:

    # wilson_char "Should I go like: MooOOo~? Or more like: MOOooo!"
    wilson_char "我應該要「MooOOo～」嗎？還是「MOOooo！」比較好啊？"

# game/chapter1.rpy:281
translate mandarin chapter_1_2_450de447:

    # wilson_char "Arghhh! Come on, Wilson. Think like a cow!"
    wilson_char "呃啊啊！拜託，Wilson，像牛一樣思考。"

# game/chapter1.rpy:282
translate mandarin chapter_1_2_a356482d:

    # "You watch in amazement as Wilson, truly and spectacularly without dignity, commits fully to his new bovine role."
    "你傻眼地看著 Wilson 完全拋去自尊，沉浸於他嶄新的牛牛人設。"

# game/chapter1.rpy:286
translate mandarin chapter_1_2_a0f3d027:

    # vanta_char "Are you...practicing your moos?"
    vanta_char "你是在……練習哞哞叫嗎？"

# game/chapter1.rpy:287
translate mandarin chapter_1_2_da5b0796:

    # wilson_char "We have to sell it, Vanta. What kind of cow's gonna fall for your weak ass moo? Draw from the diaphragm, Vanta."
    wilson_char "Vanta，我們要全心投入。什麼樣的牛才會被你弱雞的 moo 騙啊？你要從丹田發力，Vanta。"

# game/chapter1.rpy:289
translate mandarin chapter_1_2_8fd6702d:

    # vanta_char "Mooing in a cowboy costume is not on my bucket list for this year...but I've stopped questioning my life choices."
    vanta_char "穿著乳牛裝哞哞叫並不在我今年的計畫之內……但我已經不再懷疑我的人生選擇了。"

# game/chapter1.rpy:291
translate mandarin chapter_1_2_e68299d4:

    # "You wonder if Zali is having a quieter, less humiliating time with groceries."
    "你想知道 Zali 是否正在享受一段更寧靜而不羞恥的購物時光。"

# game/chapter1.rpy:296
translate mandarin chapter_1_2_8895917d:

    # "The both of you get on all fours and begin mooing, trying to attract the calf back with your sounds. The farmer occasionally gives you both an enthusiastic thumbs up, taking photos of you the whole time."
    "你們倆四肢著地後開始哞哞叫，嘗試用叫聲將小牛吸引回來。農夫時不時熱情地對你們比讚，同時不斷幫你們拍照。"

# game/chapter1.rpy:297
translate mandarin chapter_1_2_5e869f83:

    # vanta_char "Wilson. This is absolutely the dumbest thing we've ever done.\nNothing—and I mean nothing—will ever be more stupid than this."
    vanta_char "Wilson，這是我們有史以來做過最蠢的事了。絕對沒有什麼事可以比這個更蠢了。"

# game/chapter1.rpy:298
translate mandarin chapter_1_2_ad981d3b:

    # wilson_char "{size=45}MOooOooo~~~{/size}"
    wilson_char "{size=45}MOooOooo～～～{/size}"

# game/chapter1.rpy:299
translate mandarin chapter_1_2_48e5d462:

    # "Wilson starts mooing maternally. You don't react."
    "Wilson 開始像母牛一樣哞哞叫，而你不為所動。"

# game/chapter1.rpy:300
translate mandarin chapter_1_2_83caaa14:

    # wilson_char "Come on, Vanta. That was your cue!"
    wilson_char "快點，Vanta，那是給你的暗號！"

# game/chapter1.rpy:301
translate mandarin chapter_1_2_06eae0d1:

    # vanta_char "This is so stupid..."
    vanta_char "這也太蠢了……"

# game/chapter1.rpy:302
translate mandarin chapter_1_2_e93564a7:

    # wilson_char "Don't break RP!"
    wilson_char "不要打破人設！"

# game/chapter1.rpy:303
translate mandarin chapter_1_2_a96721d5:

    # vanta_char "M...Moo~"
    vanta_char "M……Moo～"

# game/chapter1.rpy:304
translate mandarin chapter_1_2_a8457830:

    # "You moo half-heartedly."
    "你心不在焉地 moo。"

# game/chapter1.rpy:305
translate mandarin chapter_1_2_099fec82:

    # wilson_char "Moo louder! You're a concerned father! Never give up, never what?"
    wilson_char "Moo 大聲一點！你是擔心孩子的老爸，不要退縮！"

# game/chapter1.rpy:306
translate mandarin chapter_1_2_94aa6786:

    # vanta_char "Oh my god... I don't even know what that sounds like!"
    vanta_char "我的天啊……我根本不知道怎麼叫比較好！"

# game/chapter1.rpy:307
translate mandarin chapter_1_2_bbaac225:

    # wilson_char "You just have to immerse yourself in the character. Come on, try again."
    wilson_char "你只要沉浸在角色裡就好。來吧，再來一次。"

# game/chapter1.rpy:312
translate mandarin chapter_1_2_2b099d45:

    # wandv_char "{size=45}MOOOOooo~~~~~{/size}"
    wandv_char "{size=45}MOOOOooo～～～～～{/size}"

# game/chapter1.rpy:313
translate mandarin chapter_1_2_67e06060:

    # "You moo again, channeling your inner alpha cow, if that's even a thing. Wilson nods enthusiastically, joining in with his motherly moos."
    "你又 moo 了一次，呼喚著你內在的乳牛之魂（如果有這種東西的話）。Wilson 充滿熱情地點頭，並加入你一起散發「 moo 性光輝」。"

# game/chapter1.rpy:314
translate mandarin chapter_1_2_26207232:

    # "Rapid camera flashes go off in the distance. But before the shame can sink in, you spot a small brown calf poking its head out from a bush."
    "遠處傳來了陣陣快門聲。但在羞恥感再次攻擊你以前，你便看見一隻棕色的小牛從樹叢探出頭來。"

# game/chapter1.rpy:316
translate mandarin chapter_1_2_02f8562f:

    # "The calf moos shyly. Wilson lights up in excitement."
    "小牛羞澀地哞哞叫，而 Wilson 臉上寫滿了興奮。"

# game/chapter1.rpy:317
translate mandarin chapter_1_2_947e77a7:

    # wilson_char "Moo! My son is back!"
    wilson_char "Moo！我兒子回來了！Moo！"

# game/chapter1.rpy:319
translate mandarin chapter_1_2_2b4f86a5:

    # vanta_char "What do you mean your son? He clearly came out because of my moo!"
    vanta_char "什麼叫你兒子？他明明就是被我的 moo 吸引出來的！"

# game/chapter1.rpy:321
translate mandarin chapter_1_2_79aced30:

    # wilson_char "Nah. He's my son. I carried him for nine months."
    wilson_char "不，他是我的兒子。我可是懷了他九個月呢。"

# game/chapter1.rpy:322
translate mandarin chapter_1_2_eb13cb1b:

    # vanta_char "You—"
    vanta_char "你——"

# game/chapter1.rpy:323
translate mandarin chapter_1_2_1ba12b22:

    # "The farmer comes over as you start bickering, laughing as he hugs his calf with joy."
    "正當你們要開始吵架時，農夫來了。他開心地笑著，抱了抱他的小牛。"

# game/chapter1.rpy:328
translate mandarin chapter_1_2_6e7cb5ca:

    # farmer_char "Well, I'll be damned, I didn't think you'd be so good at this cowboys business. Ever thought about ranching?"
    farmer_char "我沒料到你們對牧牛那麼在行。有考慮過經營牧場嗎？"

# game/chapter1.rpy:330
translate mandarin chapter_1_2_4986aa88:

    # wilson_char "You know, I could see myself as a cowboy. Just a simple life, mooing at sunset and grazing in the fields... That's what cowboys do, right?"
    wilson_char "其實，我可以想像自己是個牛仔。就是簡單過生活，對著夕陽哞哞叫，還有在田野間放牧……這就是牛仔會做的事，對吧?"

# game/chapter1.rpy:333
translate mandarin chapter_1_2_3266b9b2:

    # vanta_char "I'm starting to think you actually don't know what a cowboy is."
    vanta_char "我開始懷疑你不知道牛仔的意思了。"

# game/chapter1.rpy:336
translate mandarin chapter_1_2_8e613f9f:

    # wilson_char "What do you mean, Vanta? You don't wanna be my cow husband?"
    wilson_char "Vanta，你什麼意思？你不想當我的牛郎嗎？"

# game/chapter1.rpy:337
translate mandarin chapter_1_2_6ee42fd0:

    # vanta_char "Please stop. I am not expanding on this. I don't even want to entertain the idea."
    vanta_char "拜託停下。我不想讓這對話繼續下去，我甚至不想開這個話題。"

# game/chapter1.rpy:339
translate mandarin chapter_1_2_5025d1c7:

    # "As the farmer thanks you both profusely and leads the calf back to its pen, you and Wilson finally peel off the absurd costumes."
    "在農夫不斷對你們道謝並把小牛帶回農場後，你和 Wilson 才脫下了可笑的套裝。"

# game/chapter1.rpy:343
translate mandarin chapter_1_2_b9ba662a:

    # "With the calf safe and the task complete, you and Wilson begin your trek back toward\nthe campsite. Sunlight fades through the trees, casting long shadows that stretch across the forest floor."
    "既然小牛安然無恙，任務也順利落幕，你們便啟程回到營地。逐漸黯淡的陽光透過林木灑下，在路面上投射一條長長的影子。"

# game/chapter1.rpy:344
translate mandarin chapter_1_2_ede955f9:

    # "As the sun dips lower, warm hues paint the surroundings, and the inviting aroma of food drifts through the air, pulling you toward the promise of dinner. Whatever Zali's been cooking must be amazing. You quicken your pace to meet him."
    "夕陽西下，將周遭染上暖和的色調。誘人的食物香氣充盈在空氣裡，吸引你們享用等待已久的晚餐。Zali 煮的料理一定會很美味。你們加快腳步，期待回去與 Zali 相聚。"

# game/chapter1.rpy:354
translate mandarin chapter_1_2_1a588cf0:

    # "Entering the cute local supermarket, you browse the shelves, grabbing ingredients.\nEggs, flour, sausages, tomatoes, spinach...and of course—a baguette. It's not a Krisis campsite dinner without a French classic."
    "走進當地可愛的超市後，你們四處搜索架上的食材。蛋、麵粉、香腸、番茄、菠菜——當然還有法國麵包。法式經典可是 Krisis 營火晚餐不可或缺的一環。"

# game/chapter1.rpy:357
translate mandarin chapter_1_2_71fc0b34:

    # zali_char "Alright, I think these should be enough..."
    zali_char "好，這樣應該就夠了……"

# game/chapter1.rpy:362
translate mandarin chapter_1_2_4403fbb7:

    # "Back at the cabin, you and Zali start prepping. Vegetables are laid out, and you're already elbow-deep in washing them."
    "回到木屋後，你和 Zali 一起開始準備食材。拿出蔬菜後，你著手開始洗菜。"

# game/chapter1.rpy:366
translate mandarin chapter_1_2_9fe2d065:

    # zali_char "Vanta, I have aprons here. Let me put one on for you. Hold still, don't move."
    zali_char "Vanta，這裡有圍裙，我來幫你穿上。站好喔，不要動。"

# game/chapter1.rpy:368
translate mandarin chapter_1_2_3c242ff0:

    # vanta_char "You're really enjoying this, huh? Tying knots and whatnot."
    vanta_char "看來你真的很享受打結之類的，是吧？"

# game/chapter1.rpy:373
translate mandarin chapter_1_2_19a5195f:

    # "Zali spins you around, expertly securing the apron strings around your waist.\nHis movements are smooth, effortless—like he's done this a hundred times before,\nwithout a hint of hesitation."
    "Zali 將你轉過身並俐落地將圍裙的帶子繫上你的腰。他的一舉一動都流暢而毫不費力，就好像已經做過了無數次一樣，動作沒有一絲猶豫。"

# game/chapter1.rpy:374
translate mandarin chapter_1_2_4b072108:

    # "His voice is steady, calm, matching the ease of his actions, and for a moment, the sounds of the camp fade into the background."
    "他聲音平穩，與他輕鬆的動作相呼應。而有那麼一瞬間，營火的聲音似乎逐漸消失無蹤。"

# game/chapter1.rpy:376
translate mandarin chapter_1_2_0b74c4f5:

    # "You find yourself watching him, momentarily thrown off by the quiet confidence he carries. Honestly, he's a little too good at this—should you be concerned about how often he practices tying knots?"
    "你發現自己正盯著他，並不自覺受他無意間散發的自信吸引。老實說，他真的做得有點太好了——\n你應該在意他究竟有多常練習打結嗎？"

# game/chapter1.rpy:382
translate mandarin chapter_1_2_a46c666a:

    # "You shake off the thought and refocus on the task at hand."
    "你將這些想法拋諸腦後，並重新專注於手邊的工作。"

# game/chapter1.rpy:384
translate mandarin chapter_1_2_ff7bf797:

    # zali_char "I'll cut the sausages. Let's make spinach, tomato baked eggs with sausages."
    zali_char "我來切香腸，我們就用菠菜、番茄、香腸來炒蛋吧。"

# game/chapter1.rpy:386
translate mandarin chapter_1_2_f324e755:

    # vanta_char "Oooo....さすが the sausage guy... I'm excited for this."
    vanta_char "哦……さすが sausage guy……我等不及要開動了。"

# game/chapter1.rpy:388
translate mandarin chapter_1_2_fe514b6b:

    # "The two of you fall into a rhythm that would put a cooking show to shame. The campfire crackles warmly, ingredients are prepped, and dinner simmers, filling the air with a mouthwatering aroma."
    "你們倆開啟了就連烹飪節目都相形失色的節奏。暖和的營火劈啪作響，你們將食材準備完成後開始煮晚餐，空氣裡充斥令人垂涎的香氣。"

# game/chapter1.rpy:391
translate mandarin chapter_1_2_6f8b4ae5:

    # vanta_char "Mmm mmm MMM! Smells like a masterpiece in the making."
    vanta_char "嗯嗯嗯！聞起來已經是一道傑作了。"

# game/chapter1.rpy:392
translate mandarin chapter_1_2_fc9bcae6:

    # "You glance up and spot a streak of flour smudged across Zali's chest."
    "你瞥見 Zali 的胸口有一抹麵粉漬。"

# game/chapter1.rpy:395
translate mandarin chapter_1_2_1a38acfb:

    # vanta_char "Oi, Zali. You planning to serve yourself as a dessert, too? You've got flour all over you."
    vanta_char "欸，Zali，你打算把自己也當成一道甜點端上來嗎？你身上都是麵粉。"

# game/chapter1.rpy:396
translate mandarin chapter_1_2_74c3c208:

    # "Zali looks down, patting his chest absently."
    "Zali 向下看並隨意拍拍胸口。"

# game/chapter1.rpy:402
translate mandarin chapter_1_2_10d6c90c:

    # zali_char "I guess you found the secret menu. I can be your dessert if you want."
    zali_char "看來你發現了今日隱藏菜單。如果你想，我也可以當你的甜點。"

# game/chapter1.rpy:404
translate mandarin chapter_1_2_ffae8a5c:

    # vanta_char "Here, let me—"
    vanta_char "來，讓我——"

# game/chapter1.rpy:405
translate mandarin chapter_1_2_8351482e:

    # "You grab a towel, stepping closer."
    "你拿了條毛巾，朝 Zali 靠近了些。"

# game/chapter1.rpy:406
translate mandarin chapter_1_2_8e809cdd:

    # "You swipe the flour with exaggerated care, brushing off the smudge while Zali\nsuppresses a chuckle, making the moment linger a second longer than necessary."
    "你過分仔細地擦去那抹髒污，Zali 則壓抑著笑意，讓這段時光多加駐留。"

# game/chapter1.rpy:407
translate mandarin chapter_1_2_b081bd1b:

    # "You and Zali continue making dinner, the aroma wafting through the air, carried by a gentle breeze, mingling with the crackling firewood."
    "你和 Zali 繼續準備晚餐，食物的香氣透過溫和的微風飄散於空氣中，與劈啪作響的火聲交融。"

# game/chapter1.rpy:413
translate mandarin chapter_1_2_654dd510:

    # vanta_char "Ahh...! The wind! There's sand in my eyes."
    vanta_char "啊……！有風！我眼睛進沙了。"

# game/chapter1.rpy:414
translate mandarin chapter_1_2_23797418:

    # "You blink rapidly and turn your head away as the breeze carries a fine grit of dust across your face."
    "你快速地眨眼，並在又一陣風將沙子吹往你的方向時轉過頭。"

# game/chapter1.rpy:416
translate mandarin chapter_1_2_02bd269a:

    # "Zali drops everything and strides over, his expression concerned as he leans in."
    "Zali 放下手邊所有事後朝你走來，並面露擔憂地湊近你。"

# game/chapter1.rpy:424
translate mandarin chapter_1_2_798155fe:

    # zali_char "Let me have a look..."
    zali_char "讓我看看……"

# game/chapter1.rpy:425
translate mandarin chapter_1_2_dd0e7003:

    # "The distance between the two of you shrinks dramatically. Your faces are unnecessarily close, the warmth of his breath brushing your skin."
    "你們之間的距離急劇縮短。你們的臉過分接近，他呼吸的熱度灑上你的皮膚。"

# game/chapter1.rpy:426
translate mandarin chapter_1_2_8144832b:

    # "His hand hovers near your face, his fingers hesitating like they're caught between instinct and restraint."
    "他的手游移至你臉附近，他的手指似乎在本能和克制間猶疑不定。"

# game/chapter1.rpy:427
translate mandarin chapter_1_2_af53c8a3:

    # "The moment stretches, fragile and electric, like the world itself is holding its breath, waiting to see who will move first."
    "這段脆弱而帶電的時光被延展開來，好似世界自己屏住了呼吸，等著看誰先有下一步動作。"

# game/chapter1.rpy:436
translate mandarin chapter_1_2_30461e62:

    # wilson_char "I'm back. Wow, whatever you guys are cooking smells so—WAIT. What are you doing?\nOh my god, I was helping a farmer find his cows and you two are here kissing?"
    wilson_char "我回來了。哇，你們在煮的東西聞起來好——給我等一下。你們在幹嘛？天啊，我在幫農夫找牛，而你們在這裡玩親親？"

# game/chapter1.rpy:437
translate mandarin chapter_1_2_86cc6989:

    # "Wilson's voice shatters the moment like a bucket of cold water. Perfect—or horrible—timing, really."
    "Wilson 的聲音潑了他們一身冷水。這簡直是再完美——或糟糕——不過的時機了。"

# game/chapter1.rpy:440
translate mandarin chapter_1_2_4f36965f:

    # vanta_char "W—What?"
    vanta_char "什——什麼？"

# game/chapter1.rpy:441
translate mandarin chapter_1_2_6a09b508:

    # vanta_char "It's sand! I just... I got sand in my eyes, okay?"
    vanta_char "是沙子！只是……我眼睛進沙子了，懂嗎？"

# game/chapter1.rpy:443
translate mandarin chapter_1_2_21a6d4fa:

    # wilson_char "Right, whatever you say, man. Kissing without me? Unforgivable..."
    wilson_char "好啦，隨便你。瞞著我接吻？不可原諒……"

# game/chapter1.rpy:444
translate mandarin chapter_1_2_271efdbb:

    # "Wilson crosses his arms, throwing a mock glare at you."
    "Wilson 雙手環胸，故作生氣地瞪著你。"

# game/chapter1.rpy:445
translate mandarin chapter_1_2_58649743:

    # "The sun dips lower as the three of you reunite at the campsite, laughter echoing through the golden light filtering between the trees. The inviting aroma of food fills the air, drawing you all toward the promise of dinner."
    "夕陽於你們在營地相聚時沉得更低，笑聲隨著灑落樹木的金色亮光迴盪。誘人的食物香氣充斥在空氣之中，帶領你們開始享用等待已久的晚餐。"

# game/chapter1.rpy:458
translate mandarin chapter_1_3_3774232c:

    # "After dinner, the three of you gather around the campfire. The flickering flames cast a warm glow, warding off the evening chill."
    "晚餐之後，你們三人聚集在營火周圍。閃爍的火焰散發出暖和的光，驅散傍晚的寒氣。"

# game/chapter1.rpy:462
translate mandarin chapter_1_3_7f3d36a2:

    # "You pull out a bag of marshmallows, smiling as you pass them around with roasting sticks. Moments like this call for a classic treat—roasted marshmallows under the open sky."
    "你拿出一包棉花糖，並微笑著將串著棉花糖的烤棒傳下去。這樣的時刻就該配上經典的點心——廣闊天空下的烤棉花糖。"

# game/chapter1.rpy:465
translate mandarin chapter_1_3_060426dc:

    # wilson_char "The crispy shell and gooey center—nothing beats a roasted marshmallow by a campfire."
    wilson_char "這個酥脆的外殼跟黏糊糊的內餡——在營火旁沒有什麼比烤棉花糖更棒的東西了。"

# game/chapter1.rpy:466
translate mandarin chapter_1_3_1e17dd04:

    # wilson_char "Man, that hits the spot."
    wilson_char "這好爽喔喔喔！"

# game/chapter1.rpy:469
translate mandarin chapter_1_3_56b38a11:

    # vanta_char "That's what she said."
    vanta_char "那是她說的。"

# game/chapter1.rpy:474
translate mandarin chapter_1_3_80a28568:

    # zali_char "Goodness! This is giga fire! Yes, I can have five more."
    zali_char "天啊！這個爆炸好吃！我可以再多吃好幾個。"

# game/chapter1.rpy:475
translate mandarin chapter_1_3_35d06080:

    # vanta_char "Ahh! It's been a while since we've relaxed like this, just enjoying the moment."
    vanta_char "啊！我們已經有好一陣子沒有像這樣放鬆、享受當下了。"

# game/chapter1.rpy:476
translate mandarin chapter_1_3_33004051:

    # zali_char "Gosh! Yeah, you're right!"
    zali_char "天哪！對，你說得對！"

# game/chapter1.rpy:480
translate mandarin chapter_1_3_2762efdf:

    # wilson_char "It's nice to disconnect from screens and just enjoy a quiet moment for a change."
    wilson_char "像這樣脫離螢幕，然後享受寧靜的時刻也是不錯的充電方式。"

# game/chapter1.rpy:481
translate mandarin chapter_1_3_065002bc:

    # zali_char "Yeah, it's really peaceful here. The fire, the sky, and the stars...it's a kind of calm you don't find anywhere else."
    zali_char "確實，這裡很寧靜。這裡的營火、天空，還有星星……都是世上絕無僅有的平和。"

# game/chapter1.rpy:482
translate mandarin chapter_1_3_09b9fa27:

    # "You take a deep breath, the faint sweetness of roasted marshmallows filling your senses."
    "你深呼吸，讓微弱的烤棉花糖甜味充斥你的感官。"

# game/chapter1.rpy:487
translate mandarin chapter_1_3_a04e0740:

    # "It's been a while since you've had a moment like this—relaxed, unhurried, and shared with those who matter most."
    "你已經好久沒有和最重視的人們共度這樣輕鬆寫意的時光了。"

# game/chapter1.rpy:488
translate mandarin chapter_1_3_639b7747:

    # "You have your friends by your side, who (arguably) know you better than most other people. Actually, not just friends—your found family, within arm's reach."
    "你身邊有著比任何人都瞭解你的朋友（應該吧）。實際上，你們不只是朋友，更是親如手足的摯友。"

# game/chapter1.rpy:489
translate mandarin chapter_1_3_a102d844:

    # "This kind of moment makes you smile and appreciate the choices that brought you here. It's a reminder that life's best joys are often found in the simplest things."
    "這樣的時刻使你們揚起微笑，並感謝起了一路以來的選擇。這提醒了你們，人生最大的樂趣經常藏在最簡單的事物之中。"

# game/chapter1.rpy:490
translate mandarin chapter_1_3_2b2f86fd:

    # vanta_char "We hardly ever get a break, now that I think about it. Even the last time we had a vacation, we were still working our asses off."
    vanta_char "現在想想，我們幾乎沒休息過，就連上次休假也是忙得要死。"

# game/chapter1.rpy:491
translate mandarin chapter_1_3_332684c3:

    # wilson_char "I mean, there's always danger around every corner. Even where we sit, anything can happen. Evil never takes a break, so we shouldn't either."
    wilson_char "畢竟危機潛藏在各個角落啊。就連我們現在坐的地方都可能出事。邪惡從不休息，我們也一樣。"

# game/chapter1.rpy:492
translate mandarin chapter_1_3_4defb7ff:

    # zali_char "That may be true...which is why we should enjoy moments like this while we can!"
    zali_char "或許是這樣沒錯……這正是為什麼我們該及時行樂！"

# game/chapter1.rpy:493
translate mandarin chapter_1_3_42916347:

    # wilson_char "You're right, Zali."
    wilson_char "Zali，你說得對。"

# game/chapter1.rpy:494
translate mandarin chapter_1_3_3b59bdc4:

    # "You three enjoy your roasted marshmallows while engaging in a much-needed mental check in with each other."
    "在享用烤棉花糖的同時，你們三人也享受了久違的心靈時光。"

# game/chapter1.rpy:498
translate mandarin chapter_1_3_4285dba7:

    # wilson_char "I love you guys, genuinely."
    wilson_char "我愛你們，真心不騙。"

# game/chapter1.rpy:500
translate mandarin chapter_1_3_f8630d0a:

    # zali_char "Awwnn, I love you too!"
    zali_char "嗷嗷噢，我也愛你！"

# game/chapter1.rpy:502
translate mandarin chapter_1_3_6672cf95:

    # vanta_char "{size=40}Hahah! Gay~~~{/size}"
    vanta_char "{size=40}哈哈！Gay～～～{/size}"

# game/chapter1.rpy:504
translate mandarin chapter_1_3_2cb4a73f:

    # wilson_char "{size=45}WHAT?!{/size}"
    wilson_char "{size=45}什麼？！{/size}"

# game/chapter1.rpy:506
translate mandarin chapter_1_3_e248c8f5:

    # wilson_char "You know what, never mind! Zali, I love YOU!"
    wilson_char "管他的，算了！Zali，我愛你！"

# game/chapter1.rpy:507
translate mandarin chapter_1_3_41bc4bda:

    # zali_char "D'aww, stahp it~!"
    zali_char "哎呀，鼻要這樣啦～！"

# game/chapter1.rpy:509
translate mandarin chapter_1_3_3edfc7ae:

    # vanta_char "Damn, I'm sorry! I love you too, man."
    vanta_char "好啦，我很抱歉！我也愛你！"

# game/chapter1.rpy:511
translate mandarin chapter_1_3_9c5d95c5:

    # wilson_char "Nope! it's too late!"
    wilson_char "我不聽！來不及了！"

# game/chapter1.rpy:516
translate mandarin chapter_1_3_299547a7:

    # "After some light banter, you clean up the leftovers and set them aside. With the fire dying down, you head back into the cabin to prepare for the night."
    "在無傷大雅的鬥嘴後，你們將廚餘清乾淨後放到一邊。火焰逐漸熄滅，而你們也回到了屋內準備度過這個夜晚。"

# game/chapter1.rpy:520
translate mandarin chapter_1_3_898f4cfa:

    # "Night falls. The shared bed creaks slightly as the three of you sleep soundly. Suddenly, a loud noise breaks the silence—rustling leaves, guttural growls, and the heavy crash of something being overturned."
    "夜幕低垂。床在你們三人酣睡時發出輕微的吱嘎聲。突然有一聲巨響打破了寂靜——樹葉的沙沙聲、粗重的咆哮聲，還有東西被翻倒的巨大撞擊聲。"

# game/chapter1.rpy:523
translate mandarin chapter_1_3_42413e2b:

    # wilson_char "Hmm...?"
    wilson_char "嗯……？"

# game/chapter1.rpy:526
translate mandarin chapter_1_3_12e50729:

    # vanta_char "Hmm... Wilson stop moving... You're hogging the blanket."
    vanta_char "嗯……Wilson 不要再亂動了……你把被子都佔走了。"

# game/chapter1.rpy:529
translate mandarin chapter_1_3_7656cb67:

    # zali_char "Huh? Wait, guys, guys. I think something is out there..."
    zali_char "什麼？等等，大家，外面好像有東西……"

# game/chapter1.rpy:531
translate mandarin chapter_1_3_3bc748f5:

    # "Zali sits up, his sharp instincts catching the unusual sounds outside. He glances towards the window. Who would be hanging outside of their camp at this godforsaken hour?"
    "Zali 敏銳的直覺捕捉到了外頭怪異的聲響，於是他趕緊坐起身。他瞥向窗戶。在這萬物皆眠的時間，會有誰在他們的營地外遊蕩呢？"

# game/chapter1.rpy:532
translate mandarin chapter_1_3_67b5e7d2:

    # "Hearing Zali's voice, you slowly wake up. You rub your eyes, shuffle to the windowsill,\nand pull back the curtain slightly."
    "聽見 Zali 的聲音後，你緩慢地起床。你揉揉眼睛，拖著步伐走向窗臺，並稍微拉開了窗簾。"

# game/chapter1.rpy:534
translate mandarin chapter_1_3_350666ce:

    # "Your breath catches in your throat as your eyes adjust to the darkness. There, near the dying embers of the campfire, looms a massive shadow. The Bigfoot—or what you are convinced is Bigfoot—is rummaging through the leftover food."
    "在雙眼適應黑暗後，你的呼吸便被卡在了喉頭。熄滅的木炭附近，有個巨大的身影逐漸逼近。大腳怪——或你認為是大腳怪的生物——正翻找著廚餘。"

# game/chapter1.rpy:535
translate mandarin chapter_1_3_de0d92c1:

    # "It stands tall—too tall. Seven feet, maybe more. And it's covered in thick, matted hair."
    "牠很高——太高了，大概有七呎高，甚至更高。全身還被又厚又亂的毛髮覆蓋。"

# game/chapter1.rpy:537
translate mandarin chapter_1_3_c336adc0:

    # zali_char "Is... Is that Bigfoot?"
    zali_char "那……那是大腳怪嗎？"

# game/chapter1.rpy:538
translate mandarin chapter_1_3_5741d10a:

    # vanta_char "Yes, well. Looks like Bigfoot traveled here just to crash our glamping trip."
    vanta_char "好吧，看來大腳怪是為了毀掉我們的露營之旅才特地遠道而來。"

# game/chapter1.rpy:539
translate mandarin chapter_1_3_ddc423ad:

    # "Despite the sarcasm in your tone, you can't help but feel uneasy. Looking at the size and shape of whatever this thing is, it's like nothing you've ever seen before."
    "即使語帶嘲諷，你還是忍不住感到坐立難安。畢竟那奇怪生物的尺寸和樣貌都是你此生\n未曾見識過的。"

# game/chapter1.rpy:540
translate mandarin chapter_1_3_5aae8247:

    # "Wilson is now awake, rubbing the sleep from his eyes. He looks at you both, still groggy."
    "Wilson 終於醒了。他揉去眼裡的睡意，昏昏沉沉地看向你們。"

# game/chapter1.rpy:542
translate mandarin chapter_1_3_1b67ff8d:

    # wilson_char "Guys... What's so important that we're breaking up the homie sleep?"
    wilson_char "各位……到底是什麼重要的東西打斷了我們的 homie sleep?"

# game/chapter1.rpy:543
translate mandarin chapter_1_3_8aa6e9ce:

    # zali_char "Wilson... It's Bigfoot. I think."
    zali_char "Wilson……我覺得是大腳怪。"

# game/chapter1.rpy:544
translate mandarin chapter_1_3_276732d1:

    # "You pull away from the window, turning to Zali and Wilson."
    "你離開窗戶後轉向 Zali 和 Wilson。"

# game/chapter1.rpy:547
translate mandarin chapter_1_3_9a7a164a:

    # vanta_char "Alright. Let's grab something. Duty calls."
    vanta_char "好吧，拿個武器，任務來了！"

# game/chapter1.rpy:555
#translate mandarin chapter_1_3_509f52fe:

    # "The three of you jump out of bed, throw on some clothes (you were naked *wink*),\nand grab whatever tools are within reach."
    # "你們三人跳下床，穿上衣服（你們原本一絲不掛😉），並隨手拿了身邊有的東西。"

# game/chapter1.rpy:556
translate mandarin chapter_1_3_5788c88a:

    # "Zali picks up a frying pan, Wilson takes a flashlight, and you manage to find...\na sturdy stick."
    "Zali 拿起了煎鍋，Wilson則握緊了手電筒，而你找到了一支……粗壯的棍子。"

# game/chapter1.rpy:558
translate mandarin chapter_1_3_bbfe9f5c:

    # vanta_char "LMAO. I guess this is what we've got."
    vanta_char "笑死，這些應該就是我們的武器了。"

# game/chapter1.rpy:559
translate mandarin chapter_1_3_3a3c11ff:

    # "As the tank of the group, you take the lead, stepping in front of Zali and Wilson. You put your hand on the doorknob, take a deep breath, and open the door."
    "作為隊內的坦克，你自然成了領頭羊，並主動站到了 Zali 和 Wilson 前方。你將手放上門把，深呼吸後打開了門。"

# game/chapter1.rpy:572
translate mandarin chapter_1_example_qte_debug_b11d77e1:

    # "Your eyes meet Bigfoot's."
    "你與大腳怪四目相交。"

# game/chapter1.rpy:574
translate mandarin chapter_1_example_qte_debug_cdf3977e:

    # "The creature lets out a loud growl, its massive form tensing before it charges straight at the three of you."
    "那生物發出了震耳欲聾的嗥叫，牠龐大的身軀繃緊，隨後直直衝向你們。"

# game/chapter1.rpy:575
translate mandarin chapter_1_example_qte_debug_3fbebf56:

    # "Waking up in the middle of the night and fight a giant monster? Say less!"
    "在半夜起床對付巨大怪物？廢話不多說，上了！"

# game/chapter1.rpy:576
translate mandarin chapter_1_example_qte_debug_048a39f6:

    # "The three of you spring into action immediately, instincts kicking in as you prepare to face\nthe oncoming attack."
    "你們三人立即進入了戰鬥狀態，在準備應對攻擊時，又是時候考驗反應力了。"

# game/chapter1.rpy:599
translate mandarin chapter_1_example_clear_b3fb0fbc:

    # "You all leap just in time, your excellent reflexes saving you from the charging creature."
    "多虧了你們出色的反應力，你們都即時縱身一躍，躲過了衝刺而來的怪物。"

# game/chapter1.rpy:609
translate mandarin chapter_1_example_timeout_a33c4710:

    # "You don't jump quickly enough, and Bigfoot's massive punch lands squarely on your chest."
    "你們來不及跳開，而大腳怪巨大的拳頭正正打中了你的胸膛。"

# game/chapter1.rpy:610
translate mandarin chapter_1_example_timeout_f1a7527c:

    # vanta_char "URGHHH!! That...hurt..."
    vanta_char "呃啊啊！好……痛……"

# game/chapter1.rpy:611
translate mandarin chapter_1_example_timeout_605e1d82:

    # "But as the Ace and Tyrant of Krisis, you shake it off—it'll take more than that to faze you."
    "但身為 Krisis 的王牌和暴君，這對你而言不算什麼，想把你打暈還差得遠呢。"

# game/chapter1.rpy:621
translate mandarin chapter_1_wilson_qte_9fe6d43b:

    # "Bigfoot turns its gaze towards Wilson, its eyes full of rage. It charges towards Wilson."
    "大腳怪將牠堆滿怒氣的雙眼轉向 Wilson，隨後朝他衝過去。"

# game/chapter1.rpy:622
translate mandarin chapter_1_wilson_qte_001f883f:

    # "Facing Bigfoot barreling towards him, the former hitman decides to—"
    "面對高速朝他衝來的大腳怪，前殺手決定——"

# game/chapter1.rpy:649
translate mandarin chapter_1_wilson_timeout_b9d07d61:

    # "Wilson freezes, unable to react in time. Bigfoot's massive arm swings in a brutal arc, sending him sprawling to the ground."
    "Wilson 呆在原地，來不及反應。大腳怪狂暴地揮舞龐大的手臂，打得他癱倒在地。"

# game/chapter1.rpy:650
translate mandarin chapter_1_wilson_timeout_b493adf9:

    # zali_char "WILSON—!!!!"
    zali_char "WILSON——！！！！"

# game/chapter1.rpy:659
translate mandarin chapter_1_wilson_fail_33f38322:

    # "Wilson throws the flashlight and it hits Bigfoot square between the eyes. The\ncreature stumbles, but Wilson's hesitation gives it an opening, and a massive arm swings toward him."
    "Wilson 將手電筒扔向大腳怪，打在牠的雙眼之間，導致牠向後跌了一下。但 Wilson 的猶豫給了牠機會，怪物朝著他揮出龐大的手臂。"

# game/chapter1.rpy:660
translate mandarin chapter_1_wilson_fail_b493adf9:

    # zali_char "WILSON—!!!!"
    zali_char "WILSON——！！！！"

# game/chapter1.rpy:670
translate mandarin chapter_1_wilson_clear_9784e087:

    # "Wilson steps aside with the precision of a man who's tango'd with death more times than he cares to count."
    "在鬼門關前走過好幾遭的 Wilson 精準地向一旁躲開。"

# game/chapter1.rpy:671
translate mandarin chapter_1_wilson_clear_b01e1cf8:

    # "Bigfoot's charge narrowly misses him, leaving claw marks in the ground instead."
    "大腳怪的攻擊差點就命中了他，最終只在地面上留下爪印。"

# game/chapter1.rpy:672
translate mandarin chapter_1_wilson_clear_57d5ef70:

    # wilson_char "F—That was close!"
    wilson_char "乾——差一點！"

# game/chapter1.rpy:673
translate mandarin chapter_1_wilson_clear_be1f996f:

    # "Wilson nimbly dodges the attack—exactly what you'd expect from a hitman. Meanwhile, Zali raises the frying pan high above his head, banging it loudly to get Bigfoot's attention."
    "Wilson 靈巧地躲過攻擊——完全不愧對他前殺手的身分。與此同時，Zali 將煎鍋高舉過頭，並大聲地敲擊它來吸引大腳怪的注意。"

# game/chapter1.rpy:682
translate mandarin chapter_1_zali_qte_0a392e1a:

    # "Bigfoot locks its rage-filled eyes on Zali. He quickly wraps a bandage around the pan's handle, creating an improvised meteor hammer."
    "大腳怪充滿怒氣的視線鎖定在 Zali 身上。他則突發奇想，俐落地將繃帶纏上鍋子的把手作為\n流星錘。 "

# game/chapter1.rpy:683
#translate mandarin chapter_1_zali_qte_a19fe0c7:

    # "He starts swinging the pan in a steady rhythm, its arc cutting through the air. Timing is everything now. Zali looks at its crotch—"
    # "他開始以穩定的節奏揮動鍋子，揮出的弧線劃破空氣。時機正是此刻的關鍵。Zali 看向牠的胯間——"

# game/chapter1.rpy:699
#translate mandarin chapter_1_zali_qte_1_2_2e25a67d:

    # zali_char "Take this! Where are you looking at?"
    # zali_char "看招！你在看哪裡啊？"

# game/chapter1.rpy:711
#translate mandarin chapter_1_zali_qte_1_3_3620ea1e:

    # zali_char "HA! Oh that's gonna hurt! Now last one..."
    # zali_char "哈！剛剛那下很痛吧！現在是最後一擊……"

# game/chapter1.rpy:726
translate mandarin chapter_1_zali_fail_040fa1b6:

    # "To everyone's surprise, the bandage slips and the frying pan flies from Zali's hand.\nBigfoot lunges, striking before he can react."
    "出乎意料的是，繃帶鬆了，鍋子從 Zali 手中飛出。大腳怪向前猛撲，在他反應前使出一記重擊。"

# game/chapter1.rpy:727
translate mandarin chapter_1_zali_fail_fc538419:

    # vanta_char "ZALI—!!!!"
    vanta_char "ZALI——！！！！"

# game/chapter1.rpy:736
translate mandarin chapter_1_zali_timeout_d76434b7:

    # "Zali took too long to move and got attacked."
    "Zali 的反應來不及跟上大腳怪的速度，大腳怪重擊 Zali。"

# game/chapter1.rpy:737
translate mandarin chapter_1_zali_timeout_fc538419:

    # vanta_char "ZALI—!!!!"
    vanta_char "ZALI——！！！！"

# game/chapter1.rpy:747
translate mandarin chapter_1_zali_clear_d238aefa:

    # zali_char "Phew!! Easy peasy!"
    zali_char "呼！小菜一碟！"

# game/chapter1.rpy:751
translate mandarin chapter_1_zali_clear_bb8ef080:

    # "Zali's improvised meteor hammer stuns Bigfoot, leaving it concussed and stumbling directly towards you."
    "Zali 用自製的流星錘敲暈了大腳怪，讓牠腦震盪並直直跌向你。"

# game/chapter1.rpy:752
translate mandarin chapter_1_zali_clear_bfc60998:

    # "All you've got is a stick, but you're confident, and you've handled worse."
    "你手上只有一支棍子，但你自信滿滿，更何況你還處理過更棘手的任務。"

# game/chapter1.rpy:754
translate mandarin chapter_1_zali_clear_01aaaabe:

    # "You dart forward, facing the creature head-on as its massive fist swings towards you."
    "你向前飛奔，並正好在牠巨大的拳頭揮向你時與牠大眼對小眼。"

# game/chapter1.rpy:765
translate mandarin chapter_1_vanta_qte_624be87e:

    # "You see its fist swinging from the right, you decide to—"
    "你看見牠的拳頭向右揮，於是你——"

# game/chapter1.rpy:795
translate mandarin chapter_1_vanta_qte_1_2_f20387e2:

    # vanta_char "Light work, light work."
    vanta_char "輕而易舉。"

# game/chapter1.rpy:797
translate mandarin chapter_1_vanta_qte_1_2_f94a1b10:

    # "You bounce lightly on your feet to stay nimble."
    "你輕盈地落地以保持靈活。"

# game/chapter1.rpy:803
translate mandarin chapter_1_vanta_qte_1_2_a325f065:

    # "You study Bigfoot's movements carefully, anticipating the next attack. This time, its uses the other arm!"
    "你謹慎地觀察大腳怪的動作，同時等待著下一次攻擊。這次牠用了另一隻手！"

# game/chapter1.rpy:804
translate mandarin chapter_1_vanta_qte_1_2_28864d1a:

    # "You ready yourself, and—"
    "你做好準備，然後——"

# game/chapter1.rpy:834
translate mandarin chapter_1_vanta_qte_1_3_0e3106ef:

    # vanta_char "I can do this all day... Come at me."
    vanta_char "我和你打一整天都沒問題……來吧！"

# game/chapter1.rpy:841
translate mandarin chapter_1_vanta_qte_1_3_62eb61fb:

    # "Bigfoot's erratic swings become wilder, it's going straight to your stomach! You—"
    "大腳怪的手臂擺動得越來越瘋狂，再來就要打中你的腹部了！而你——"

# game/chapter1.rpy:868
translate mandarin chapter_1_vanta_fail_01fdaca2:

    # "You jump straight into its punch. It's too late to jump away again—"
    "你直直跳進了牠的重拳，想再跳開已經為時已晚了——"

# game/chapter1.rpy:869
translate mandarin chapter_1_vanta_fail_af05a9d7:

    # zali_char "VANTA—!!!!"
    zali_char "VANTA——！！！！"

# game/chapter1.rpy:878
translate mandarin chapter_1_vanta_timeout_1a2c1082:

    # "Your feet are stuck to the ground, Bigfoot's strike is about to land on your face—"
    "你的腳卡在地面上，同時大腳怪的重擊就要擊中你的臉——"

# game/chapter1.rpy:879
translate mandarin chapter_1_vanta_timeout_af05a9d7:

    # zali_char "VANTA—!!!!"
    zali_char "VANTA——！！！！"

# game/chapter1.rpy:893
translate mandarin chapter_1_vanta_clear_8e5792be:

    # vanta_char "Alright, let's wrap this up so I can head back to bed with my homies, shall we?"
    vanta_char "好，盡快結束這一切，然後回去和 homie 睡覺了，好嗎?"

# game/chapter1.rpy:901
translate mandarin chapter_1_vanta_clear_6ce311af:

    # "Spotting an opening, you move in with accuracy. You run in with a sharp knee strike, landing squarely on Bigfoot's chest. Without hesitation, you pivot smoothly and backhand the stick into its neck, ending the fight with a decisive blow."
    "看見有機可乘後，你精準跑上前，用膝蓋給大腳怪的胸口來上一記重擊。 你毫無猶豫地流暢轉身，反手將棍棒插進牠的脖子，最後以關鍵性的一拳結束了戰鬥。"

# game/chapter1.rpy:907
translate mandarin chapter_1_vanta_clear_01425ba5:

    # zali_char "Eyyy! Good job Vanta!!"
    zali_char "好耶！Vanta 做得好！！"

# game/chapter1.rpy:909
translate mandarin chapter_1_vanta_clear_5f7a3c83:

    # vanta_char "All in a night's work..."
    vanta_char "這只是我平時夜生活的一部份罷了……"

# game/chapter1.rpy:911
translate mandarin chapter_1_vanta_clear_7836c2de:

    # wilson_char "Right, should we just tie it up for now? I'll notify A.S.H. so they can take care of it first thing in the morning."
    wilson_char "那現在是不是把牠綁起來就好？我會再通知 A.S.H.，這樣他們可以早上再來處理。"

# game/chapter1.rpy:913
translate mandarin chapter_1_vanta_clear_642db186:

    # zali_char "Yeah! I can secure it to that tree over there. It's not going anywhere."
    zali_char "好！我把牠綁在那棵樹邊，牠無處可逃了。"

# game/chapter1.rpy:915
translate mandarin chapter_1_vanta_clear_e2c4506b:

    # vanta_char "Man... Let's get back to sleep..."
    vanta_char "天啊……我們趕快回去睡覺吧……"

# game/chapter1.rpy:922
translate mandarin chapter_1_vanta_clear_81409d2b:

    # "As the three of you get back inside the cabin, the weight of the night's events lingers.\nThis was supposed to be a relaxing holiday, but it seems that heroes really can't catch\na break."
    "在回到屋子後，這晚發生的各種事件仍縈繞在你們心中。這本應是讓你們得以好好放鬆的假日，但看來英雄真的無法好好休息。"

# game/chapter1.rpy:926
translate mandarin chapter_1_vanta_clear_59619716:

    # "In the dim glow of the A.S.H. office, a new mission notification pings onto the mission board. A familiar name flashes in bold letters:"
    "同時，在 A.S.H. 辦公室昏暗的燈光中，一則新的任務通知在螢幕上跳出。熟悉的名字以\n粗體字浮現："

# game/chapter1.rpy:927
translate mandarin chapter_1_vanta_clear_d8b2e772:

    # "{size=40}Shu Yamino.{/size}"
    "{size=40}Shu Yamino。{/size}"

translate mandarin strings:

    # game/chapter1.rpy:125
    old "Take a Picture With Your Phone"
    new "拿出手機拍照"

    # game/chapter1.rpy:234
    old "That leaves you to make a choice: help Zali pick up groceries and head back to camp, or join Wilson in tracking down the missing cows for the distraught farmer.{fast}"
    new "於是你必須做出選擇：幫 Zali 挑選食材後回到營區，或者和 Wilson 一起幫慌亂的農夫尋找\n失蹤的牛隻。{fast}"

    # game/chapter1.rpy:234
    old "Join Wilson to Search for the Missing Cows"
    new "和 Wilson 一起去找失蹤的牛。"

    # game/chapter1.rpy:234
    old "Go Grocery Shopping With Zali"
    new "和 Zali 一起去雜貨店採購。"

translate mandarin strings:

    # game/chapter1.rpy:69
    old "Brake"
    new "煞車"

translate mandarin strings:

    # game/chapter1.rpy:595
    old "Jump Apart"
    new "跳開"

    # game/chapter1.rpy:637
    old "Dodge"
    new "躲開"

    # game/chapter1.rpy:638
    old "Throw Flashlight"
    new "丟出手電筒"

    # game/chapter1.rpy:773
    old "Jump Left"
    new "往左跳"

    # game/chapter1.rpy:774
    old "Jump Right"
    new "往右跳"

    # game/chapter1.rpy:833
    old "Jump Up"
    new "跳起來"

    # game/chapter1.rpy:834
    old "Duck Down"
    new "彎下身"

# game/chapter1.rpy:554
translate mandarin chapter_1_3_99bf1ba8:

    # "The three of you jump out of bed, throw on some clothes,\nand grab whatever tools are within reach."
    "你們三人跳下床，穿上衣服，並隨手拿了身邊有的東西。"

# game/chapter1.rpy:680
translate mandarin chapter_1_zali_qte_9cfe039c:

    # "He starts swinging the pan in a steady rhythm, its arc cutting through the air. Timing is everything now. Zali looks at its {size=60}crotch{/size}—"
    "他開始以穩定的節奏揮動鍋子，揮出的弧線劃破空氣。時機正是此刻的關鍵。\nZali 看向牠的{size=60}胯間{/size}——"

# game/chapter1.rpy:696
translate mandarin chapter_1_zali_qte_1_2_e7525233:

    # zali_char "Hey! Where are you looking at? {size=60}Eyes{/size}. On. Me."
    zali_char "看招！你在看哪裡啊？{size=60}眼睛{/size}、看著、我。"

# game/chapter1.rpy:708
translate mandarin chapter_1_zali_qte_1_3_c89f1d41:

    # zali_char "HA! Oh that's gonna hurt! Now let's deal with those dangerous little {size=60}claws{/size} of yours..."
    zali_char "哈！剛剛那下很痛吧！現在讓我來處理你那些危險的{size=60}小爪子{/size}……"# TODO: Translation updated at 2025-06-14 23:19

# game/chapter1.rpy:173
translate mandarin chapter_1_2_7749ddb6:

    # "A group of forest rangers stand outside the grocery store, their conversation growing louder as you approach. A farmer, clearly upset, joins them, gesturing at his broken fence and mentioning strange footprints he found near his farm."
    "商店外站著一群森林護管員，而他們對話的音量在你們靠近時逐漸上升。一位面露沮喪的農夫加入他們，他指向毀損的圍籬，且提到了他在農場附近發現的怪異腳印。"

# game/chapter1.rpy:302
translate mandarin chapter_1_2_82561a91:

    # wilson_char "Moo louder! You're a concerned father! Never back down, never what?"
    wilson_char "Moo 大聲一點！你是擔心孩子的老爸，不要退縮！"

# game/chapter1.rpy:325
translate mandarin chapter_1_2_00980a9d:

    # farmer_char "Well, I'll be damned, I didn't think you'd be so good at this cowboy business. Ever thought about ranching?"
    farmer_char "我沒料到你們對牧牛那麼在行。有考慮過經營牧場嗎？"

# game/chapter1.rpy:491
translate mandarin chapter_1_3_90e1623a:

    # "You three enjoy your roasted marshmallows while engaging in a much-needed mental check-in with each other."
    "在享用烤棉花糖的同時，你們三人也享受了久違的心靈時光。"

