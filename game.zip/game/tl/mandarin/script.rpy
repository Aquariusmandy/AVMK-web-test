﻿
# TODO: Translation updated at 2025-04-23 14:30

translate mandarin strings:

    # game/script.rpy:304
    old "Vantacrow"
    new "Vantacrow"

    # game/script.rpy:305
    old "Wilson"
    new "Wilson"

    # game/script.rpy:306
    old "Vezalius"
    new "Vezalius"

    # game/script.rpy:307
    old "Wilson & Vantacrow"
    new "Wilson & Vantacrow"

    # game/script.rpy:308
    old "Vantacrow & Vezalius"
    new "Vantacrow & Vezalius"

    # game/script.rpy:309
    old "Vezalius & Wilson"
    new "Vezalius & Wilson"

    # game/script.rpy:310
    old "Vantacrow & Crew"
    new ""

    # game/script.rpy:311
    old "Farmer"
    new "農夫小哥"

    # game/script.rpy:312
    old "Forest Ranger"
    new "森林護管員"

    # game/script.rpy:313
    old "Rich Lady"
    new "貴婦"

    # game/script.rpy:314
    old "Mana"
    new "Mana"

    # game/script.rpy:315
    old "Rai"
    new "Rai"

    # game/script.rpy:647
    old "{font=final}{size=120}EHHHHHH!!?{/size}{/font}"
    new "{font=final}{size=120}誒誒誒誒誒誒!!?{/size}{/font}"
