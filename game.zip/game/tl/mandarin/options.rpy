﻿# TODO: Translation updated at 2024-06-08 01:58

translate mandarin strings:

    # game/options.rpy:14
    old "Full_alpha_2"
    new "Full_alpha_2"
# TODO: Translation updated at 2024-06-17 17:45

translate mandarin strings:

    # game/options.rpy:14
    old "BetaTest"
    new "BetaTest"

# TODO: Translation updated at 2025-04-23 14:30

translate mandarin strings:

    # game/options.rpy:14
    old "Krisis En Voyage"
    new "Krisis En Voyage"

