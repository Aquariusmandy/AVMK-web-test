﻿# TODO: Translation updated at 2025-05-21 11:56

# game/chapter2.rpy:10
translate mandarin chapter_2_ec3b34e6:

    # "The short-lived peace of your retreat is officially over. It was nice while it lasted."
    "休假間短暫的寧靜終究抵達了盡頭，但過程還是很不錯。"

# game/chapter2.rpy:14
translate mandarin chapter_2_e3c473d2:

    # "Back at A.S.H., the three of you stand around the mission board, reading the latest brief—this time from none other than Shu Yamino."
    "回到 A.S.H.，你們三人圍繞著任務板，閱讀著最新的簡報——這次的委託人，正是 Shu Yamino。"

# game/chapter2.rpy:15
translate mandarin chapter_2_f8317f13:

    # "No rest for the world's greatest heroes."
    "全世界最優秀的英雄果然不得休息。"

# game/chapter2.rpy:16
translate mandarin chapter_2_2e812d27:

    # vanta_char "\"Dear Krisis, I heard you just got back from your well-deserved trip to Canada. I hope you enjoyed the break, because now, I have a mission for you.\""
    vanta_char "「親愛的 Krisis，我聽說你們才剛從應得的加拿大之旅回來。希望你們有好好享受這次休假，因為現在我有個要給你們的任務。」"

# game/chapter2.rpy:17
translate mandarin chapter_2_09278cdf:

    # wilson_char "\"A good friend of mine, Rich Lady, is hosting a high-profile event at her manor in Paris.\nShe is also a big fan of my one-of-a-kind art piece, 'Real.' Naturally, she wants to borrow it for display next week.\""
    wilson_char "「我的貴婦好友即將在她巴黎的莊園舉辦一場高檔的活動。同時，她也是我萬中選一的畫作『Real』的忠實粉絲。因此，她希望向我借這幅畫並在下週的活動中展出。」"

# game/chapter2.rpy:18
translate mandarin chapter_2_a53646d0:

    # zali_char "\"As you know, my work is extremely valuable—priceless, even. I trust you three to guard it with your lives as you escort it to France and ensure its safety over the next few weeks.\""
    zali_char "「正如你們所知，我的作品極其珍貴——甚至可說是無價之寶。我相信你們三人能夠用生命把它護送到法國，並確保它接下來幾週的安危。」"

# game/chapter2.rpy:19
translate mandarin chapter_2_0cd8800e:

    # vanta_char "\"Thanks in advance for your hard work. Wishing you a smooth mission. Shu Yamino.\""
    vanta_char "「感謝你們的努力，預祝你們任務順利。Shu Yamino。」"

# game/chapter2.rpy:20
translate mandarin chapter_2_89919034:

    # "You lean back in your chair. A high-profile art escort mission? That's new."
    "你向後靠在椅背上。護送高檔藝術品的任務？還真是新鮮。"

# game/chapter2.rpy:22
translate mandarin chapter_2_ecf57e4a:

    # vanta_char "Alright, boys—all hands on deck—or paint, I guess."
    vanta_char "好，大家——全部人手上陣——或者說全部人手上色，大概吧。"

# game/chapter2.rpy:24
translate mandarin chapter_2_741d34fa:

    # wilson_char "{size=40}To France!{/size}"
    wilson_char "{size=40}目標法國！{/size}"

# game/chapter2.rpy:26
translate mandarin chapter_2_b37a0845:

    # zali_char "{size=45}On y va!{/size}"
    zali_char "{size=45}我們出發吧！{/size}"

# game/chapter2.rpy:36
translate mandarin chapter_2_d5c7780d:

    # "Ah yes. The land of love, art, delicious food, and—of course—the birthplace of the one and only Vezalius Bandage."
    "真好，愛與藝術之地——當然還是世上獨一無二的 Vezalius Bandage 的出生地。"

# game/chapter2.rpy:37
translate mandarin chapter_2_6419b5a9:

    # "After successfully delivering the painting to the Parisian manor, the three of you step out into the heart of Paris."
    "成功把畫作送到巴黎的莊園後，你們三人步入巴黎市中心。"

# game/chapter2.rpy:38
translate mandarin chapter_2_d7295815:

    # "The city buzzes with life—locals stroll along cobbled streets, the aroma of fresh coffee drifts from bustling cafés, and the golden afternoon sun casts a warm glow over the historic architecture."
    "這座城市充滿生命力——當地人漫步在鵝卵石鋪成的街道上，剛出爐咖啡的香氣從繁忙的咖啡廳散出，金黃色的午後暖陽照耀著歷史建築。"

# game/chapter2.rpy:41
translate mandarin chapter_2_0607faaf:

    # zali_char "Feels good to be back somewhere familiar."
    zali_char "回家的感覺真好。"

# game/chapter2.rpy:44
translate mandarin chapter_2_8de37484:

    # wilson_char "Finally, Paris! And—oh my god—I can smell fresh bread and pastries!"
    wilson_char "終於到巴黎了！天啊，我已經聞到剛出爐的麵包跟點心的味道了！"

# game/chapter2.rpy:47
translate mandarin chapter_2_3912414e:

    # vanta_char "Do we want to get some snacks? God, long flights make me hungry."
    vanta_char "要不要去買點零食？媽呀，坐長途班機真的快餓死我了。"

# game/chapter2.rpy:48
translate mandarin chapter_2_f1527f9b:

    # "Your stomach growls at the thought of food, leading you to the nearest boulangerie."
    "一想到食物，你的肚子不禁咕嚕作響，於是你們走進了最近的麵包店。"

# game/chapter2.rpy:49
translate mandarin chapter_2_aeb0b3e1:

    # "Stepping into the bakery, you're met with the buttery scent of freshly baked croissants and the quiet shuffle of locals picking up their pastries."
    "你們一踏進麵包店，迎面而來的是剛出爐可頌的奶油香氣，幾位熟客正輕聲細語地挑選著麵包。"

# game/chapter2.rpy:50
translate mandarin chapter_2_f030324e:

    # "As you browse the pastry counter, your phone buzzes in your pocket. You pull it out and glance at the screen."
    "在你瀏覽點心櫃的同時，口袋裡的手機開始震動，你掏出手機並看向螢幕。"

# game/chapter2.rpy:52
translate mandarin chapter_2_abf7d016:

    # vanta_char "... Oh brother. What in the world?"
    vanta_char "……不是哥們，什麼鬼啊？"

# game/chapter2.rpy:55
translate mandarin chapter_2_2060e6cc:

    # "Wilson and Zali immediately lean in, their curiosity piqued as they look over your shoulder."
    "Wilson 和 Zali 立刻好奇地湊了上來，從你的肩上看過去。"

# game/chapter2.rpy:56
translate mandarin chapter_2_ee323680:

    # wilson_char "\"Hello, Krisis. It seems you have been warmly welcomed to the wonderful and vibrant Paris. I do hope you enjoy what you can—because soon enough, the prize will be mine. Consider this fair warning before I snatch it from right under your noses. All the worst, Phantom Thief.\""
    wilson_char "「Krisis 的各位好。看來你們已經被美好又充滿活力的巴黎熱情迎接了。誠摯希望你們可以盡情享受——因為畫作很快就會成為我的囊中之物。在我從你們眼皮底下把它偷走前，先鄭重思考一下這則警告吧。 萬事不如意，怪盜上。」"

# game/chapter2.rpy:58
translate mandarin chapter_2_54ccca8b:

    # zali_char "A direct threat to our mission... But what? Phantom Thief?"
    zali_char "直接針對我們任務的威脅……但這是什麼？怪盜？"

# game/chapter2.rpy:60
translate mandarin chapter_2_6959c398:

    # wilson_char "Well, there goes snack time. Why does this keep happening?"
    wilson_char "好吧，點心時間泡湯了。為什麼這種事一直發生啊？"

# game/chapter2.rpy:62
translate mandarin chapter_2_e194e21c:

    # vanta_char "I guess we just gotta ball. No time for croissants, boys—duty calls, again."
    vanta_char "看來我們只能 ball 了，也沒時間吃可頌了，兄弟們——任務要緊。"

# game/chapter2.rpy:64
translate mandarin chapter_2_5a16ce90:

    # "Just then, your phone vibrates again—this time, an incoming call. You're surprised by the caller on screen."
    "就在這時，你的手機再一次震動——這次是一通電話，你被螢幕上顯示的來電者嚇了一跳。"

# game/chapter2.rpy:65
translate mandarin chapter_2_f76c70bb:

    # "It's Rich Lady. You pick up the phone and put it on speaker."
    "是那位貴婦。你接起電話並開啟擴音。"

# game/chapter2.rpy:71
translate mandarin chapter_2_cd0eb4da:

    # manor_owner_char "Hello heroes! I'm sorry to call you so suddenly, did you happen to receive a message from the Phantom Thief?"
    manor_owner_char "哈囉，英雄們！不好意思突然打給你們，你們是否有收到怪盜的訊息呢？"

# game/chapter2.rpy:73
translate mandarin chapter_2_d2e36568:

    # vanta_char "Hello ma'am. Yes, we did! We are just about to inform you and head over."
    vanta_char "女士好，是的，我們有收到訊息！ 我們正準備告知您此事並前往莊園。"

# game/chapter2.rpy:74
translate mandarin chapter_2_94ef8721:

    # "There's a small pause on the other end, like she is carefully choosing her words."
    "對面暫停了片刻，看來她正在仔細挑揀用字。"

# game/chapter2.rpy:75
translate mandarin chapter_2_2cf6e41f:

    # manor_owner_char "... Well, you probably wouldn't know this, but a few years ago, there was a series of high-profile thefts across the city—paintings, jewels, priceless artifacts—all of them vanishing without a trace."
    manor_owner_char "……嗯，你們可能不知道這件事。但幾年前，這座城市發生了一系列轟動一時的偷竊案——畫作、珠寶、無價的工藝品——全都消失得無影無蹤。"

# game/chapter2.rpy:76
translate mandarin chapter_2_ece3dfa3:

    # manor_owner_char "Museums, private collections, even high-security vaults weren't safe. And the thief?\nHe always left a note signed 'Phantom Thief.'"
    manor_owner_char "博物館、私人收藏，甚至連戒備森嚴的金庫都不安全。那小偷呢？他每次都只留下一張署名「怪盜」的紙條。"

# game/chapter2.rpy:77
translate mandarin chapter_2_86993953:

    # manor_owner_char "He was never caught. If this message really is from him... I... I need you here immediately! You must protect the painting! Please!"
    manor_owner_char "他從來沒有被抓到過。如果這則訊息真的是他傳的，我……我需要你們馬上過來！你們一定要保護好這幅畫作！拜託了！"

# game/chapter2.rpy:78
translate mandarin chapter_2_6d97fde4:

    # "Her voice rises with panic."
    "她的聲音因慌張而拔高。"

# game/chapter2.rpy:79
translate mandarin chapter_2_2b6f5188:

    # manor_owner_char "What if our security isn't enough? What if he's already planted traps? What if he lied about the date and—oh my god, what if the painting is already gone?! I need to check—"
    manor_owner_char "萬一我們的保全措施不夠怎麼辦？如果他已經設了陷阱怎麼辦？如果他說的日期是假的——我的天啊，如果那幅畫作已經不見了怎麼辦？！我得去檢查——"

# game/chapter2.rpy:84
translate mandarin chapter_2_d40f2158:

    # zali_char "S'il vous plaît, madam. Take a deep breath. Rest assured, Krisis is on the case."
    zali_char "女士，深呼吸。請放心，Krisis 正在進行調查。"

# game/chapter2.rpy:86
translate mandarin chapter_2_da561393:

    # wilson_char "We'll be there shortly. If this Phantom Thief is really back, he won't be getting away so easily this time."
    wilson_char "我們很快就會抵達。 如果怪盜真的回歸了，這次他可無法那麼輕易逃走。"

# game/chapter2.rpy:88
translate mandarin chapter_2_c10298a6:

    # vanta_char "Exactly. We've got this. We're heading there now."
    vanta_char "沒錯，交給我們吧！我們已經在路上了。"

# game/chapter2.rpy:97
translate mandarin chapter_2_b218734d:

    # manor_owner_char "Ah, Krisis! You got here fast, I am so glad. I want to tell you about my perfect plan to stop the Phantom Thief!"
    manor_owner_char "哦！Krisis！很開心你們這麼快就到了。我想告訴你們一個可以阻止怪盜的完美計畫！"

# game/chapter2.rpy:98
translate mandarin chapter_2_64187c3e:

    # "She seems much calmer now, her eyes filled with determination. The panic from earlier is nowhere to be seen."
    "她現在看上去冷靜了一點，她眼裡原先的驚慌已然被決心取代。"

# game/chapter2.rpy:101
translate mandarin chapter_2_ce8d246b:

    # zali_char "Okay great, walk us through your plan!"
    zali_char "太好了，展開說說！"

# game/chapter2.rpy:102
translate mandarin chapter_2_9f7d9eb5:

    # manor_owner_char "Alright! So, when I was planning this party, I thought—why not bring in some entertainment? A comedy show sounded like a great idea!"
    manor_owner_char "好的，所以呢，我在策畫這場派對時，我就在想——為什麼不加一些娛樂活動呢？喜劇表演感覺\n就很不錯！"

# game/chapter2.rpy:103
translate mandarin chapter_2_819f1525:

    # manor_owner_char "But guess what? Turns out, the comedian I hired is also a hero! Small world, huh?\nWouldn't it be amazing for you to work with him?"
    manor_owner_char "但你猜怎麼了？我僱用的喜劇演員居然也是一位英雄！這世界真小，是吧？你們不覺得，如果可以跟他合作很好嗎？"

# game/chapter2.rpy:104
translate mandarin chapter_2_3142bad4:

    # manor_owner_char "He should be arriving any moment now. Oh, you're going to love him—I promise."
    manor_owner_char "他應該很快就會到，我保證你們一定會愛死他的。"

# game/chapter2.rpy:105
translate mandarin chapter_2_ff5c7705:

    # manor_owner_char "Now, here's the plan. I need all of you to go undercover—either as party staff or as guests. This way, the Phantom Thief won't know exactly who I've hired for security."
    manor_owner_char "然後這是我的計畫：我需要你們臥底成派對的工作人員或來賓，這樣怪盜才不會知道我到底僱用了誰來當守衛。"

# game/chapter2.rpy:108
translate mandarin chapter_2_009336e8:

    # vanta_char "Sounds good, we'll be ther—No, I don't want to say that. Your plan sounds solid.\nSo... Another hero? I wonder who that is..."
    vanta_char "感覺不錯，我們會到——算了，我不想這樣講。你的計畫感覺很詳細。所以……另一位英雄？\n不知道會是誰……"

# game/chapter2.rpy:112
translate mandarin chapter_2_49749631:

    # "Before you can finish your thoughts, the sound of the door creaking open behind you makes you turn instinctively."
    "在你得出結論前，後方開門的聲響便促使你直覺地轉過頭。"

# game/chapter2.rpy:113
translate mandarin chapter_2_3f233464:

    # "First, you see sleek brown shoes. Then, a red-and-blue plaid suit, layered under a stylish brown coat. Your gaze travels upward, and your breath catches—"
    "首先你看見了光滑的棕色鞋子，接著是時髦的棕色外衣與紅藍相間的格子西裝。你視線向上，\n隨後屏住呼吸——"

# game/chapter2.rpy:122
translate mandarin chapter_2_a1246420:

    # wandv_char "M... Mana?!"
    wandv_char "M……Mana？！"

# game/chapter2.rpy:126
translate mandarin chapter_2_297349f3:

    # zali_char "Wow! Mana-san? I did not expect to see you here of all places! You are, of course, a world class comedian."
    zali_char "哇！Mana-san？沒想到會在這裡遇到你！真不愧是世界級的喜劇演員。"

# game/chapter2.rpy:128
translate mandarin chapter_2_0e22cc5f:

    # mana_char "Haha, yeah! Hello Krisis boys! Bet you didn't see this one coming. Surprise!"
    mana_char "哈哈，就是我！哈囉，Krisis 的大家！你們絕對沒想過我會在這裡。嚇到了吧！"

# game/chapter2.rpy:130
translate mandarin chapter_2_551ab7cc:

    # "All of you exchange happy smiles before pulling him into a quick group hug. A JP hero was the last thing you expected to meet in France—but that only makes it more exciting. Getting to work alongside Mana is a rare opportunity."
    "你們笑得燦爛，並快速抱了一下他。你從未預料到會在法國遇見 JP 的英雄——不過這場偶遇也讓整件事更加刺激。畢竟和 Mana 一起工作的機會可不是每天都有。"

# game/chapter2.rpy:134
translate mandarin chapter_2_db4c9fa5:

    # manor_owner_char "Wow, it seems like you already know each other—this should go even more smoothly!"
    manor_owner_char "哇，看來你們本來就認識，那事情應該會比我預想的還順利。"

# game/chapter2.rpy:135
translate mandarin chapter_2_f29d9f6e:

    # "You chuckle and swing an arm over Mana's shoulder."
    "你輕笑，並伸手攬過 Mana 的肩膀。"

# game/chapter2.rpy:137
translate mandarin chapter_2_e63ac733:

    # vanta_char "You could say he's like our brother from another country. We may be in different divisions, but we've had each other's backs before."
    vanta_char "他就像從另一個國家來的兄弟。雖然我們在不同分部工作，但也曾經合作過。"

# game/chapter2.rpy:141
translate mandarin chapter_2_18ac9feb:

    # zali_char "Yeah, Mana and I even defused a bomb together once...totally went according to plan. Obviously, nothing exploded. No one panicked. Flawless, even."
    zali_char "是啊，Mana 和我甚至一起拆彈過……結果就如計畫般順利。絕對沒有東西爆炸，沒有人驚慌失措，可說是天衣無縫。"

# game/chapter2.rpy:143
translate mandarin chapter_2_6060875c:

    # mana_char "Ah... Yeah. I, uh...definitely remember that. Haha...ha..."
    mana_char "呃……對。我，呃……還記得很清楚呢。哈哈……哈……"

# game/chapter2.rpy:147
translate mandarin chapter_2_c47bdeb4:

    # wilson_char "Anyway! With the four of us, stopping the Phantom Thief should be easy peasy.\nRight, guys?"
    wilson_char "反正！只要我們四個出馬，阻止怪盜肯定是小事一樁。對吧，大家？"

# game/chapter2.rpy:148
translate mandarin chapter_2_f5917a49:

    # "A chorus of “YES!” erupts, filling the room with energy. Rich Lady watches, amusement flickering across her face as she visibly relaxes."
    "「當然！」所有人的喊聲迸發開來，讓房間充滿活力。貴婦注視著你們，顯而易見地放鬆，臉上閃過一絲愉悅。"

# game/chapter2.rpy:151
translate mandarin chapter_2_0c9f7996:

    # manor_owner_char "Alright, let's head to the dining room, enjoy a good meal and finalize the plan for the day."
    manor_owner_char "好的，那我們就去餐廳用餐並完善我們的計畫吧。"

# game/chapter2.rpy:157
translate mandarin chapter_2_6c68785f:

    # "The night of the party arrives, and with it, the weight of the mission. The Phantom Thief\nhas never been caught—but tonight, that changes."
    "派對之夜降臨，隨之而來的還有這場任務的壓力。怪盜尚未被逮捕——但今晚，一切都會不同。"

# game/chapter2.rpy:160
translate mandarin chapter_2_b5e5a287:

    # manor_owner_char "Your disguises are ready. We've prepared individual changing rooms for each of you, and the outfits have been tailored to your exact measurements. Put them on and let me know if anything needs adjusting."
    manor_owner_char "你們的變裝道具已經準備好了。我們有為每個人提供了獨立更衣室，並且衣服都是為你們量身訂作的。更衣後如果有任何需要調整的地方，請務必告知我。"

# game/chapter2.rpy:161
translate mandarin chapter_2_6b551562:

    # "With a nod, the three of you step into your assigned rooms, while Mana waits outside."
    "你們三個點點頭，之後踏進指定的房間裡，Mana 則在外等待。"

# game/chapter2.rpy:165
translate mandarin chapter_2_1a585efc:

    # "Mana, fitting seamlessly into his outfit, will attend as an esteemed guest. Meanwhile, Krisis will blend in as staff, working behind the scenes."
    "穿著西裝的 Mana 會不著痕跡地扮成賓客，同時 Krisis 會混進幕後工作人員的行列。"

# game/chapter2.rpy:169
translate mandarin chapter_2_e7687a24:

    # "As the doors shut behind the heroes, Rich Lady lingers for a moment, a sly, knowing smile tugging at her lips."
    "在英雄帶上門後，貴婦在原地駐足了一會，隨即脣角勾起一抹意味深長的狡詐笑容。"

# game/chapter2.rpy:173
translate mandarin chapter_2_abaafedf:

    # "While waiting for Krisis to change, Mana exhales and adjusts his cuffs, taking in the grand surroundings. He doesn't need a disguise—his presence alone grants him access."
    "在等待 Krisis 更衣時，Mana 深呼吸並調整了袖口，張望廣闊的四周。他不必偽裝——他的存在就足以給他一張入場證了。"

# game/chapter2.rpy:174
translate mandarin chapter_2_04c7885b:

    # "But then—silence."
    "隨之而來的是寂靜。"

# game/chapter2.rpy:176
translate mandarin chapter_2_5fcf6278:

    # "Mana glances at the other doors, his brows furrowing slightly. Why are they taking so long?"
    "Mana 看向其他扇門，並微微皺眉。為什麼他們換衣服換那麼久？"

# game/chapter2.rpy:177
translate mandarin chapter_2_87865b9f:

    # mana_char "Uh... Krisis? You guys good in there?"
    mana_char "呃……Krisis？你們在裡面還好嗎？"

# game/chapter2.rpy:180
translate mandarin chapter_2_77d65967:

    # "No response."
    "無人回應。"

# game/chapter2.rpy:181
translate mandarin chapter_2_c4e27b1f:

    # "Then—slowly, hesitantly, the doors creak open."
    "緊接著——有人緩慢而猶豫地打開了門。"

# game/chapter2.rpy:182
translate mandarin chapter_2_0e5742b2:

    # "And let's just say...their disguises aren't exactly what they expected."
    "這麼說吧……這可不是他們原先預期的偽裝。"

# game/chapter2.rpy:183
translate mandarin chapter_2_675b89da:

    # wilson_char "..."
    wilson_char "……"

# game/chapter2.rpy:184
translate mandarin chapter_2_27e0a79b:

    # zali_char "..."
    zali_char "……"

# game/chapter2.rpy:185
translate mandarin chapter_2_2e688bd5:

    # vanta_char "..."
    vanta_char "……"

# game/chapter2.rpy:207
translate mandarin chapter_2_7c879c27:

    # "Mana tries—and fails—to suppress a snicker, laughter bubbling out as he takes in the expressions on all of your faces."
    "Mana 嘗試憋笑，但失敗了。在他掃視你們的表情時，笑聲還是忍不住從口中漏出。"

# game/chapter2.rpy:212
translate mandarin chapter_2_c2113716:

    # wilson_char "So...when you said 'staff uniforms,' did you just casually forget to mention that we'd be in maid outfits?"
    wilson_char "所以……在你說「員工制服」的時候，是單純忘記跟我們說我們是要穿女僕裝嗎？"

# game/chapter2.rpy:213
translate mandarin chapter_2_67644519:

    # "Rich Lady grins warmly, without a hint of remorse."
    "貴婦露出溫暖的笑，表情不帶一絲悔意。"

# game/chapter2.rpy:214
translate mandarin chapter_2_acd63970:

    # manor_owner_char "Oh, did I forget to mention the exact roles? Must've slipped my mind. But look at you three—absolutely fabulous!"
    manor_owner_char "哦！我忘記說明具體的角色了嗎？肯定是不小心忘記了。但看看你們三個——太美了！"

# game/chapter2.rpy:217
translate mandarin chapter_2_e0193d76:

    # mana_char "I have to say... You all look amazing. I am in awe... Especially Wilson..."
    mana_char "我必須說……你們超美的。我真的嘆為觀止……尤其是Wilson……"

# game/chapter2.rpy:221
translate mandarin chapter_2_a6cacfe2:

    # "Realizing there's no way out, you accept your fate and commit to the maid spirit."
    "在意識到自己無路可逃後，你們接受了命運並安分地繼續穿著女僕裝。"

# game/chapter2.rpy:222
translate mandarin chapter_2_3af92b10:

    # "With the party underway, it's time to put aside distractions—your mission is to protect the Real painting."
    "既然派對正在進行中，是時候全神貫注了——畢竟你的任務是保護「Real」這幅畫。"

# game/chapter2.rpy:223
translate mandarin chapter_2_1d2f6b81:

    # "And speaking of which..."
    "話說回來……"

# game/chapter2.rpy:227
translate mandarin chapter_2_45d22fa5:

    # wilson_char "Mana, you haven't seen the Real painting in person before, have you? Trust me, you need to. It's a masterpiece."
    wilson_char "Mana，你是不是還沒親眼看過「Real」 這幅畫？相信我，你一定要去看看。它簡直就是神作！"

# game/chapter2.rpy:228
translate mandarin chapter_2_71e9e128:

    # mana_char "I haven't, but I'd love to!"
    mana_char "還沒，但我非常樂意！"

# game/chapter2.rpy:234
translate mandarin chapter_2_dd02bf42:

    # "The four of you make your way to where the renowned painting is displayed in all its glory."
    "你們四人一起前往這幅尊貴的名作展示的地方。"

# game/chapter2.rpy:235
translate mandarin chapter_2_8cc1715c:

    # "Mana's breath catches as he takes in the masterpiece before him, his eyes slowly widening with admiration."
    "在欣賞眼前這幅鉅作時，Mana 屏住呼吸，不禁因欽慕而睜大雙眼。"

# game/chapter2.rpy:236
translate mandarin chapter_2_902e9e8e:

    # "He steps in closer, his gaze tracing the intricate details."
    "他靠近這幅畫，視線描繪著精緻的細節。"

# game/chapter2.rpy:240
translate mandarin chapter_2_f1a128e1:

    # mana_char "Wow. This is indeed...a masterpiece. The angles, the compositions and the coloring... Whoa, even the saliva..."
    mana_char "哇，這真是……神作啊！這個角度、構圖，還有用色……哇嗚，就連口水也是……"

# game/chapter2.rpy:241
translate mandarin chapter_2_e37b2180:

    # "Leaning in further, his eyes capture every corner. The drool glistening around the\nmouth is...definitely very well-rendered."
    "Mana 又靠近了一點，視線不放過任何一個角落。他們嘴角晶瑩的口水確實描繪得……非常細緻。"

# game/chapter2.rpy:243
translate mandarin chapter_2_c9ead1f3:

    # "Then, something feels off. His eyes narrow as he reaches for the frame, tilting his head\nand peeking behind the painting."
    "但下一刻他就感受到了不對勁。他在伸手觸碰畫框時瞇起眼，歪頭去窺看畫作的後方。"

# game/chapter2.rpy:245
translate mandarin chapter_2_9798f4ac:

    # "His breath hitches, and his eyes widen as he spots a bomb—small, yet clearly not\nto be underestimated."
    "他猛地屏住呼吸，雙眼在看見炸彈時睜大——炸彈雖小，威力卻不容小覷。"

# game/chapter2.rpy:247
translate mandarin chapter_2_6db398c7:

    # "Mana recognizes it instantly. He knows this type of bomb all too well. His eyes dart\nstraight to Zali."
    "Mana 馬上就認了出來，他對這種炸彈再熟悉不過了。他視線立刻轉向 Zali。"

# game/chapter2.rpy:249
translate mandarin chapter_2_837aa7af:

    # mana_char "Zali! Zali! Zali!"
    mana_char "Zali！Zali！Zali！"

# game/chapter2.rpy:253
translate mandarin chapter_2_5ecf0d70:

    # "Zali looks at Mana, slightly confused, but steps forward regardless. Mana leans in,\nlowering his voice to a whisper."
    "Zali 有些疑惑地看向 Mana，但還是立刻走上前。Mana 湊近他，壓低聲音好用氣音對話。"

# game/chapter2.rpy:256
translate mandarin chapter_2_69d902f8:

    # mana_char "Look here... A bomb. We need to move this painting to a corner and handle it right away."
    mana_char "你看……是炸彈。我們必須把這幅畫移到角落，並且馬上把炸彈處理掉才行。"

# game/chapter2.rpy:257
translate mandarin chapter_2_3c3a1e3d:

    # "Both Wilson and you hear Mana's voice through the earpiece. The three of you exchange glances but keep your expressions neutral. Trying not to show any signs of distress, you maintain your professional smiles."
    "你和 Wilson 都透過耳機聽見了 Mana 的聲音。你們三人互看一眼，但表情維持冷靜，試著不展現出心中的不安，並保持著專業的微笑。"

# game/chapter2.rpy:259
translate mandarin chapter_2_f8daf572:

    # zali_char "Of course. Let's move this over there. We've done this before, Mana. I know we can pull it off again, right?"
    zali_char "當然，我們把這拿過去吧。Mana，我們有經驗——所以會再次成功，對吧？"

# game/chapter2.rpy:260
translate mandarin chapter_2_f94b08a7:

    # "Zali and Mana lift the painting off the wall, carefully carrying it toward a secluded corner of the room, away from the guests. They turn the painting over, eyes locking onto the red light pulsing behind it."
    "Zali 和 Mana 把畫作拿下牆，謹慎地讓它遠離客人，拿到房裡僻靜的角落。他們將畫作轉面，緊盯著後面閃爍的紅色燈光。"

# game/chapter2.rpy:261
translate mandarin chapter_2_e53bb798:

    # zali_char "Mana, the last time we defused this type of bomb—"
    zali_char "Mana，上次我們拆除這種炸彈——"

# game/chapter2.rpy:269
translate mandarin chapter_2_676a0f7e:

    # "All of a sudden, the room goes dark. Panic erupts as people scramble, bumping into each other in confusion."
    "突然，房間暗了下來。大家急忙逃竄，許多人在慌亂中撞到了其他人。"

# game/chapter2.rpy:270
translate mandarin chapter_2_7499b5bf:

    # mana_char "わあ—これは最悪や..."
    mana_char "わあ—これは最悪や..."

# game/chapter2.rpy:271
translate mandarin chapter_2_595e79d1:

    # "Mana and Zali freeze, they immediately scanning for a source of light—without it, defusing the bomb would be impossible."
    "Mana 和 Zali 頓在原地，迅速開始搜尋光源——要是沒有燈光，拆除炸彈就會是不可能的任務。"

# game/chapter2.rpy:277
translate mandarin chapter_2_e8569ccd:

    # wandv_char "{size=40}Whoa!! What's—{/size}"
    wandv_char "{size=40}哇！！那是——{/size}"

# game/chapter2.rpy:278
translate mandarin chapter_2_f7caeab6:

    # "Despite the darkness making it hard to see, you and Wilson remain steady, expertly weaving through the frantic crowd."
    "雖然眼前一片黑暗，你和 Wilson 依舊保持冷靜，熟練地在混亂的人群中穿梭。"

# game/chapter2.rpy:279
translate mandarin chapter_2_b5721e12:

    # wilson_char "Any idea where the fuse box could be?"
    wilson_char "你知道保險絲盒可能在哪裡嗎？"

# game/chapter2.rpy:280
translate mandarin chapter_2_93489e66:

    # vanta_char "Not really! Your guess is as good as mine."
    vanta_char "不知道！我也跟你一樣迷茫。"

# game/chapter2.rpy:281
translate mandarin chapter_2_8a28c5b6:

    # wilson_char "Let's try the kitchen first!"
    wilson_char "我們先去廚房看看！"

# game/chapter2.rpy:282
translate mandarin chapter_2_ffcfd1a6:

    # vanta_char "... You just want food, don't you?"
    vanta_char "……你只是想吃東西吧？"

# game/chapter2.rpy:283
translate mandarin chapter_2_a7c4c656:

    # wilson_char "Hah?? I mean, yeah, but— Ugh, shut up, let's just go..."
    wilson_char "蛤？？我是說，對啦，但——呃，閉嘴啦，去就對了……"

# game/chapter2.rpy:284
translate mandarin chapter_2_7d56aa8c:

    # vanta_char "Alright then! Let's go!"
    vanta_char "好吧！那我們走吧！"

# game/chapter2.rpy:289
translate mandarin chapter_2_bef0a9ec:

    # zali_char "Wilson! Mana and I couldn't find any light source near us. We're holding the painting,\nbut if you can get to the fuse box—it's probably near the kitchen or in a utility room in mansions like this..."
    zali_char "Wilson！Mana 和我在附近找不到光源。我們現在拿著這幅畫，但如果你找得到保險絲盒——它應該是在廚房附近，也可能在這種建築會有的雜物間裡……"

# game/chapter2.rpy:292
translate mandarin chapter_2_0f7bab05:

    # "You and Wilson weave through the crowd, careful not to knock anyone over—or get crushed yourselves."
    "你們二人快速穿過人潮，同時極力避免撞到任何人——或者被任何人撞到。"

# game/chapter2.rpy:294
translate mandarin chapter_2_30ade051:

    # "A few meters away, the sharp crash of shattering glass cuts through the chaos.\nEvery hero stiffens, heads snapping toward the sound as tension thickens the air."
    "就在幾公尺遠的地方，玻璃碎裂的刺耳撞擊聲劃破了混亂。壓力讓空氣變得愈發沉重。所有英雄僵在原地，隨即轉向聲音源頭。"

# game/chapter2.rpy:295
translate mandarin chapter_2_8d80a2ed:

    # "Then, Rich Lady's frantic voice crackles through their earpieces."
    "接著，貴婦驚慌的聲音從耳機裡傳來。"

# game/chapter2.rpy:297
translate mandarin chapter_2_d1204856:

    # manor_owner_char "Someone's stealing my necklace! It's worth over $5 million!\n{size=40}My prized possessionnnn—{/size}"
    manor_owner_char "有人在偷我的項鍊！它價值超過五百萬美金！\n{size=40}我珍貴的收藏啊啊啊啊啊——{/size}"

# game/chapter2.rpy:301
translate mandarin chapter_2_24285394:

    # "The moment the price is mentioned, Mana's eyes widen—this was a setup. He wastes no time, relaying new orders to the team."
    "一聽到價格，Mana 便睜大雙眼——這是個圈套。他毫不遲疑，立刻向團隊下達新的指示。"

# game/chapter2.rpy:302
translate mandarin chapter_2_a506062e:

    # mana_char "Krisis, come in! It was never about the painting—that was just a decoy! Find the thief!\nThe necklace is the real target!"
    mana_char "Krisis，立即注意！結果根本不干畫作的事——它只是幌子而已！我們得找到怪盜！那條項鍊才是他真正的目標！"

# game/chapter2.rpy:305
translate mandarin chapter_2_c2f6e37a:

    # vanta_char "God dammit! On it! Willy, You got the fuse box?"
    vanta_char "老天啊！我們在努力了！Willy，你可以搞定保險絲盒嗎？"

# game/chapter2.rpy:307
translate mandarin chapter_2_711c4fe3:

    # wilson_char "Yup! Leave it to me!"
    wilson_char "嗯哼！交給我！"

# game/chapter2.rpy:308
translate mandarin chapter_2_ef80ba16:

    # "The power is out, and the room is in chaos. You don't have time to wait for the lights to come back—every second wasted is a step closer to the thief escaping with the necklace."
    "停電了，因此房裡陷入一片混亂。你們已經等不到電力恢復了——等待的每一秒都給了怪盜多一點偷走項鍊後逃之夭夭的機會。"

# game/chapter2.rpy:309
translate mandarin chapter_2_e965ee05:

    # "You and Wilson split up—he rushes to restore power, while you push through the frantic crowd, barely dodging guests scrambling in all directions."
    "你和 Wilson 分頭行動——他衝去恢復電力，而你則穿梭在人群中，勉強閃過四處驚慌逃竄的賓客。"

# game/chapter2.rpy:310
translate mandarin chapter_2_4c21c570:

    # "The darkness makes it impossible to see clearly, but you don't need to. The thief is moving fast—you just have to be faster."
    "黑暗讓你看不清眼前的一切，但不要緊。怪盜移動得很快，而你只要更快就好。"

# game/chapter2.rpy:315
translate mandarin chapter_2_88cb7fb8:

    # "Wilson moves quickly, navigating the dimly lit corridor toward the kitchen. The emergency lights flicker weakly, casting distorted shadows against the mansion's ornate walls.\nHis heels click against the polished floor as he picks up the pace—"
    "Wilson 迅速移動，穿梭在昏暗的走廊中，朝著廚房前進。微弱的緊急燈閃爍不定，在豪宅華麗的牆面上投下扭曲的影子。他的腳步聲在拋光地板上清晰作響，步伐也越來越快——"

# game/chapter2.rpy:318
translate mandarin chapter_2_e17a6394:

    # "Then, resistance. His dress jerks him to a sudden stop."
    "就在這時，一股阻力猛地拉住他，裙擺卡住了，讓他瞬間停下腳步。"

# game/chapter2.rpy:319
translate mandarin chapter_2_6d9ee4f9:

    # "He glances back and realizes—the blade of a decorative suit of armor has caught the fabric, pinning him in place."
    "他向後看，意識到是盔甲裝飾的刀刃勾到了裙子，才導致他動彈不得。"

# game/chapter2.rpy:321
translate mandarin chapter_2_5433bc54:

    # wilson_char "{size=40}Oh my god! My dress—! UGHHHHH!!{/size}"
    wilson_char "{size=40}我的天啊！我的裙子啊啊啊啊啊啊！{/size}"

# game/chapter2.rpy:322
translate mandarin chapter_2_1a4785ed:

    # "Wilson tugs once, twice—before the entire suit of armor lurches forward and crashes\nto the ground with a deafening clang."
    "Wilson 用力扯了一下、兩下——整套盔甲向前倒在地上，發出震耳欲聾的撞擊聲。"

# game/chapter2.rpy:328
translate mandarin chapter_2_c42589b7:

    # wilson_char "Ughhh, I swear, I'm the clumsiest maid in this mansion."
    wilson_char "呃呃，我敢說我是這個莊園裡最笨手笨腳的女僕了。"

# game/chapter2.rpy:330
translate mandarin chapter_2_84a107ce:

    # "Wilson stands up and gives his dress a quick shake, then hurries on. The fuse box isn't going to find itself!"
    "Wilson 站起身後快速抖了抖裙子，接著繼續趕路。畢竟保險絲盒可不會自己跑出來！"

# game/chapter2.rpy:331
translate mandarin chapter_2_e2edd319:

    # wilson_char "Great. Just great. First, I get assaulted by medieval decor, and now my dress is ruined."
    wilson_char "很好啊。 首先，我被中世紀盔甲攻擊，然後現在我的裙子毀了。"

# game/chapter2.rpy:334
translate mandarin chapter_2_02a2e70b:

    # "Before he can complain further, Zali's voice crackles through his earpiece."
    "在他繼續抱怨下去前，Zali 的聲音傳進耳機。"

# game/chapter2.rpy:337
translate mandarin chapter_2_a3b12c99:

    # zali_char "Wilson! How long is it going to take you to get to the fuse box? Mana and I don't have enough light sources to defuse the bomb!"
    zali_char "Wilson！你還要多久才找得到保險絲盒？Mana 和我沒有足夠的光源來拆炸彈！"

# game/chapter2.rpy:340
translate mandarin chapter_2_f9622474:

    # wilson_char "I think I'm getting there! Just give me a little more time to figure this out!"
    wilson_char "我應該快找到了！再給我一點時間！"

# game/chapter2.rpy:343
translate mandarin chapter_2_f5f18738:

    # zali_char "Okay! Be quick, but also don't hurt yourself, okay?"
    zali_char "好！快點，但小心不要受傷，好嗎？"

# game/chapter2.rpy:346
translate mandarin chapter_2_d33e6f82:

    # "Wilson finally reaches the kitchen. The heat from inactive stoves lingers, making the air thick. He keeps his hand against the wall, feeling his way through—then, his fingers hit something solid."
    "Wilson 終於抵達了廚房。閒置爐子的熱氣揮之不去，讓空氣變得厚重。他的手抵住牆壁，邊摸索邊走著。隨後，他的手指碰到了某個堅硬的東西。"

# game/chapter2.rpy:347
translate mandarin chapter_2_0fd8737d:

    # "A fuse box. Miraculously—or maybe suspiciously—it's unlocked."
    "是保險絲盒。它沒有上鎖，簡直是個奇蹟——或者說很可疑。"

# game/chapter2.rpy:348
translate mandarin chapter_2_1b927edf:

    # "Wilson flips the fuse box open, his eyes scanning the mess of switches and buttons.\nNo labels. No instructions anywere."
    "他把盒子翻開，視線掃描著雜亂的線和按鈕。全都沒有標示，也沒有指引。"

# game/chapter2.rpy:352
translate mandarin chapter_2_wilson_qte_3e7b8ada:

    # wilson_char "Jesus Christ... Okay, right. Here goes nothing..."
    wilson_char "老天爺啊……好吧，沒關係……"

# game/chapter2.rpy:398
translate mandarin chapter_2_wilson_timeout_6deeaad2:

    # "Sparks fly as Wilson fumbles with the switches, causing a momentary delay before the power finally surges back on."
    "在 Wilson 摸索開關時，火花迸了出來，導致電力恢復前延遲了一下。"

# game/chapter2.rpy:407
translate mandarin chapter_2_wilson_clear_d5bfe298:

    # "The lights flicker once before steadily returning."
    "燈光在恢復正常前閃爍了一下。"

# game/chapter2.rpy:411
translate mandarin chapter_2_2_138273e5:

    # "Wilson exhales, pushing the box shut as warm light spills through the halls."
    "Wilson 吐出一口氣，並在暖色燈光穿過大廳時把箱子闔上。"

# game/chapter2.rpy:412
translate mandarin chapter_2_2_ea6d9e85:

    # wilson_char "Thank god that worked! Time to help the others!"
    wilson_char "謝天謝地，成功了！該去幫其他人了！"

# game/chapter2.rpy:417
translate mandarin chapter_2_2_014e2a61:

    # "Back at the painting, Mana and Zali exchange glances as the lights flick back on."
    "回到畫作這裡，Mana 和 Zali 在房間重新亮起時對視一眼。"

# game/chapter2.rpy:418
translate mandarin chapter_2_2_ac34f0ab:

    # "On the bomb, four buttons are arranged in a square shape, their colors flashing in a specific sequence—one that feels eerily familiar—although, it's slightly different this time."
    "炸彈上面有四個排列成正方形的按鈕，而這些顏色正以特定順序閃爍。即使這次有點不同，\n但這景象還是熟悉得詭異。"

# game/chapter2.rpy:420
translate mandarin chapter_2_2_114e8abb:

    # mana_char "Wait, Zali... No way..."
    mana_char "等等，Zali……不是吧……"

# game/chapter2.rpy:421
translate mandarin chapter_2_2_d57969dd:

    # mana_char "This is slightly different to the bombs we defused before!"
    mana_char "這跟我們之前拆除的炸彈不太一樣！"

# game/chapter2.rpy:423
translate mandarin chapter_2_2_b3c1739e:

    # zali_char "Oh no... Ah, I see. Okay, I understand now."
    zali_char "糟了……不過沒關係。好，我現在瞭解了。"

# game/chapter2.rpy:424
translate mandarin chapter_2_2_fa843437:

    # zali_char "We need to remember the order of the flashing colors, and press the exact same buttons."
    zali_char "我們必須記得顏色閃爍的順序，然後按下相應的按鈕。"

# game/chapter2.rpy:426
translate mandarin chapter_2_2_7a6f8f21:

    # mana_char "Let's give it a go! I have faith in us, Zali!"
    mana_char "只能放手一搏了！Zali，我有自信！"

# game/chapter2.rpy:428
translate mandarin chapter_2_2_40391da1:

    # "Zali takes a deep breath, steadying his nerves. He can't let the pressure get to him—\nhe has to stay focused."
    "Zali 深呼吸好讓自己平靜下來。他不能讓自己被壓力影響——他必須專心。"

# game/chapter2.rpy:438
translate mandarin chapter_2_zali_flashing_1_d77378df:

    # zali_char "I'm ready, Mana! Let's do this! It's flashing now..."
    zali_char "Mana，我準備好了！加油！燈亮了……"

# game/chapter2.rpy:443
translate mandarin chapter_2_zali_flashing_1_4efa4dca:

    # mana_char "Oh my god! Okay! I've got this!! Here I go..."
    mana_char "我的天啊！好！我可以的！只要這樣……"

# game/chapter2.rpy:465
translate mandarin chapter_2_zali_flashing_2_2a3f8664:

    # "Mana presses the buttons in the correct order. A new set of colors begins flashing—\nit's not over yet!"
    "Mana 以正確的順序按下按鈕，新的一組顏色開始閃爍——任務還沒結束呢！"

# game/chapter2.rpy:467
translate mandarin chapter_2_zali_flashing_2_4200fd78:

    # zali_char "Alright! That was great, Mana! Oh...there's more? Leave it to me!"
    zali_char "太好了，Mana！哦……還有嗎？交給我吧！"

# game/chapter2.rpy:469
translate mandarin chapter_2_zali_flashing_2_a24b8f10:

    # mana_char "Okay, okay!"
    mana_char "好！"

# game/chapter2.rpy:479
translate mandarin chapter_2_zali_flashing_2_7498d02d:

    # manor_owner_char "My heroes! I was wondering if—"
    manor_owner_char "英雄們！我在想如果——"

# game/chapter2.rpy:483
translate mandarin chapter_2_zali_flashing_2_76f46f90:

    # "Rich Lady's voice suddenly comes through their ear piece. Both Zali and Mana freeze for a second as they try to focus on memorizing the sequence."
    "貴婦的聲音突然從耳機裡傳出，正嘗試專心記住順序的 Zali 和 Mana 都愣了一下。"

# game/chapter2.rpy:485
translate mandarin chapter_2_zali_flashing_2_6ab067bd:

    # zali_char "God dammit... Je suis désolé, I usually like ladies but not now! I need to focus!"
    zali_char "天啊……我很抱歉，我平常是愛女人士，但現在不是！我得專心！"

# game/chapter2.rpy:508
translate mandarin chapter_2_zali_flashing_3_c3a59889:

    # "With Zali's laser focus, he manages to press the buttons correctly, even with a few unexpected interruptions."
    "Zali 全神貫注，成功克服了微小的干擾並按下正確的按鈕。"

# game/chapter2.rpy:511
translate mandarin chapter_2_zali_flashing_3_29893eee:

    # zali_char "Oh my god, that was close. I almost lost my cool..."
    zali_char "天啊，差一點。我剛剛差點抓狂了……"

# game/chapter2.rpy:514
translate mandarin chapter_2_zali_flashing_3_5c433f7d:

    # "However, the bomb is still ticking. Zali and Mana take another deep breath."
    "然而，炸彈還在滴答作響。Zali 和 Mana 再次深呼吸。"

# game/chapter2.rpy:520
translate mandarin chapter_2_zali_flashing_3_f4fcfa34:

    # zali_char "Wait, was that yellow, blue, blue? or yellow, red, blue?"
    zali_char "等等，是黃、藍、藍嗎？還是黃、紅、藍？"

# game/chapter2.rpy:521
translate mandarin chapter_2_zali_flashing_3_8b6c12dc:

    # mana_char "Hmmm... Was there a red? Or it could be yellow, red, yellow, blue?"
    mana_char "嗯……有紅色嗎？還是有可能是黃、紅、黃、藍？"

# game/chapter2.rpy:523
translate mandarin chapter_2_zali_flashing_3_c6c5f9e4:

    # zali_char "No... I was pretty sure there was... Ahhh!! This is so hard! My memory!"
    zali_char "不是……我很確定有……啊啊啊！好難！我的金魚腦！"

# game/chapter2.rpy:546
translate mandarin chapter_2_zali_timeout_1d4f7443:

    # "Oh no—the time ran out! For a split second, nothing happens. Then—"
    "你按錯了按鈕。下一秒，無事發生，隨後——"

# game/chapter2.rpy:548
translate mandarin chapter_2_zali_timeout_7d12e17a:

    # "The red light flashes violently as the device lets out a sharp, high-pitched whine. Mana's breath catches—"
    "紅燈急劇閃爍，接著裝置發出尖銳、高頻率的聲響。Mana 倒吸一口氣——"

# game/chapter2.rpy:550
translate mandarin chapter_2_zali_timeout_f3985afb:

    # mana_char "ZALI—!!!"
    mana_char "ZALI——！！！"

# game/chapter2.rpy:558
translate mandarin chapter_2_zali_failed_56b2fb1e:

    # "A wrong button was pressed. For a split second, nothing happens. Then—"
    "你按錯了按鈕。下一秒，無事發生，隨後——"

# game/chapter2.rpy:560
translate mandarin chapter_2_zali_failed_7d12e17a:

    # "The red light flashes violently as the device lets out a sharp, high-pitched whine. Mana's breath catches—"
    "紅燈急劇閃爍，接著裝置發出尖銳、高頻率的聲響。Mana 倒吸一口氣——"

# game/chapter2.rpy:563
translate mandarin chapter_2_zali_failed_f3985afb:

    # mana_char "ZALI—!!!"
    mana_char "ZALI——！！！"

# game/chapter2.rpy:571
translate mandarin chapter_2_zali_clear_70987418:

    # "Zali presses the final buttons. A green light flickers on—the beeping stops.\nSilence. Then, relief."
    "Zali 按下最後的按鈕，綠燈隨之閃爍——嗶聲戛然而止，迎來了寂靜，最後是解脫。"

# game/chapter2.rpy:579
translate mandarin chapter_2_zali_clear_5d9615a0:

    # "Zali gently sets the bomb down before instantly pulling Mana into a tight hug. The two heroes cheer, letting out a collective sigh as the weight of the moment washes over them."
    "Zali 輕輕放下炸彈，隨即拉過 Mana 並緊緊抱住他。兩位英雄一齊歡呼，在想起此刻的沉重時同時嘆了口氣。"

# game/chapter2.rpy:580
translate mandarin chapter_2_zali_clear_4d52d222:

    # zali_char "Oh my goodness! We actually did it!"
    zali_char "我的天啊！我們真的做到了！"

# game/chapter2.rpy:581
translate mandarin chapter_2_zali_clear_6ee31ce3:

    # mana_char "Was there ever any doubt? We always got this!"
    mana_char "這還要懷疑嗎？這種事我們一直都能搞定！"

# game/chapter2.rpy:582
translate mandarin chapter_2_zali_clear_85fbbfa3:

    # "Only one thing left to do—for you to catch the Phantom Thief."
    "現在只剩下最後一個任務——抓捕怪盜。"

# game/chapter2.rpy:587
translate mandarin chapter_2_zali_clear_d2f9d838:

    # vanta_char "Alright! You're not going anywhere! Not on my watch!"
    vanta_char "好啊！你是無法從我眼皮底下逃走的！"

# game/chapter2.rpy:591
translate mandarin chapter_2_vanta_qte_1_ff3a6fbc:

    # "The Phantom Thief is fast, darting through the crowd. You need to act now—with your unmatched reflexes, you could totally jump over the table like a cool action hero...\nor, you know, just shove your way through the guests."
    "怪盜閃避人群的速度很快，你現在必須跟著移動——你完全可以像動作片裡帥氣的英雄一樣，\n用無出其右的反應力跳過桌子……或者，嗯，硬擠過這群賓客也行啦。"

# game/chapter2.rpy:615
translate mandarin chapter_2_vanta_1_1_751f329e:

    # "You leap over the table in one sleek motion. No distractions. No second chances.\nJust you, the chase, and the prize they think they can steal."
    "你俐落地跳過桌子。沒有干擾，沒有重來的機會，只有你、這場追逐，及怪盜以為他能偷到的寶物。"

# game/chapter2.rpy:625
translate mandarin chapter_2_vanta_1_2_7cd632d9:

    # "You keep moving, eyes locked on the thief. They're fast, but you follow closely."
    "你持續移動，視線釘在怪盜身上。他跑得很快，但你跟得很緊。"

# game/chapter2.rpy:634
translate mandarin chapter_2_vanta_timeout_1_36c024a6:

    # "You missed the opportunity to jump over the table, you push through the crowd instead, following the thief."
    "你錯失了跳過桌子的機會，於是你轉而穿過人群，跟在怪盜身後。"

# game/chapter2.rpy:642
translate mandarin chapter_2_vanta_qte_2_e72faabd:

    # "The thief is slipping away, heading straight for the exit. You spot a chance to intercept—dramatically dive through the window, or use the door like a reasonable person."
    "怪盜正迅速朝出口奔去。你看準攔截的時機——你可以戲劇性地跳窗，或者像正常人一樣開門出去。"

# game/chapter2.rpy:663
translate mandarin chapter_2_vanta_2_1_4d1d94a0:

    # "You don't think. You just move. You just ball the hell out."
    "腦袋還來不及反應，身體已經動了起來。你直接開 ball，毫不猶豫。"

# game/chapter2.rpy:665
translate mandarin chapter_2_vanta_2_1_79f36043:

    # "Pivoting sharply, you charge toward the window and throw yourself through it.\nThe impact shatters the glass, shards scattering in every direction as you twist mid-air.\nThe night air rushes past you before you hit the ground, rolling to absorb the impact."
    "你用力轉過身，奔向窗戶後奮力躍過。衝擊的力道撞破了玻璃，碎屑於你在空中扭身時四散。\n夜晚的空氣穿過，在你落地後滾動時吸收了衝擊力。"

# game/chapter2.rpy:668
translate mandarin chapter_2_vanta_2_1_9d89efb7:

    # "You land in a crouch—just ahead of the thief."
    "你落地蹲在怪盜正前方。"

# game/chapter2.rpy:677
translate mandarin chapter_2_vanta_2_2_5a75b82f:

    # "You push harder, legs burning as you sprint toward the exit. The thief is just ahead,\nslipping through the doorway. You grit your teeth and force your body to keep moving."
    "你更加用力地推門，雙腿在你衝向出口時燃燒。怪盜就在前方，他正準備溜過門廊。你咬緊牙關，強迫自己的身體繼續移動。"

# game/chapter2.rpy:678
translate mandarin chapter_2_vanta_2_2_8e8c5750:

    # "Your chest rises and falls heavily—you're exhausted. Chasing someone through a mansion full of people has drained every ounce of energy in your body, but you refuse to let them get away."
    "你的胸腔劇烈起伏——你已經精疲力盡。在人滿為患的大宅裡追捕怪盜已經榨乾了你體內所有精力，但你並不會就此屈服。"

# game/chapter2.rpy:679
translate mandarin chapter_2_vanta_2_2_b7442eab:

    # "Through sheer determination, you push forward, closing the gap. The moment you see an opening, you bolt ahead and lunge, tackling the thief to the ground with all the strength you have left."
    "憑著純粹的決心，你向前推，縮短你們的距離。看見機會那刻，你向前衝刺，並利用餘下的精力把怪盜壓制在地。"

# game/chapter2.rpy:688
translate mandarin chapter_2_vanta_timeout_2_e63eb21f:

    # "You push harder, legs burning as you sprint toward the exit. The thief is just ahead, slipping through the doorway. You grit your teeth and force your body to keep moving."
    "你更加用力地推門，雙腿在你衝向出口時燃燒。怪盜就在前方，他正準備溜過門廊。你咬緊牙關，強迫自己的身體繼續移動。"

# game/chapter2.rpy:689
translate mandarin chapter_2_vanta_timeout_2_8e8c5750:

    # "Your chest rises and falls heavily—you're exhausted. Chasing someone through a mansion full of people has drained every ounce of energy in your body, but you refuse to let them get away."
    "你的胸腔劇烈起伏——你已經精疲力盡。在人滿為患的大宅裡追捕怪盜已經榨乾了你體內所有精力，但你並不會就此屈服。"

# game/chapter2.rpy:690
translate mandarin chapter_2_vanta_timeout_2_b7442eab:

    # "Through sheer determination, you push forward, closing the gap. The moment you see an opening, you bolt ahead and lunge, tackling the thief to the ground with all the strength you have left."
    "憑著純粹的決心，你向前推，縮短你們的距離。看見機會那刻，你向前衝刺，並利用餘下的精力把怪盜壓制在地。"

# game/chapter2.rpy:700
translate mandarin chapter_2_3_94faa639:

    # "Without hesitation, you push forward and lunge, wrapping your arms around them and slamming them to the ground."
    "不等對方反應，你立刻向前衝去，猛地撲上前，一把將他壓制在地。"

# game/chapter2.rpy:701
translate mandarin chapter_2_3_e765b40e:

    # vanta_char "Game over, thief!"
    vanta_char "遊戲結束，怪盜！"

# game/chapter2.rpy:702
translate mandarin chapter_2_3_9b37b387:

    # "You yank the necklace free, holding it up in victory. Think chasing a thief in a maid dress\nis impossible? Nah-uh! Light work. Just another Tuesday."
    "你從怪盜手中搶過項鍊，並以勝者的姿態高舉那條項鍊。你以為穿著女僕裝追逐怪盜是不可能的事？並非如此！簡直稀鬆平常。"

# game/chapter2.rpy:710
translate mandarin chapter_2_3_3e5637ad:

    # "Just as you finish tying the thief's hands behind their back, you hear hurried footsteps approaching. Rich Lady, Mana, Zali, and Wilson rush toward you. Their faces are lit\nwith relief and awe."
    "就在你把怪盜的手反綁後，匆忙的腳步聲朝你傳來。貴婦、Mana、Zali、Wilson 全都跑了過來，他們鬆了一口氣，臉上滿是欣慰與敬佩。"

# game/chapter2.rpy:713
translate mandarin chapter_2_3_bcc39804:

    # manor_owner_char "Oh my god! You actually caught the Phantom Thief!"
    manor_owner_char "我的天啊！你真的抓到怪盜了！"

# game/chapter2.rpy:715
translate mandarin chapter_2_3_0e29d2d5:

    # zali_char "Now that was very impressive, Vanta!"
    zali_char "真是太厲害了，Vanta！"

# game/chapter2.rpy:718
translate mandarin chapter_2_3_f45cf538:

    # mana_char "Ah! As expected from the tyrant and the trusted Ace!"
    mana_char "啊！我們的暴君和可靠的王牌果然不會讓人失望！"

# game/chapter2.rpy:721
translate mandarin chapter_2_3_c8e13159:

    # wilson_char "And in a maid dress? Holy—"
    wilson_char "而且還穿著女僕裝？媽呀——"

# game/chapter2.rpy:726
translate mandarin chapter_2_3_574054cf:

    # "Rich Lady retrieves the stolen necklace, holding it up to the moonlight with teary eyes."
    "貴婦拿回失竊的項鍊，熱淚盈眶地向月光高舉它。"

# game/chapter2.rpy:727
translate mandarin chapter_2_3_d70ae5c6:

    # manor_owner_char "Oh, my beloved $5 million treasure! And the Real painting is also unharmed!\nTonight, we honor the hero!"
    manor_owner_char "哦，我心愛的五百萬寶物！「Real」也安然無恙！今晚我們以英雄為榮！"

# game/chapter2.rpy:730
translate mandarin chapter_2_3_bab50f25:

    # "Mana steps forward, pulling something from his pocket—a sealed envelope."
    "Mana 向前走去，並從口袋拿出一個東西——密封的信封。"

# game/chapter2.rpy:731
translate mandarin chapter_2_3_446460ec:

    # mana_char "Actually, there's something I want to give to you guys in person."
    mana_char "其實，我有東西想要親自給你們。"

# game/chapter2.rpy:732
translate mandarin chapter_2_3_6af512af:

    # mana_char "Krisis, consider this your formal invitation to Japan. We, Oriens and Dytica are celebrating our second anniversary together, and you're on the guest list, of course."
    mana_char "Krisis，這是找你們去日本的正式邀請。Oriens 和 Dytica 要一起慶祝二週年。想當然爾，Krisis 也在受邀名單中。"

# game/chapter2.rpy:736
translate mandarin chapter_2_3_4bdc6367:

    # wilson_char "Ooo...Fancy! You sure this isn't just an elaborate excuse to see me again?"
    wilson_char "哦哦……笑死！你確定這不是為了再次見到我而精心編造的藉口嗎？"

# game/chapter2.rpy:739
translate mandarin chapter_2_3_78e88354:

    # zali_char "Well, Vanta? What do you think? We haven't been in Japan together in a while, have we?"
    zali_char "Vanta 呢？你覺得如何？我們已經好一陣子沒去日本了，對吧？"

# game/chapter2.rpy:744
translate mandarin chapter_2_3_22877bd6:

    # "You take the invitation and tuck it into the pocket of your maid outfit. This mission was a great success, and one thing's certain—Krisis is going to Japan!"
    "你接過邀請函後塞進女僕裝的口袋裡。這場任務是你們大獲全勝，而還有一件事無庸置疑——那就是 Krisis 要出發前往日本了！"

# TODO: Translation updated at 2025-06-04 22:02

# game/chapter2.rpy:430
translate mandarin chapter_2_2_88f7f61c:

    # "Zali takes a deep breath, steadying his nerves. He can't let the pressure get to him—\nhe has to lock in."
    "Zali 深呼吸好讓自己平靜下來。他不能讓自己被壓力影響——他必須專心。"

translate mandarin strings:

    # game/chapter2.rpy:604
    old "Jump Over"
    new "跳過桌子"

    # game/chapter2.rpy:605
    old "Push Through"
    new "穿過人群"

    # game/chapter2.rpy:653
    old "Jump Through"
    new "跳窗"

    # game/chapter2.rpy:654
    old "Take the Door"
    new "從門走出去"


# TODO: Translation updated at 2025-06-14 23:19

# game/chapter2.rpy:75
translate mandarin chapter_2_a19464af:

    # vanta_char "Hello ma'am. Yes, we did! We were just about to inform you and head over."
    vanta_char "女士好，是的，我們有收到訊息！我們正準備告知您此事並前往莊園。"

# game/chapter2.rpy:133
translate mandarin chapter_2_efc8853d:

    # "All of you exchange happy smiles before pulling him into a quick group hug. A JP hero was the last person you expected to meet in France—but that only makes it more exciting. Getting to work alongside Mana is a rare opportunity."
    "你們笑得燦爛，並快速抱了一下他。你從未預料到會在法國遇見 JP 的英雄——不過這場偶遇也讓整件事更加刺激。畢竟和 Mana 一起工作的機會可不是每天都有。"

# game/chapter2.rpy:276
translate mandarin chapter_2_647d5ec7:

    # "Mana and Zali freeze, they immediately start scanning for a source of light—without it, defusing the bomb would be impossible."
    "Mana 和 Zali 頓在原地，迅速開始搜尋光源——要是沒有燈光，拆除炸彈就會是不可能的任務。"

# game/chapter2.rpy:762
translate mandarin chapter_2_3_ff7241d9:

    # zali_char "Well, Vanta? What do you think? We haven't been to Japan together in a while, have we?"
    zali_char "Vanta 呢？你覺得如何？我們已經好一陣子沒去日本了，對吧？"

