# TODO: Translation updated at 2025-06-04 19:09

translate mandarin strings:

    # game/inventory.rpy:268
    old "Find every hero in the Photo Diary \nto unlock the Travel Gallery!"
    new "找齊「相簿日記」中的所有英雄，解鎖旅程藝廊！"

# TODO: Translation updated at 2025-06-04 19:10

translate mandarin strings:

    # game/inventory.rpy:240
    old "No matter the time or place, heroes never stop. \nKrisis, Heroes of the Night—Touch Down!"
    new "無論哪個時間、哪個地點，英雄的腳步不會停歇。\n夜之英雄 Krisis，Touch Down！"

# TODO: Translation updated at 2025-06-04 19:51

translate mandarin strings:

    # game/inventory.rpy:258
    old "Small heroes, Big adventure—find every hero!"
    new "找出所有英雄及他們隱藏的東西吧！"

    # game/inventory.rpy:283
    old "A collection of shining moments, each one brought to \nlife by the brilliant creativity of the Vezcrewneers."
    new "集合眾多閃耀光芒的片段，\n每一個 Vezcrewneer 的創作都無比精彩。"

    # game/inventory.rpy:299
    old "Secret\nSnaps"
    new "焦點時刻"

    # game/inventory.rpy:300
    old "Photo\nDiary"
    new "相簿日記"

    # game/inventory.rpy:301
    old "Travel\nGallery"
    new "旅程畫廊"

# TODO: Translation updated at 2025-06-04 20:32

translate mandarin strings:

    # game/inventory.rpy:321
    old "Find every hero and what they're hiding!"
    new "找出所有英雄及他們隱藏的東西吧！"

# TODO: Translation updated at 2025-06-14 23:19

translate mandarin strings:

    # game/inventory.rpy:258
    old "Click the photos on the left and find every hero!"
    new "點開左邊照片，找到所有隱藏的英雄吧！"

    # game/inventory.rpy:268
    old "Find every hero in the Photo Diary and complete\nthe chapter to unlock the Travel Gallery!"
    new "找齊「相簿日記」中的所有英雄和物品，\n完成該任務即可解鎖「旅程畫廊」！"

