﻿# TODO: Translation updated at 2025-05-21 11:56

# game/chapter3.rpy:11
translate mandarin chapter_3_93d3af88:

    # "The grand lobby of International Heroes HQ buzzes with acitivity. Buntings hang overhead, congratulatory banners stretch across the walls, and a faint chorus of laughter and chatter echoes through the halls."
    "國際英雄總部豪華的大廳充滿生氣：天花板高掛著彩旗，牆上貼著滿滿的祝賀橫幅，走廊中迴盪著笑聲與談話聲，洋溢著歡樂氣氛。"

# game/chapter3.rpy:12
translate mandarin chapter_3_7e8a587c:

    # "Two years. Somehow, it's already been two years since all eleven of you became heroes."
    "兩年了。不知不覺，你們十一人已經成為英雄兩年了。"

# game/chapter3.rpy:15
translate mandarin chapter_3_17c17832:

    # wilson_char "Wow, it's been a while since we last came here. They've upgraded so many facilities."
    wilson_char "哇，我們真的好久沒來了。這裡好多設施都翻新了。"

# game/chapter3.rpy:16
translate mandarin chapter_3_0253491a:

    # wilson_char "Celebrating our two-year mark here feels kinda perfect, huh?"
    wilson_char "在這裡慶祝我們的二週年紀念感覺挺不錯的，對吧？"

# game/chapter3.rpy:20
translate mandarin chapter_3_d579ea62:

    # zali_char "Definitely! I miss Japan. Wait—where is Vanta?"
    zali_char "當然！我很想念日本。等等——Vanta 呢？"

# game/chapter3.rpy:21
translate mandarin chapter_3_edd3de8c:

    # "Zali glances around and calls down the hallway."
    "Zali 四處張望並朝著走廊呼喚。"

# game/chapter3.rpy:23
translate mandarin chapter_3_b91f0ef7:

    # zali_char "Van~~ta~~ Are you coming with us?"
    zali_char "Van～～ta～～你有要一起來嗎？"

# game/chapter3.rpy:27
translate mandarin chapter_3_c021274f:

    # "A loud bang echoes from down the hall."
    "走廊傳來一陣巨響。"

# game/chapter3.rpy:32
translate mandarin chapter_3_de678d72:

    # vanta_char "Yes! I am coming!"
    vanta_char "要！我要去了！"

# game/chapter3.rpy:33
translate mandarin chapter_3_86d439b2:

    # vanta_char "Shi—I mean, I'll be there in just a second."
    vanta_char "靠——我是說，我會馬上過去。"

# game/chapter3.rpy:34
translate mandarin chapter_3_6d4edd11:

    # "You jog toward Zali and Wilson."
    "你跑向 Zali 和 Wilson。"

# game/chapter3.rpy:36
translate mandarin chapter_3_2ab19e79:

    # vanta_char "Sorry guys! Phew, that was close. I was just grabbing my bag, then Usami showed up and—well, we ended up arm wrestling."
    vanta_char "抱歉，大家！呼，差點就贏了。我剛在拿包包，然後 Usami 出現了，所以——嗯，我們就開始\n比腕力了。"

# game/chapter3.rpy:37
translate mandarin chapter_3_e9e56453:

    # wilson_char "That bang was you and Usami?"
    wilson_char "那個巨響是你跟 Usami 發出來的？"

# game/chapter3.rpy:38
translate mandarin chapter_3_e2152249:

    # vanta_char "Yeah! We kind of...cracked the table in half, haha. No winner, but hey—we ball. We will rematch someday."
    vanta_char "對啊！我們……差不多把桌子壓裂成一半了。我們沒有分出勝負，但嘿——總有一天會再比一次的。"

# game/chapter3.rpy:46
translate mandarin chapter_3_15a213bf:

    # rai_char "{size=40}Yu!{/size} Ah! There you are—I thought you'd already left!"
    rai_char "{size=40}Yu！{/size} 啊！你在這——！我還以為你已經走了！"

# game/chapter3.rpy:50
translate mandarin chapter_3_31a1201e:

    # wilson_char "Rai! I am still here. What's up?"
    wilson_char "Rai！我還在啊，怎麼了？"

# game/chapter3.rpy:51
translate mandarin chapter_3_f5dcb5b7:

    # rai_char "Just wanted to give you guys these~"
    rai_char "只是想給你們這個～"

# game/chapter3.rpy:52
translate mandarin chapter_3_1aa190d7:

    # "Rai hands over three elegant-looking envelopes."
    "Rai 把三個精美的信封遞給你們。"

# game/chapter3.rpy:53
translate mandarin chapter_3_de9d38f5:

    # wilson_char "Wait... Onsen passes? Really? Hazukashi... That's so kind of you, Chu!"
    wilson_char "等等……溫泉券？真的嗎？好害羞……你人真好！啾！"

# game/chapter3.rpy:57
translate mandarin chapter_3_9bf2663e:

    # vanta_char "On god on god? For real for real?"
    vanta_char "尊嘟假嘟？"

# game/chapter3.rpy:58
translate mandarin chapter_3_cba1b453:

    # rai_char "Krisis has really put in the work this year. After everything that went down in Canada and France—that was crazy!"
    rai_char "Krisis 今年真的很努力呢。尤其是在加拿大跟法國的事件之後——那真的太瘋狂了！"

# game/chapter3.rpy:60
translate mandarin chapter_3_e4219a33:

    # rai_char "Before tonight's celebration, take a breather, go relax. This place has a great reputation. Trust me!"
    rai_char "在今晚的慶祝活動之前好好放鬆一下吧，相信我，這地方的評價很好的。"

# game/chapter3.rpy:61
translate mandarin chapter_3_36820381:

    # rai_char "Enjoy yourselves! I'll see Yu later at the party!"
    rai_char "好好享受吧！晚點派對上見，Yu！"

# game/chapter3.rpy:64
translate mandarin chapter_3_38315fec:

    # vandz_char "Woah! Thank you so much Rai!"
    vandz_char "哇！太感謝你了，Rai！"

# game/chapter3.rpy:71
translate mandarin chapter_3_fd2d6213:

    # "You arrive at the onsen ryokan. The building stands quietly against a backdrop of gentle hills and swaying trees, its wooden beams and tiled roof exuding a timeless charm.\nA warm scent of cedar and minerals fills the air, welcoming you in."
    "你們抵達了溫泉旅館。這棟建築靜靜佇立在山丘與搖曳樹影間，木製樑柱與斜屋頂散發著不朽的古樸魅力。空氣中飄著淡淡的雪松與礦物香氣，溫柔迎接著你們的到來。"

# game/chapter3.rpy:72
translate mandarin chapter_3_9ad10120:

    # "Slipping off your shoes at the entrance, you're guided down polished tatami-lined hallways by a cheerful staff member. The air inside is calm and still—the only sounds are the trickle of water and the occasional distant splash."
    "你們在入口處脫下鞋子，一位熱情的工作人員帶領你們走過典雅的榻榻米走廊。館內靜謐祥和，只有潺潺水聲與偶爾的水花聲在空氣中迴盪。"

# game/chapter3.rpy:76
translate mandarin chapter_3_ae222b4d:

    # "Soon, you reach the changing room. Neatly arranged baskets, folded towels, and little wooden stools await. Steam curls from behind the curtains leading to the baths."
    "很快，你們來到了更衣室：排列整齊的籃子、折好的毛巾，還有小小的木凳在裡面等著你們，蒸氣在通往浴室的門簾後方盤旋著。"

# game/chapter3.rpy:79
translate mandarin chapter_3_0bc3acad:

    # vanta_char "Man, Rai was so nice giving us those onsen passes. Wilson... Just saying, Rai really likes you."
    vanta_char "天啊，Rai 人真的好好，居然給我們這些溫泉券。Wilson......我只是說說，但 Rai 真的很喜歡你呢。"

# game/chapter3.rpy:83
translate mandarin chapter_3_a942a0c8:

    # wilson_char "I know! I really like Rai, too! For real. I could use some goooood cracking down my spine."
    wilson_char "對啊！我也很喜歡Rai！說真的，我的脊椎可以發出一些超——讚的喀喀聲。"

# game/chapter3.rpy:85
translate mandarin chapter_3_06319f41:

    # "Wilson stretches dramatically—several joints cracking like nobody's business."
    "Wilson 旁若無人地伸展——他的關節大聲地喀喀作響。"

# game/chapter3.rpy:86
translate mandarin chapter_3_cf5fe4d5:

    # vanta_char "Sheesh, Wilson. You sound like a microwave full of popcorn."
    vanta_char "Sheesh，笑死，Wilson，你聽起來很像在爆米香誒。"

# game/chapter3.rpy:90
translate mandarin chapter_3_349c5c62:

    # zali_char "You want me to give you a massage after this, Wilson?"
    zali_char "Wilson，晚點想要我幫你按摩嗎？"

# game/chapter3.rpy:91
translate mandarin chapter_3_91edb3f6:

    # wilson_char "YES! Zali, I know you always have my back, literally. Hehe, did you get it?"
    wilson_char "我要！Zali，我就知道你一直都在背後支持我，字面意思。嘿嘿，聽得懂嗎？"

# game/chapter3.rpy:95
translate mandarin chapter_3_e5f9bdd2:

    # vanta_char "{size=45}Gay~~~{/size}"
    vanta_char "{size=45}Gay～～～{/size}"

# game/chapter3.rpy:103
translate mandarin chapter_3_678ce885:

    # "You step into the changing room and start undressing. Zali is already ahead of you, wrapping his towel with effortless grace. Wilson hums as he follows suit, loosely tying his towel around his waist."
    "你們踏進更衣室後開始脫衣。Zali 早已站在你們面前，輕鬆優雅地將毛巾圍好。Wilson 則哼著歌，把毛巾隨意地綁在腰上。"

# game/chapter3.rpy:104
translate mandarin chapter_3_5a47de19:

    # "Then...you stare at your towel."
    "然後……你盯著你的毛巾。"

# game/chapter3.rpy:108
translate mandarin chapter_3_68c6b9bd:

    # "You pick it up. Hold it out. Turn it around. Shake it once, shake it again, just in case it magically decides to get bigger."
    "你拿起毛巾，展開它，轉到另一面，接著甩一甩，好像它會神奇地突然變大一樣。"

# game/chapter3.rpy:109
translate mandarin chapter_3_a42cd0d0:

    # vanta_char "Uhh. Is it just me, or is this towel criminally small?"
    vanta_char "呃，是我的問題，還是這條毛巾真的小得犯規？"

# game/chapter3.rpy:110
translate mandarin chapter_3_307180bf:

    # zali_char "Haha! No way it's that bad. Turn around, let's see..."
    zali_char "哈哈！不會那麼糟啦。轉過去，讓我看看……"

# game/chapter3.rpy:115
translate mandarin chapter_3_be923412:

    # "You turn around, revealing that the towel barely covers your behind—just one wrong move away from full exposure."
    "你轉過身，露出幾乎遮不到後方的毛巾——只要動作太大，你就會整個走光。"

# game/chapter3.rpy:116
translate mandarin chapter_3_8a2ed35d:

    # vanta_char "Bro, I think my cake is too big. My ass is just out."
    vanta_char "老兄，我覺得我屁股太巨了，它直接這樣露在外面耶。"

# game/chapter3.rpy:117
translate mandarin chapter_3_bbf6f483:

    # zali_char "You can take another towel, you know. One for the front, one for the back."
    zali_char "你可以再拿一條毛巾，前後各圍一條。"

# game/chapter3.rpy:118
translate mandarin chapter_3_8a919686:

    # wilson_char "Or just rub it in. Ball it out. Own it like the king you are. Let the cheeks speak, Vaddy."
    wilson_char "不要遮遮掩掩，大膽露出吧。讓所有人知道誰才是老大，Vaddy。"

# game/chapter3.rpy:119
translate mandarin chapter_3_e91e1fb3:

    # vanta_char "I'm telling you, they've gyatt to be more considerate of people with fat cheeks like mine."
    vanta_char "我跟你說，他們真的要多多照顧我們這種有肥屁股的人。"

# game/chapter3.rpy:120
translate mandarin chapter_3_c97dbd07:

    # "There's a beat of silence before all of you burst into laughter."
    "聞言，你們沉默了一秒，隨後哄堂大笑。"

# game/chapter3.rpy:121
translate mandarin chapter_3_1df8d6c0:

    # zali_char "Goodness, Vanta. Here—there's another towel if you wanna use it."
    zali_char "天啊，Vanta。如果你想要的話，這裡還有一條毛巾。"

# game/chapter3.rpy:128
translate mandarin chapter_3_d87f1c01:

    # "The three of you finally settle into the bath, easing into the steaming water with a collective sigh. Muscles relax, tension melts, and for a while, there's nothing but the\nquiet ripple of water and the occasional swirl of steam."
    "你們三人終於進到了浴池，在浸泡泉水的同時嘆出一口氣。你們的肌肉放鬆下來，紓解體內的壓力。此刻除了水面的微微漣漪與蒸氣的輕輕翻騰，一切都靜了下來。"

# game/chapter3.rpy:129
translate mandarin chapter_3_94c103f7:

    # "Time seems to blur in the warmth. You lean back, half-dozing, half-listening to Wilson yap something about konbini snacks."
    "在溫暖的氛圍裡，時間好像變得模糊不清。你向後仰，半夢半醒地聽著 Wilson 滔滔不絕分享著超商的零食。"

# game/chapter3.rpy:132
translate mandarin chapter_3_2153cd2c:

    # "Eventually, the three of you start to rise from the bath, wrapping yourselves in towels once more. But as you head toward the changing room—"
    "最後，你們三人從溫泉裡起身，再次拿毛巾圍住身體。但正當你們走向更衣室時——"

# game/chapter3.rpy:135
translate mandarin chapter_3_5f2ee044:

    # zali_char "... Wait. Where are my glasses?"
    zali_char "……等等，我的眼鏡呢？"

# game/chapter3.rpy:136
translate mandarin chapter_3_c391290e:

    # wilson_char "Huh? Mine are gone too! I am sure that I left them sitting right on my shirt..."
    wilson_char "蛤？我的也不見了！我很確定我把它放在我的衣服上了……"

# game/chapter3.rpy:137
translate mandarin chapter_3_028b12c1:

    # "You check the shelf where you left yours. Empty. All three pairs—vanished."
    "你查看了你放眼鏡的架子，上面空空如也——三副眼鏡都已消失無蹤。"

# game/chapter3.rpy:138
translate mandarin chapter_3_2fc69528:

    # "After searching every corner and finding absolutely nothing, you decide to head back to your room. Maybe someone picked up your glasses by mistake?"
    "你們搜尋了每個角落，卻什麼也沒找到，於是你們決定回房間。有沒有可能有人不小心拿到了你們的眼鏡？"

# game/chapter3.rpy:143
translate mandarin chapter_3_a526f740:

    # "But the moment you slide open the door to your room—"
    "但就在你拉開房門那刻——"

# game/chapter3.rpy:144
translate mandarin chapter_3_fc82411e:

    # "Three neatly folded kimono sit waiting on your bed. On top, a card catches your eye."
    "你看見床上有三件折得整整齊齊的浴衣，上面的卡片吸引了你的視線。"

# game/chapter3.rpy:147
translate mandarin chapter_3_5a10adde:

    # zali_char "Wow, these are gorgeous... Who left these here? Oh? It's Rai. Wilson, this must be for you."
    zali_char "哇，這太美了……是誰把這些東西留在這裡的？哦？原來是 Rai。Wilson，這一定是給你的。"

# game/chapter3.rpy:152
translate mandarin chapter_3_6f8ab4d8:

    # wilson_char "\"Dear Yu. My heart beat is 240 bpm...this is just a small gift from me, I mean, from all of us.\nI hope you'll wear it to the party tonight. There's also another surprise hidden nearby...\nYou know what this means, don't you? Inami Rai, chu!\""
    wilson_char "「親愛的 Yu，我的心跳是每分鐘 240 下……這只是我的小小心意，我是說，我們的心意。希望今晚你可以穿這件參加派對。這附近還藏著另一個驚喜......你知道這是什麼意思吧？\nInami Rai 上，啾！」"

# game/chapter3.rpy:154
translate mandarin chapter_3_17e1dec4:

    # wilson_char "Wait... I don't know what this means! Another gift? Another surprise?"
    wilson_char "等等......我不知道這是什麼意思！另一個禮物？另一個驚喜？"

# game/chapter3.rpy:156
translate mandarin chapter_3_c64e7e00:

    # vanta_char "Honestly, I wouldn't be surprised if Rai just jumps out of nowhere—"
    vanta_char "說實話，就算 Rai 現在突然跳出來我也不會驚訝——"

# game/chapter3.rpy:165
translate mandarin chapter_3_bf1b4ac0:

    # "Suddenly—BANG BANG BANG. Someone's knocking like they're trying to break the door down. You barely exchange glances before heading over."
    "突然之間——嘣嘣嘣！有人在敲門，敲到門快壞了。你們幾乎來不及對視就急忙向門走去。"

# game/chapter3.rpy:173
translate mandarin chapter_3_eac70c04:

    # "As you open the door, you spot someone familiar. It is none other than—"
    "你一打開門就看見熟悉的身影。那個人正是——"

# game/chapter3.rpy:178
translate mandarin chapter_3_1de395a4:

    # wilson_char "Rai? You're here? How—"
    wilson_char "Rai？你在這？為什——"

# game/chapter3.rpy:183
translate mandarin chapter_3_b082cd06:

    # "Rai freezes mid-step at the sound of Wilson's voice. Then, he bolts."
    "Rai 在聽見 Wilson 的聲音後愣了一下，隨後一言不發地跑走了。"

# game/chapter3.rpy:190
translate mandarin chapter_3_8493d71e:

    # wilson_char "Wait! Why are you running away? I am Yu!!!"
    wilson_char "等等！為什麼你要跑？我是 Yu 啊！"

# game/chapter3.rpy:191
translate mandarin chapter_3_64d8185c:

    # vanta_char "What in the world...?"
    vanta_char "到底是怎樣……？"

# game/chapter3.rpy:192
translate mandarin chapter_3_fb724cb6:

    # zali_char "Did he just—run? Also, am I crazy, or was he holding our glasses?"
    zali_char "所以他就這樣跑了嗎？還有，是我看錯了，還是他真的拿著我們的眼鏡？"

# game/chapter3.rpy:193
translate mandarin chapter_3_e7d9b3e8:

    # wilson_char "No...no way! Rai would never run from me! We're going after him."
    wilson_char "不……不可能！Rai 才不會躲我！我們去追他。"

# game/chapter3.rpy:199
translate mandarin chapter_3_bdfd0d07:

    # "Krisis takes off down the hallway in pursuit."
    "Krisis 沿著走廊追了出去。"

# game/chapter3.rpy:202
translate mandarin chapter_3_a834286d:

    # "Unbeknownst to you, back in your room, a pair of purple-pink eyes watches silently from behind the closet door. The owner of said eyes narrows them, lying in wait for the perfect moment to jump out."
    "你們不知道的是，就在緊閉的門後，一雙粉紫色的眼睛虎視眈眈。那人瞇起雙眼，等待最佳時機後\n跳出來。"

# game/chapter3.rpy:203
translate mandarin chapter_3_fcc82b20:

    # "... That moment never comes."
    "……結果那時機根本沒有到來。"

# game/chapter3.rpy:205
translate mandarin chapter_3_867723b0:

    # "The second you storm out of the room, the closet creaks open."
    "在你們衝出房間那瞬間，背後就傳來衣櫃打開的聲響。"

# game/chapter3.rpy:208
translate mandarin chapter_3_bc99d86d:

    # rai_char "Huh?! What just happened? I was gonna surprise Yu! I even practiced my big entrance!"
    rai_char "蛤？發生什麼事了？！我本來要嚇 Yu 的！我甚至演練了我的盛大進場誒！"

# game/chapter3.rpy:212
translate mandarin chapter_3_04e6c932:

    # "The three of you sprint after Rai, racing down the hallway. But as you round the corner into the changing room corridor—"
    "你們三人追在 Rai 身後，穿過了走廊。但就在你們繞進更衣室的走廊時——"

# game/chapter3.rpy:213
translate mandarin chapter_3_158413e6:

    # "Bamboo baskets. Everywhere."
    "到處都是木桶。"

# game/chapter3.rpy:214
translate mandarin chapter_3_1a3ec900:

    # "Rai, with suspicious agility, bounds straight through without disturbing a single one."
    "Rai 過分靈巧地越過它們，完全沒碰到任何一個桶子。"

# game/chapter3.rpy:219
translate mandarin chapter_3_qte_baskets_25dbf849:

    # vanta_char "God dammit! Who put these here?! We need to get rid of them!"
    vanta_char "可惡！誰把這些放在這裡的？！我們要把這些移走！"

# game/chapter3.rpy:262
translate mandarin chapter_3_qte_baskets_timeout_a76d81e8:

    # wilson_char "Jesus Christ! AHHH!!"
    wilson_char "我的老天鵝啊啊啊啊！！"

# game/chapter3.rpy:263
translate mandarin chapter_3_qte_baskets_timeout_3ba8be4f:

    # zali_char "Oops! My foot, gosh!"
    zali_char "哦！我的腳，哎呀！"

# game/chapter3.rpy:264
translate mandarin chapter_3_qte_baskets_timeout_74a69f46:

    # vanta_char "I swear, there weren't this many baskets earlier..."
    vanta_char "我發誓，這裡原本才沒有這麼多木桶……"

# game/chapter3.rpy:265
translate mandarin chapter_3_qte_baskets_timeout_8ef70eb7:

    # "You try to move through the baskets with grace...but that's not happening. Wilson bumps into one and stumbles. Zali gets his foot caught in a handle. You trip slightly, sending one flying through the air."
    "你嘗試優雅地越過木桶……但失敗了。Wilson 撞到一個木桶後被絆倒，Zali 的腳卡住了。你絆了一下，讓木桶飛了起來。"

# game/chapter3.rpy:266
translate mandarin chapter_3_qte_baskets_timeout_b6c7a240:

    # "You quickly regain your composure, dust yourself off, and start laughing."
    "你很快就恢復冷靜，回歸作戰姿態，並笑了出來。"

# game/chapter3.rpy:277
translate mandarin chapter_3_qte_baskets_clear_5bab054d:

    # "One by one, you three scoop up the baskets and toss them behind you. Zali catches one mid-air. Wilson spins one dramatically. You—you just stack them neatly."
    "你們一個接一個撿起木桶後丟到一旁。Zali 接住丟到空中的木桶，Wilson 則誇張地轉動那個木桶，而你——你就只是把它們整齊地疊起來而已。"

# game/chapter3.rpy:282
translate mandarin chapter_3_qte_baskets_clear_c4fc1aba:

    # zali_char "Phew! Nice and easy!"
    zali_char "呼！輕而易舉！"

# game/chapter3.rpy:283
translate mandarin chapter_3_qte_baskets_clear_cbf6a604:

    # wilson_char "Great teamwork, guys!"
    wilson_char "我們真有默契！"

# game/chapter3.rpy:284
translate mandarin chapter_3_qte_baskets_clear_a1d42206:

    # vanta_char "Alright. We up!"
    vanta_char "太讚了，走吧！"

# game/chapter3.rpy:288
translate mandarin chapter_3_1_04a9ee3a:

    # "Then, something shiny catches your eye. It's Zali's glasses—laying peacefully on a shelf, near the edge of the corridor."
    "爾後，有個亮晶晶的東西吸引了你的視線——是 Zali 的眼鏡。它安靜地躺在靠近走廊邊緣的架子上。"

# game/chapter3.rpy:289
translate mandarin chapter_3_1_c36c6176:

    # zali_char "Oh! my glasses! They're just...here?"
    zali_char "哦！我的眼鏡！它一直在……這裡嗎？"

# game/chapter3.rpy:292
translate mandarin chapter_3_1_237af8e5:

    # "Zali picks his glasses up and puts them on."
    "Zali 撿起眼鏡後戴上。"

# game/chapter3.rpy:294
translate mandarin chapter_3_1_5ab4a996:

    # wilson_char "Ahhhh~~ Which way did Rai go? That way?"
    wilson_char "啊啊～～Rai 往哪跑了？那裡嗎？"

# game/chapter3.rpy:296
translate mandarin chapter_3_1_ea0c4340:

    # vanta_char "I think he went down that direction, no?"
    vanta_char "我覺得是那個方向，不是嗎？"

# game/chapter3.rpy:303
translate mandarin chapter_3_1_bebb818f:

    # "You swing around the corner—and there he is. Rai, standing in the middle of the hallway."
    "就在你跑到角落時，你發現 Rai 站在走廊正中央。"

# game/chapter3.rpy:308
translate mandarin chapter_3_1_25c377fb:

    # zali_char "Look! It's Rai!"
    zali_char "你們看！Rai 在那裡！"

# game/chapter3.rpy:309
translate mandarin chapter_3_1_a14cb4bf:

    # wilson_char "Rai! It's me! Is everything okay? You look..."
    wilson_char "Rai！是我！你還好嗎？你看起來……"

# game/chapter3.rpy:314
translate mandarin chapter_3_1_66e3fef1:

    # "Wilson jogs forward. Rai lets out a squeak, spins on his heel, and dashes into the kitchen."
    "Wilson 奔跑上前，Rai 尖叫一聲，隨即轉過身衝進廚房。"

# game/chapter3.rpy:322
translate mandarin chapter_3_1_0bd5a16a:

    # wilson_char "Why are you running away from me? Rai? Rai!"
    wilson_char "你為什麼一直在躲我？Rai？Rai！"

# game/chapter3.rpy:323
translate mandarin chapter_3_1_9e4e8fb8:

    # zali_char "Wait, guys! Be careful. There are people working in the kitchen, we can't make a mess!"
    zali_char "大家等等！小心點。廚房裡有人在工作，我們不能搗亂！"

# game/chapter3.rpy:324
translate mandarin chapter_3_1_3d84e7b8:

    # wilson_char "Then we'll just have to be giga-careful! Come on, let's go!"
    wilson_char "那我們一定要超——級小心才行！來吧，我們走！"

# game/chapter3.rpy:325
translate mandarin chapter_3_1_052307e2:

    # zali_char "Wilson, wait—"
    zali_char "Wilson，等等——"

# game/chapter3.rpy:330
translate mandarin chapter_3_1_24dec637:

    # "Wilson takes off into the kitchen. Zali runs after him, leaving you groaning."
    "Wilson 跑進廚房，Zali 緊隨其後，留你在原地哀嚎。"

# game/chapter3.rpy:334
translate mandarin chapter_3_1_daa64f9f:

    # vanta_char "Ngh~~ The kitchen again? Alright, I am coming..."
    vanta_char "嗯～～為什麼總是在廚房呢？好，我要去了……"

# game/chapter3.rpy:335
translate mandarin chapter_3_1_d4d50370:

    # "That's what he said."
    "那是他說的。"

# game/chapter3.rpy:340
translate mandarin chapter_3_1_989e006f:

    # "You reluctantly burst into the kitchen. Wilson is already hopping over counters like he's parkouring through a block game."
    "你心不甘情不願地衝進廚房，而 Wilson 已經跳上了檯子，好似在方塊遊戲裡跑酷一樣。"

# game/chapter3.rpy:342
translate mandarin chapter_3_1_5c092916:

    # "The kitchen staff startle, dodging out of the way. Pots clatter. Something flies—"
    "廚房人員嚇了一跳，紛紛躲到一旁。鍋子發出碰撞聲，同時有東西飛了起來——"

# game/chapter3.rpy:345
translate mandarin chapter_3_1_ea541ae3:

    # "An egg whisk flies through the air, heading straight for a chef."
    "一支打蛋器直直朝向主廚飛去。"

# game/chapter3.rpy:347
translate mandarin chapter_3_1_0f6eea5d:

    # vanta_char "{size=40}Oh my god!! Wilson!{/size}"
    vanta_char "{size=40}我的天啊！！Wilson！{/size}"

# game/chapter3.rpy:348
translate mandarin chapter_3_1_22f26585:

    # wilson_char "{size=40}Ah! Gomenyasai!{/size}"
    wilson_char "{size=40}啊！非常喵歉！{/size}"

# game/chapter3.rpy:350
translate mandarin chapter_3_1_1719b6ed:

    # zali_char "{size=40}Wilson! Behind you!{/size}"
    zali_char "{size=40}Wilson！注意後面！{/size}"

# game/chapter3.rpy:353
translate mandarin chapter_3_1_47b9fd69:

    # "Wilson turns around, and—"
    "Wilson 轉過身，然後——"

# game/chapter3.rpy:377
translate mandarin chapter_3_qte_1_timeout_f383f3cc:

    # "Wilson fumbles the catch. The whisk sails past his head and smacks a chef right in the face."
    "Wilson 沒抓緊，導致打蛋器從他手中溜走，正中主廚的臉。"

# game/chapter3.rpy:378
translate mandarin chapter_3_qte_1_timeout_dd658eff:

    # wilson_char "{size=40}Sowwy!{/size}"
    wilson_char "{size=40}抱券！{/size}"

# game/chapter3.rpy:389
translate mandarin chapter_3_qte_1_clear_1b044c4c:

    # "Wilson catches the whisk just in time and tosses it cleanly into a nearby sink."
    "Wilson 及時抓住打蛋器，並俐落地將它扔進附近的水槽。"

# game/chapter3.rpy:390
translate mandarin chapter_3_qte_1_clear_8c19dcc7:

    # wilson_char "UGHAHH! That was way too close!"
    wilson_char "呃啊啊啊！真的就差一點點！"

# game/chapter3.rpy:397
translate mandarin chapter_3_2_d34b7234:

    # "Suddenly—BANG! A water tank hits the ground, flooding the floor. In the chaos, an octopus slips out."
    "突然之間——嘣！水缸掉到地上，淹沒了地面。混亂中，一隻章魚溜了出來。"

# game/chapter3.rpy:401
translate mandarin chapter_3_2_8098a18a:

    # vanta_char "What? Is that an octopus? Gosh golly gee willikers... You can't be serious..."
    vanta_char "什麼？那是章魚嗎？天公伯啊……你是在開玩笑吧……"

# game/chapter3.rpy:402
translate mandarin chapter_3_2_accaf6b6:

    # wilson_char "Well... Vanta, you fought a giant octopus before, right?"
    wilson_char "嗯……Vanta，你之前有跟一隻巨無霸章魚打架過，對吧？"

# game/chapter3.rpy:407
translate mandarin chapter_3_2_60f7dd67:

    # zali_char "{size=40}Don't worry! I got it!{/size}"
    zali_char "{size=40}別擔心！交給我吧！{/size}"

# game/chapter3.rpy:408
translate mandarin chapter_3_2_ac1947a9:

    # "Zali dashes toward the octopus, passing by a bucket. The capable hero leaps toward the octopus, moving to catch it with—"
    " Zali 衝向章魚，途中經過一旁的水桶。能幹的英雄跳向章魚。為了抓住牠，他決定使用——"

# game/chapter3.rpy:440
translate mandarin chapter_3_qte_2_clear_d39b6d8d:

    # "Zali grabs the bucket, swings it, and dunks it over the octopus. It shrieks, flailing inside, but Zali holds firm, flipping it back into the tank with expert precision."
    "Zali 抓住、揮動水桶，最後把它灌到章魚身上。章魚嚇了一跳，之後縮了進去。Zali 抓緊水桶，把章魚重新翻回水缸裡。"

# game/chapter3.rpy:443
translate mandarin chapter_3_qte_2_clear_e0a89837:

    # wilson_char "Is there anything you're not good at, Zali?"
    wilson_char "Zali，到底有什麼是你不擅長的？"

# game/chapter3.rpy:451
translate mandarin chapter_3_qte_2_wrong_a024a4c0:

    # "Zali dives forward and grabs for the octopus barehanded. It shrieks and slaps him in the face, slipping right through his fingers."
    "Zali 向前滑壘，並徒手抓住那隻章魚。他手裡受驚的章魚直接往他臉上來了一巴掌，並從指間\n溜走了。"

# game/chapter3.rpy:452
translate mandarin chapter_3_qte_2_wrong_fb93ee4e:

    # zali_char "Ugh!! It got away!"
    zali_char "呃！牠溜了！"

# game/chapter3.rpy:456
translate mandarin chapter_3_qte_2_wrong_6b48d607:

    # vanta_char "Damn... Backshots from an octopus? Couldn't be me."
    vanta_char "天……被章魚背刺？無法想像。"

# game/chapter3.rpy:463
translate mandarin chapter_3_3_41b2caba:

    # "Looking at Wilson, you eyes land on something on Wilson\'s head. It's wiggling."
    "你看向 Wilson，隨後視線落在他頭上，有個不明的東西在搖擺。"

# game/chapter3.rpy:464
translate mandarin chapter_3_3_d36a4f2e:

    # vanta_char "Uh... Wilson?"
    vanta_char "呃……Wilson？"

# game/chapter3.rpy:466
translate mandarin chapter_3_3_d1638504:

    # wilson_char "Yes, Vanta?"
    wilson_char "怎麼了，Vanta？"

# game/chapter3.rpy:468
translate mandarin chapter_3_3_d73755b8:

    # vanta_char "{size=40}Don't. Move.{/size}"
    vanta_char "{size=40}不要動。{/size}"

# game/chapter3.rpy:469
translate mandarin chapter_3_3_347fb051:

    # wilson_char "{size=40}What? What do you mean—don't—?!{/size}"
    wilson_char "{size=40}等等？什麼意思——不——？！{/size}"

# game/chapter3.rpy:472
translate mandarin chapter_3_3_cd57bd59:

    # "Wilson startles, stepping back. Right at that moment, the orange thing on his head twitches. It jumps—"
    "Wilson 嚇得倒退，而就在此刻，他頭上東西開始扭動。牠跳了一下——"

# game/chapter3.rpy:475
translate mandarin chapter_3_3_4d05cc19:

    # zali_char "{size=40}It's a crab! Vanta! Quick!{/size}"
    zali_char "{size=40}是螃蟹！Vanta！快點！{/size}"

# game/chapter3.rpy:476
translate mandarin chapter_3_3_c6cb4328:

    # "You leap forward, you can't let anything happen to your thang!"
    "你往前跳，絕不能讓牠攪局！"

# game/chapter3.rpy:499
translate mandarin chapter_3_qte_3_clear_e844ec92:

    # "You snatch the soaring crab! It wiggles aggressively."
    "你抓住一飛衝天的螃蟹！牠劇烈掙扎。"

# game/chapter3.rpy:500
translate mandarin chapter_3_qte_3_clear_8088c607:

    # "Before it can pinch you, you toss it over your shoulder. It lands in the tank without a splash."
    "在牠捏住你之前，你把牠拋到身後。牠不著痕跡地掉進水池。"

# game/chapter3.rpy:503
translate mandarin chapter_3_qte_3_clear_eb551119:

    # zali_char "Nice catch, Vanta!"
    zali_char "抓得好，Vanta！"

# game/chapter3.rpy:506
translate mandarin chapter_3_qte_3_clear_dd1c637a:

    # vanta_char "Heh. That's just the kinda guy I am."
    vanta_char "呵，不愧是我。"

# game/chapter3.rpy:522
translate mandarin chapter_3_qte_3_timeout_eb841974:

    # "You lunge for the crab and miss completely. It scuttles away with surprising speed, vanishing behind a stack of pans."
    "你衝向那隻螃蟹，結果直接撲空。牠以驚人的速度逃跑，消失在一疊平底鍋後方。"

# game/chapter3.rpy:524
translate mandarin chapter_3_qte_3_timeout_f233f96f:

    # wilson_char "You could almost say it was—"
    wilson_char "你幾乎可以說牠——"

# game/chapter3.rpy:526
translate mandarin chapter_3_qte_3_timeout_b3f5152a:

    # vanta_char "No."
    vanta_char "不要。"

# game/chapter3.rpy:528
translate mandarin chapter_3_qte_3_timeout_205bd9b8:

    # wilson_char "—Feeling crabby."
    wilson_char "對我們很不蟹。"

# game/chapter3.rpy:530
translate mandarin chapter_3_qte_3_timeout_a2529dd7:

    # vanta_char "That's it. You're done. Banned! Get out of here!"
    vanta_char "夠了，你完了，你被 ban 了！滾出去！"

# game/chapter3.rpy:539
translate mandarin chapter_3_4_267f82cb:

    # "As you catch your breath, your eyes land on something familiar on the kitchen counter."
    "在你喘過氣後，你的視線落在廚房櫃檯上某個眼熟的東西。"

# game/chapter3.rpy:540
translate mandarin chapter_3_4_f023d0eb:

    # vanta_char "My glasses? Huh! Mission accomplished, I guess."
    vanta_char "我的眼鏡？哈！任務完成，應該吧。"

# game/chapter3.rpy:543
translate mandarin chapter_3_4_44664fe9:

    # wilson_char "But where are my glasses? Also... Did Rai disappear again?"
    wilson_char "但我的眼鏡到底在哪？還有…… Rai 是不是又消失了？"

# game/chapter3.rpy:546
translate mandarin chapter_3_4_4205ed15:

    # "The three of you step out of the kitchen and look around. Just outside your room, something catches the light. You see a glint on the floor by the door."
    "你們三人踏出廚房並四處張望。就在你們的房門外，有東西吸引了你們的目光，有什麼東西正在\n門邊閃爍。"

# game/chapter3.rpy:548
translate mandarin chapter_3_4_97db28e6:

    # "You walk over. Wilson picks it up."
    "你們走過去，而 Wilson 把它撿了起來。"

# game/chapter3.rpy:552
translate mandarin chapter_3_4_f117be9c:

    # wilson_char "Oh! My glasses! They were here the whole time? I swear they weren't here when we left!"
    wilson_char "哦！我的眼鏡！結果它一直都在這裡嗎？我發誓剛剛我們離開房間的時候沒看到它……"

# game/chapter3.rpy:556
translate mandarin chapter_3_4_8b758ab2:

    # "You open the door to your room."
    "你打開房門。"

# game/chapter3.rpy:557
translate mandarin chapter_3_4_0fd37200:

    # "And freeze."
    "隨後愣在原地。"

# game/chapter3.rpy:560
translate mandarin chapter_3_4_aaa6ea1a:

    # "Rai is sitting on your bed, legs swinging, looking at you with a surprised expression."
    "Rai 正安靜地坐在你們床上，雙腿前後擺動，訝異地看向你們。"

# game/chapter3.rpy:564
translate mandarin chapter_3_4_d387e2dd:

    # rai_char "Yu! Krisis! Where have you been?! I was hiding in the room to surprise you, but before I could come out you all ran off!"
    rai_char "Yu！Krisis！你們到底去哪了？！我本來躲在房間裡想嚇你們，結果在我出來前你們就都跑走了！"

# game/chapter3.rpy:565
translate mandarin chapter_3_4_c48dac7f:

    # wilson_char "Rai? What do you mean? We've been chasing you all over this place!"
    wilson_char "Rai？什麼意思？我們剛剛一直到處追著你跑！"

# game/chapter3.rpy:568
translate mandarin chapter_3_4_b248862e:

    # zali_char "So you didn't take the glasses?"
    zali_char "所以你沒拿走眼鏡？"

# game/chapter3.rpy:569
translate mandarin chapter_3_4_d12d9d62:

    # rai_char "What glasses? I just brought the kimono for Yu, so we can match at the party later."
    rai_char "什麼眼鏡？我買了和服要送給你們，這樣我們等等就可以在派對上穿兄弟裝了。"

# game/chapter3.rpy:572
translate mandarin chapter_3_4_b7e7fe2d:

    # wilson_char "What? That makes no sence, so I wasn't chasing you?"
    wilson_char "什麼？沒道理啊，所以我在追的人不是你？"

# game/chapter3.rpy:575
translate mandarin chapter_3_4_0646e58b:

    # vanta_char "It was totally Rai! Who else could it be?!"
    vanta_char "那就是 Rai 啊！不然還會是誰？！"

# game/chapter3.rpy:576
translate mandarin chapter_3_4_012523be:

    # rai_char "No way..."
    rai_char "不可能吧……"

# game/chapter3.rpy:580
translate mandarin chapter_3_4_8c3c8b57:

    # rai_char "You didn't just run into the legendary tanuki of this inn, did you?"
    rai_char "你們該不會遇到旅館傳說中的狸貓了吧？"

# TODO: Translation updated at 2025-06-04 22:02

# game/chapter3.rpy:214
translate mandarin chapter_3_36082ae8:

    # "Wooden baskets. Everywhere."
    "到處都是木桶。"

# game/chapter3.rpy:307
translate mandarin chapter_3_qte_baskets_timeout_47283a85:

    # "You try to move through the baskets with grace...but that's not happening. Wilson bumps into one and stumbles. Zali gets his foot caught. You trip slightly, sending one flying through the air."
    "你嘗試優雅地越過木桶……但失敗了。Wilson 撞到一個木桶後被絆倒，Zali 的腳卡住了。你絆了一下，讓木桶飛了起來。"

translate mandarin strings:

    # game/chapter3.rpy:410
    old "Grab"
    new "抓住"

    # game/chapter3.rpy:468
    old "A Bucket"
    new "水桶"

    # game/chapter3.rpy:469
    old "His Hands"
    new "自己的手"

    # game/chapter3.rpy:532
    old "Catch it"
    new "抓住牠"

# game/chapter3.rpy:503
translate mandarin chapter_3_3_52a48e59:

    # "Looking at Wilson, you eyes land on something on Wilson's head. It's wiggling."
    "你看向 Wilson，隨後視線落在他頭上，有個不明的東西在搖擺。"# TODO: Translation updated at 2025-06-14 23:19

# game/chapter3.rpy:11
translate mandarin chapter_3_2f2fb403:

    # "The grand lobby of International Heroes HQ buzzes with activity. Buntings hang overhead, congratulatory banners stretch across the walls, and a faint chorus of laughter and chatter echoes through the halls."
    "國際英雄總部豪華的大廳充滿生氣：天花板高掛著彩旗，牆上貼著滿滿的祝賀橫幅，走廊中迴盪著笑聲與談話聲，洋溢著歡樂氣氛。"

# game/chapter3.rpy:20
translate mandarin chapter_3_b0fb729c:

    # zali_char "Definitely! I've missed Japan. Wait—where is Vanta?"
    zali_char "當然！我很想念日本。等等——Vanta 呢？"

# game/chapter3.rpy:617
translate mandarin chapter_3_4_141be9c9:

    # wilson_char "What? That makes no sense, so I wasn't chasing you?"
    wilson_char "什麼？沒道理啊，所以我在追的人不是你？"

# game/chapter3.rpy:625
translate mandarin chapter_3_4_9ceddfcf:

    # rai_char "I have heard rumors about a legendary tanuki in this ryokan."
    rai_char "我聽說過這個旅館有傳說中的狸貓。"

# game/chapter3.rpy:626
translate mandarin chapter_3_4_a8cefc1e:

    # rai_char "They say he used to play tricks on the guests, but that story's been around for ages...nothing's happened recently."
    rai_char "他有時候會對旅客惡作劇，不過這個傳說是很久以前傳下來的，最近都沒發生過了。"

# game/chapter3.rpy:629
translate mandarin chapter_3_4_326290e9:

    # rai_char "You didn't just run into him, did you? Haha!"
    rai_char "你們該不會遇到了吧？哈哈！"

# game/chapter3.rpy:632
translate mandarin chapter_3_4_e3ad48ca:

    # rai_char "Anyway, I'll leave these kimono with you. Don't forget to wear them to the party later!"
    rai_char "好了，這些衣服就交給你們了，記得換上。晚上的派對見喔！"

# game/chapter3.rpy:634
translate mandarin chapter_3_4_3f3ff9e9:

    # "You watch as Rai skips off cheerfully, leaving the room behind."
    "你們看著 Rai 踏著愉快的腳步離開……"

