# TODO: Translation updated at 2025-06-04 19:59

translate mandarin strings:

    # game/click_point.rpy:12
    old "Want to drive Wilson feral? \nTry a seductive half-snake enchantress. \nNo questions asked."
    new "如何將 Wilson 迷得神魂顛倒？\n美麗的半人蛇妖 Lamia 或許可以。"

    # game/click_point.rpy:12
    old "Limited edition. Freshly squeezed. \nThirsty? You know you want a taste."
    new "期間限定的新鮮現擠 Willy Milk！\n渴了嗎？想要來一杯嗎？"

    # game/click_point.rpy:12
    old "Wilson's signature crepes... \nor are they pancakes? \nEither way, they're delicious. Probably."
    new "Wilson 特製可麗餅，還是該稱之為鬆餅？\n不論是什麼，它都很好吃，大概吧。"

    # game/click_point.rpy:12
    old "Said to mark both the beginning \nand end of Calamitycrow. \nA legendary orange licorice ice cream in Canada, \nallegedly worth a two-hour detour."
    new "Calamitycrow 的開始與終點，一個傳說\n在加拿大值得開車兩小時去吃的橘子甘草冰淇淋，\n其真實美味無人能證實。"

    # game/click_point.rpy:12
    old "Willerton's pet żar-ptak. \nAlso known as KFC. \nHe's recently became a parent\n—totally unplanned."
    new "Willerton 擁有的火鳥，又稱 KFC，\n前陣子有了小孩（非飼主預期）。"

    # game/click_point.rpy:38
    old "Zali's favorite dessert. \nHomemade versions may spontaneously \nbecome...caramelized omelets."
    new "Zali 最愛的甜點。\n自製烤布蕾有機率燒焦或變成甜的烘蛋。"

    # game/click_point.rpy:38
    old "\"Delicious!\nEveryone loves blue cheese!\" —Zali"
    new "「好吃！人人都愛藍紋起司！」—— Zali。"

    # game/click_point.rpy:38
    old "Tasty, nutritious, and wildly popular! \nFor more details, consult \nmedical hero Vezalius Bandage.\nSide effects: unknown. \nUse with reckless confidence."
    new "好吃又營養的 Zalitamin 藥水現正熱賣中，\n更多商品資訊請洽醫療英雄 Vezalius Bandage。\n藥水副作用：不明。"

    # game/click_point.rpy:38
    old "Fluffy, sweet, and absolutely irresistible. \nFrench toast with American butter \nand Canadian maple syrup—heroic perfection."
    new "來一份香甜鬆軟的法式吐司，\n放上美國奶油，淋上加拿大楓糖漿，嗯～完美！"

    # game/click_point.rpy:38
    old "Rumored to be a navy-blue brief \ncovered in tiny flames.\nFor Krisis' eyes only."
    new "傳聞中佈滿小火焰圖案的深藍色內褲，\n僅供 Krisis 內部欣賞。"

    # game/click_point.rpy:63
    old "A new recipe Vanta discovered recently.\n Nothing tastes better than \nwhen it's shared with the homies."
    new "Vanta 最近找到的新食譜。\n跟 homie 共享三明治，美味加倍。"

    # game/click_point.rpy:63
    old "The first dragon Vantus ever tamed. \nBrave. Loyal. Unforgotten. \nHis spirit lives on in every dragon that followed."
    new "Vantus 馴服的第一隻龍。\n忠誠、勇敢、永誌不忘。\n牠的意志將由後繼的龍群延續下去。"

    # game/click_point.rpy:63
    old "The most beloved beverage among Krisis.\nLemon sour or lemon soda? \nJust serve it in a giga pitcher!"
    new "Krisis 在日本必點的飲料。\n究竟上桌的是檸檬沙瓦還是檸檬蘇打？\n不管了，呼乾啦！"

    # game/click_point.rpy:63
    old "A dish Vanta loves to cook. \nJapanese? American? Who knows anymore. \nClaude didn't ask. He just inhaled it."
    new "Vanta 喜歡做的日式......美式料理？\n其美好滋味讓 Claude 一掃而空。 "

    # game/click_point.rpy:63
    old "A trio of dog siblings from an enchanted town, \noften seen playing and goofing around together. \nTheir names feel eerily familiar..."
    new "某個小鎮的狗狗三兄弟，\n經常看到他們湊在一起玩耍、打鬧。\n名字有種似曾相識的感覺......"

# TODO: Translation updated at 2025-06-04 20:08

translate mandarin strings:

    # game/click_point.rpy:12
    old "Lamia?"
    new "Lamia?"

    # game/click_point.rpy:12
    old "Willy Milk"
    new "Willy Milk"

    # game/click_point.rpy:12
    old "Crêpes (or pancakes?"
    new "可麗鬆餅"

    # game/click_point.rpy:12
    old "Tiger Tail Ice Cream"
    new "橘子甘草冰淇淋"

    # game/click_point.rpy:12
    old "Krisis Fantastic Chicken"
    new "Krisis Fantastic Chicken"

    # game/click_point.rpy:38
    old "Crème Brûlée"
    new "烤布蕾"

    # game/click_point.rpy:38
    old "Blue Cheese"
    new "藍紋起司"

    # game/click_point.rpy:38
    old "Zalitamin"
    new "Zalitamin"

    # game/click_point.rpy:38
    old "French Toast"
    new "法式吐司"

    # game/click_point.rpy:38
    old "Flame Underwear"
    new "火焰內褲"

    # game/click_point.rpy:63
    old "Tamago Sando"
    new "雞蛋三明治"

    # game/click_point.rpy:63
    old "Josh"
    new "Josh"

    # game/click_point.rpy:63
    old "Lemon Sour"
    new "檸檬沙瓦"

    # game/click_point.rpy:63
    old "Sushi Bake"
    new "烤壽司"

    # game/click_point.rpy:63
    old "Vanvan, Yuyu, Banban"
    new "Vanvan、Yuyu、Banban"

# TODO: Translation updated at 2025-06-14 23:19

translate mandarin strings:

    # game/click_point.rpy:12
    old "Crêpes (or pancakes?)"
    new "可麗鬆餅"

