#side tab style
style inventory_tab is button:
    xminimum 250  
    yminimum 120
    background "gui/inventory/button/btn_side_default.png"
    selected_background "gui/inventory/button/btn_side_hover.png"
    hover_background "gui/inventory/button/btn_side_hover_0.png"
    xpos 0.12
    selected_xpos 0

style inventory_tab_text is button_text:
    font gui.name_text_font
    xalign 0.45
    yalign 0.5
    size 27
    line_spacing -2
    color "#453E6A"
    hover_color "#453E6A"
    selected_color '#473027'

transform hover_country(country_name):
    on idle:
        linear 0.25 ypos (0 if country_name != active_set else -0.225)
    on selected_idle:
        linear 0.25 ypos (0 if country_name != active_set else -0.225)
    on selected_hover:
        linear 0.25 ypos (0 if country_name != active_set else -0.225)

transform hover_tab(tab_name):
    on idle:
        linear 0.25 xpos (0.12 if tab_name != active_tab else 0)
    on selected_idle:
        linear 0.25 xpos (0.12 if tab_name != active_tab else 0)
    on selected_hover:
        linear 0.25 xpos (0.12 if tab_name != active_tab else 0)

transform gallery_zoomout:
    zoom 0.185

transform gallery_zoomout2:
    zoom 0.9
    rotate -2

transform image_tilt:
    rotate -1

transform video_tilt:
    rotate -1
    zoom 0.750

transform secretsnap_01:
    rotate 3.5
    zoom 0.35

transform secretsnap_02:
    rotate -2
    zoom 0.3

transform secretsnap_03:
    rotate 3
    zoom 0.280

transform secretsnap_04:
    rotate -3
    zoom 0.280

transform secretsnap_05:
    rotate 1
    zoom 0.290

transform photodiary_01:
    rotate -4
    zoom 0.250

transform photodiary_02:
    rotate 1
    zoom 0.250

transform photodiary_03:
    rotate -2
    zoom 0.250

transform gallery_lock:
    zoom 0.5

style sticker_title is text:
    font gui.name_text_font
    text_align 0.5

style sticker_description is text:
    size 25
    text_align 0.5

style page_description is text:
    size 25
    line_spacing -3

init python:
    def achievement_obtained(achievement_name,country,target_tab):
        achievement.grant(achievement_name)
        store.active_set = country
        store.active_tab = target_tab
        if "photodiary" in achievement_name:
            store.red_dot_shown = True
            renpy.play("audio/collected_item_ping.mp3",channel = "sound")

    def set_captured_true_for_image(i):
        if active_set == 'canada':
            persistent.ca_captured[i] = True
        elif active_set == 'france':
            persistent.fr_captured[i] = True
        else: #Japan
            persistent.jp_captured[i] = True

    def grant_achievement_for_image(i):
        if active_set == 'canada' and not persistent.ca_achievement_unlocked[i]:
            achievement_id = list(ca_achievements.keys())[i]
            achievement.grant(achievement_id)
            persistent.ca_achievement_unlocked[i] = True
            renpy.show_screen("ca_stickers_unlocked", achievement_id = achievement_id)
        elif active_set == 'france' and not persistent.fr_achievement_unlocked[i]:
            achievement_id = list(fr_achievements.keys())[i] 
            achievement.grant(achievement_id)
            persistent.fr_achievement_unlocked[i] = True
            renpy.show_screen("fr_stickers_unlocked", achievement_id=achievement_id)    
        else: #Japan
            achievement_id = list(jp_achievements.keys())[i] 
            achievement.grant(achievement_id)
            persistent.jp_achievement_unlocked[i] = True
            renpy.show_screen("jp_stickers_unlocked", achievement_id=achievement_id)    

#X-Y pos for images
define item_positions = {
    "sticker_ca_01": {"xpos": 670, "ypos": 175},  
    "sticker_ca_02": {"xpos": 341, "ypos": 267},      
    "sticker_ca_03": {"xpos": 440, "ypos": 177},
    "sticker_ca_04": {"xpos": 480, "ypos": 284}, 
    "sticker_ca_05": {"xpos": 748, "ypos": -155}, 
    "photodiary_ca_01": {"xpos": 60, "ypos": -60},
    "photodiary_ca_02": {"xpos": 275, "ypos": -85},
    "photodiary_ca_03": {"xpos": 85, "ypos": -85},
    "secretsnaps_ca_01":{"xpos":50,"ypos":45},
    "secretsnaps_ca_02":{"xpos":188,"ypos":-200},
    "secretsnaps_ca_03":{"xpos":257,"ypos":-100},
    "secretsnaps_ca_04":{"xpos":-353,"ypos":170},
    "secretsnaps_ca_05":{"xpos":417,"ypos":-190},

    "sticker_fr_01": {"xpos": 650, "ypos": 115},  
    "sticker_fr_02": {"xpos": 341, "ypos": 300},      
    "sticker_fr_03": {"xpos": 425, "ypos": 250},
    "sticker_fr_04": {"xpos": 675, "ypos": 100}, 
    "sticker_fr_05": {"xpos": 775, "ypos": 75}, 
    "photodiary_fr_01": {"xpos": 60, "ypos": -60},
    "photodiary_fr_02": {"xpos": 275, "ypos": -85},
    "photodiary_fr_03": {"xpos": 85, "ypos": -85},
    "secretsnaps_fr_01":{"xpos":50,"ypos":45},
    "secretsnaps_fr_02":{"xpos":188,"ypos":-200},
    "secretsnaps_fr_03":{"xpos":257,"ypos":-100},
    "secretsnaps_fr_04":{"xpos":-353,"ypos":170},
    "secretsnaps_fr_05":{"xpos":417,"ypos":-190},

    "sticker_jp_01": {"xpos": 420, "ypos": 190},  
    "sticker_jp_02": {"xpos": 600, "ypos": 230},      
    "sticker_jp_03": {"xpos": 700, "ypos": 150},
    "sticker_jp_04": {"xpos": 350, "ypos": 200}, 
    "sticker_jp_05": {"xpos": 660, "ypos": 75}, 
    "photodiary_jp_01": {"xpos": 60, "ypos": -60},
    "photodiary_jp_02": {"xpos": 275, "ypos": -85},
    "photodiary_jp_03": {"xpos": 85, "ypos": -85},
    "secretsnaps_jp_01":{"xpos":50,"ypos":45},
    "secretsnaps_jp_02":{"xpos":188,"ypos":-200},
    "secretsnaps_jp_03":{"xpos":257,"ypos":-100},
    "secretsnaps_jp_04":{"xpos":-353,"ypos":170},
    "secretsnaps_jp_05":{"xpos":417,"ypos":-190},
}

screen inventory_screen():
    tag menu
    modal True
    if main_menu:
        add "main_menu"
    elif persistent.endgame_popup == True:
        add "main_menu_2"
    add gui.inventory_background
    add "gui/inventory/bg_bookcover.png" xalign 0.5 yalign 0.8

    if active_set == 'canada':
        $ country_prefix = 'ca'
    elif active_set == 'france':
        $ country_prefix = 'fr'
    elif active_set == 'japan':
        $ country_prefix = 'jp'
    
    #set -> country, tab -> inventory types
    $ showItem = -1 # if click on the inventory, then reset the var "showItem"
   
    #Adds country tabs on top
    hbox:
        xpos 0.15
        ypos 0.065
        spacing 5

        imagebutton:
            idle "gui/inventory/button/btn_Canada_default.png"
            hover "gui/inventory/button/btn_Canada_hover.png"
            selected_idle "gui/inventory/button/btn_Canada_pressed.png"
            selected_hover "gui/inventory/button/btn_Canada_pressed.png"
            activate_sound "audio/sys_page.mp3"
            selected (active_set == "canada")
            action [SetVariable("active_set", "canada"), If(active_tab == "travelgallery_2",SetVariable("active_tab","travelgallery"),SetVariable("active_tab", active_tab))]
            at hover_country("canada")

        imagebutton:
            idle "gui/inventory/button/btn_France_default.png"
            hover "gui/inventory/button/btn_France_hover.png"
            selected_idle "gui/inventory/button/btn_France_pressed.png"
            selected_hover "gui/inventory/button/btn_France_pressed.png"
            activate_sound "audio/sys_page.mp3"
            selected (active_set == "france")
            action [SetVariable("active_set", "france"), If(active_tab == "travelgallery_2",SetVariable("active_tab","travelgallery"),SetVariable("active_tab", active_tab))]
            at hover_country("france")
        

        imagebutton:
            idle "gui/inventory/button/btn_Japanese_default.png"
            hover "gui/inventory/button/btn_Japanese_hover.png"
            selected_idle "gui/inventory/button/btn_Japanese_pressed.png"
            selected_hover "gui/inventory/button/btn_Japanese_pressed.png"
            activate_sound "audio/sys_page.mp3"
            selected (active_set == "japan")
            action [SetVariable("active_set", "japan"), If(active_tab == "travelgallery_2",SetVariable("active_tab","travelgallery"),SetVariable("active_tab", active_tab))]
            at hover_country("japan")

                   
    # Adds page base
    if active_tab == "secretsnaps":
        add "gui/inventory/bg_page_secretsnaps_locked.png":
            xalign 0.5
            yalign 0.65
        text _("No matter the time or place, heroes never stop. \nKrisis, Heroes of the Night—Touch Down!"):
            xpos 300
            ypos 200
            style "page_description"

    elif active_tab == "photodiary":
        if active_set == "canada":
            add "gui/inventory/bg_page_photodiary_ca.png":
                xalign 0.5
                yalign 0.65
        elif active_set == "france":
            add "gui/inventory/bg_page_photodiary_fr.png":
                xalign 0.5
                yalign 0.65
        else:
            add "gui/inventory/bg_page_photodiary_jp.png":
                xalign 0.5
                yalign 0.65
        text _("Click the photos on the left and find every hero!"):
            xpos 1015
            ypos 175
            style "page_description"

    elif active_tab == "travelgallery" or active_tab == "travelgallery_2":
        add "gui/inventory/bg_page_travelgallery.png":
            xalign 0.5
            yalign 0.65
        if active_set == "canada" and not(achievement.has("sticker_ca_01") and achievement.has("sticker_ca_02") and achievement.has("sticker_ca_03") and achievement.has("sticker_ca_04") and achievement.has("sticker_ca_05") and achievement.has("secretsnaps_ca_05")):
            text _("Find every hero in the Photo Diary and complete\nthe chapter to unlock the Travel Gallery!"):
                xpos 300
                ypos 200                
                style "page_description"
        elif active_set == "france" and not(achievement.has("sticker_fr_01") and achievement.has("sticker_fr_02") and achievement.has("sticker_fr_03") and achievement.has("sticker_fr_04") and achievement.has("sticker_fr_05") and achievement.has("secretsnaps_fr_05")):
            text _("Find every hero in the Photo Diary and complete\nthe chapter to unlock the Travel Gallery!"):
                xpos 300
                ypos 200
                style "page_description"
        elif active_set == "japan" and not(achievement.has("sticker_jp_01") and achievement.has("sticker_jp_02") and achievement.has("sticker_jp_03") and achievement.has("sticker_jp_04") and achievement.has("sticker_jp_05")and achievement.has("secretsnaps_jp_05")):
            text _("Find every hero in the Photo Diary and complete\nthe chapter to unlock the Travel Gallery!"):
                xpos 300
                ypos 200
                style "page_description"
        else:
            text _("A collection of shining moments, each one brought to \nlife by the brilliant creativity of the Vezcrewneers."):
                xpos 300
                ypos 200
                style "page_description"
    # Adds close button     
    frame:
        background Solid ('#00000000')
        xalign 0.9150
        yalign 0.175
        imagebutton idle "gui/inventory/button/btn_close.png" action If(persistent.endgame_popup == True,[SetVariable("persistent.endgame_popup",False),Hide('inventory_screen'),MainMenu(confirm=False)],Return())

    # Gallery tabs on side            
    vbox:
        spacing 20
        ypos 0.27
        xpos 0.01  
        textbutton _("Secret\nSnaps") action([SelectedIf(active_tab == "secretsnaps"),SetVariable("active_tab", "secretsnaps")]) activate_sound "audio/sys_page.mp3" style "inventory_tab" at hover_tab("secretsnaps")
        textbutton _("Photo\nDiary") action([SelectedIf(active_tab == "photodiary"),SetVariable("active_tab", "photodiary")]) activate_sound "audio/sys_page.mp3" style "inventory_tab" at hover_tab("photodiary")
        textbutton _("Travel\nGallery") action([SelectedIf("travelgallery" in active_tab),SetVariable("active_tab", "travelgallery")]) activate_sound "audio/sys_page.mp3" style "inventory_tab" at hover_tab("travelgallery")

    # Separate vbox for each set

    # Vbox per tab
    if active_tab == "photodiary":
        $ items_per_column = 3
        $ items_per_row = 3        

    elif active_tab == "secretsnaps":
        $ items_per_column = 3
        $ items_per_row = 3

    else: #Travel Gallery
        $ items_per_column = 4
        $ items_per_row = 3
    
    # Adds Images
    frame:
        xysize(1475,902)
        background Solid ("#00000000")
        xalign 0.5
        yalign 0.8

        if "travelgallery" in active_tab and active_set == "canada" and not(achievement.has("sticker_ca_01") and achievement.has("sticker_ca_02") and achievement.has("sticker_ca_03") and achievement.has("sticker_ca_04") and achievement.has("sticker_ca_05") and achievement.has("secretsnaps_ca_05")):
            add "gui/inventory/lock_large.png" xalign 0.5 yalign 0.5 at gallery_lock
        elif "travelgallery" in active_tab and active_set == "france" and not(achievement.has("sticker_fr_01") and achievement.has("sticker_fr_02") and achievement.has("sticker_fr_03") and achievement.has("sticker_fr_04") and achievement.has("sticker_fr_05")and achievement.has("secretsnaps_fr_05")):
            add "gui/inventory/lock_large.png" xalign 0.5 yalign 0.5 at gallery_lock
        elif "travelgallery" in active_tab and active_set == "japan" and not(achievement.has("sticker_jp_01") and achievement.has("sticker_jp_02") and achievement.has("sticker_jp_03") and achievement.has("sticker_jp_04") and achievement.has("sticker_jp_05")and achievement.has("secretsnaps_jp_05")):
            add "gui/inventory/lock_large.png" xalign 0.5 yalign 0.5 at gallery_lock
        else:
            vbox:
                if active_tab == "travelgallery" or active_tab == "travelgallery_2":
                    spacing 40
                    yoffset 100         
                $ items_count = len(inventory_images[active_set][active_tab])
                $ rows_count = (items_count - 1) // items_per_column + 1
                # Loop to create rows for items
                for row_index in range((items_count + items_per_column - 1) // items_per_column):
                    hbox:
                        if active_tab == "travelgallery" or active_tab == "travelgallery_2":
                            spacing 48
                        for column_index in range(items_per_column):  
                            $ item_index = row_index * items_per_column + column_index
                            if item_index < items_count:

                                $ image_dict = inventory_images[active_set][active_tab][item_index]
                                $ item_name = image_dict.get("name", f"item{item_index + 1}")

                                $ position = item_positions.get(item_name, {"xpos": 100, "ypos": 100})  # Default to (100, 100) if not found
                                $ xpos = position["xpos"]
                                $ ypos = position["ypos"]

                                $ item_background = get_item_background(active_set, active_tab, item_index)
                                #$ item_locked = get_item_locked(active_set, active_tab, item_index)
                                $ have_idle = "idle"
                                $ have_locked = "locked"
                                $ have_transform = "transform"
                                vbox:
                                    xpos xpos
                                    ypos ypos                                                                
                                    if achievement.has(item_name): #Checks if achievement is granted
                                        if item_name == "sticker_"+country_prefix+"_01":
                                            imagebutton idle image_dict[have_idle] action Show("sticker_popup", sticker_name = item_name, item_click_background=item_background)
                                        elif item_name == "sticker_"+country_prefix+"_02":
                                            imagebutton idle image_dict[have_idle] action Show("sticker_popup", sticker_name = item_name, item_click_background=item_background)
                                        elif item_name == "sticker_"+country_prefix+"_03":
                                            imagebutton idle image_dict[have_idle] action Show("sticker_popup", sticker_name = item_name, item_click_background=item_background)
                                        elif item_name == "sticker_"+country_prefix+"_04":
                                            imagebutton idle image_dict[have_idle] action Show("sticker_popup", sticker_name = item_name, item_click_background=item_background)
                                        elif item_name == "sticker_"+country_prefix+"_05":
                                            imagebutton idle image_dict[have_idle] action Show("sticker_popup", sticker_name = item_name, item_click_background=item_background)
                                        elif item_name == "photodiary_"+country_prefix+"_01":
                                            frame:
                                                xysize(420,275)
                                                background Solid('#00000000')
                                                imagebutton idle image_dict[have_idle] action Show("photodiary_popup", image_name=item_name) at image_dict[have_transform]
                                                if (active_set =="canada" and (not(achievement.has('sticker_ca_03')))) or (active_set == "france" and (not(achievement.has('sticker_fr_01') and achievement.has('sticker_fr_02')))) or (active_set =="japan" and (not(achievement.has('sticker_jp_01') and achievement.has('sticker_jp_02')))):
                                                    add "gui/inventory/frame_photo_icon.png" yalign 1.1 xalign 0.9
                                        elif item_name == "photodiary_"+country_prefix+"_02":
                                            frame:
                                                xysize(420,275)
                                                background Solid('#00000000')
                                                imagebutton idle image_dict[have_idle] action Show("photodiary_popup", image_name=item_name)  at image_dict[have_transform]
                                                if (active_set =="canada" and (not(achievement.has('sticker_ca_01') and achievement.has('sticker_ca_02')))) or (active_set == "france" and (not(achievement.has('sticker_fr_03') and achievement.has('sticker_fr_04')))) or (active_set == "japan" and (not(achievement.has('sticker_jp_03')))):
                                                    add "gui/inventory/frame_photo_icon.png" yalign 1.1 xalign 0.9          
                                        elif item_name == "photodiary_"+country_prefix+"_03":
                                            frame:
                                                xysize(420,275)
                                                background Solid('#00000000')
                                                imagebutton idle image_dict[have_idle] action Show("photodiary_popup", image_name=item_name) at image_dict[have_transform]
                                                if (active_set =="canada" and (not(achievement.has('sticker_ca_04') and achievement.has('sticker_ca_05')))) or (active_set == "france" and (not(achievement.has('sticker_fr_05'))))or (active_set =="japan" and (not(achievement.has('sticker_jp_04') and achievement.has('sticker_jp_05')))):
                                                    add "gui/inventory/frame_photo_icon.png" yalign 1.1 xalign 0.9                                        
                                        elif item_name == "secretsnaps_"+country_prefix+"_01":
                                            imagebutton idle image_dict[have_idle] action Show("secretsnaps_popup",image_name=item_name) at secretsnap_01
                                        elif item_name == "secretsnaps_"+country_prefix+"_02":
                                            imagebutton idle image_dict[have_idle] action Show("secretsnaps_popup",image_name=item_name) at secretsnap_02
                                        elif item_name == "secretsnaps_"+country_prefix+"_03": 
                                            imagebutton idle image_dict[have_idle] action Show("secretsnaps_popup",image_name=item_name) at secretsnap_03        
                                        elif item_name == "secretsnaps_"+country_prefix+"_04":     
                                            imagebutton idle image_dict[have_idle] action Show("secretsnaps_popup",image_name=item_name) at secretsnap_04                                   
                                        elif item_name == "secretsnaps_"+country_prefix+"_05":
                                            imagebutton idle image_dict[have_idle] action Show("secretsnaps_popup",image_name=item_name) at secretsnap_05
                                    elif active_tab == 'secretsnaps':
                                        add image_dict[have_locked] alpha 0.0 at image_dict[have_transform]
                                    elif active_tab == "travelgallery" or active_tab == "travelgallery_2":
                                        imagebutton idle image_dict[have_idle] action Show("gallery_popup",item_click_background=item_background,index=item_index) at gallery_zoomout
                                    elif active_tab == "photodiary" and "photodiary" in item_name:
                                        frame:
                                            xysize(420,275)
                                            background Solid('#00000000')
                                            add image_dict[have_locked] alpha 0.0 at image_dict[have_transform]
                                    else:
                                        add image_dict[have_locked]                                      
                    #hbox: 
                        #xysize (1300,5) 
            #Gallery nav arrows
            if "travelgallery" in active_tab:
                hbox:
                    yalign 0.95
                    xfill True
                    if active_tab == "travelgallery":
                        imagebutton idle "gui/inventory/button/btn_right.png" xalign 1.0 action [SetVariable("active_tab","travelgallery_2")] 
                    else:
                        imagebutton idle "gui/inventory/button/btn_left.png" xalign 0.0 action [SetVariable("active_tab","travelgallery")]

default selected_item = None

screen sticker_popup(sticker_name, item_click_background):
    modal True
    zorder 1000

    add "transparent2.png" xpos -0.1 ypos -0.8  # Background
    add "gui/inventory/frame_get_popup.png" xalign 0.5 yalign 0.5
    if active_set == 'canada':
        text ca_achievements.get(sticker_name)[3] xalign 0.5 yalign 0.2 style "sticker_title"
        text ca_achievements.get(sticker_name)[1] xalign 0.5 yalign 0.3 style "sticker_description"
    elif active_set == 'france':
        text fr_achievements.get(sticker_name)[3] xalign 0.5 yalign 0.2 style "sticker_title"
        text fr_achievements.get(sticker_name)[1] xalign 0.5 yalign 0.3 style "sticker_description"
    else: #Japan
        text jp_achievements.get(sticker_name)[3] xalign 0.5 yalign 0.2 style "sticker_title"
        text jp_achievements.get(sticker_name)[1] xalign 0.5 yalign 0.3 style "sticker_description"

    add item_click_background  xalign 0.5 yalign 0.6 yoffset 35   

    imagebutton:
        idle "gui/inventory/button/btn_close.png"
        xpos 0.68
        ypos 0.13
        action [
            Hide("sticker_popup"),
        ]     

screen secretsnaps_popup(image_name):
    modal True
    zorder 1000

    add "transparent2.png" xpos -0.1 ypos -0.8  # Background
    add inventory_list[image_name][3] at image_tilt xalign 0.5 yalign 0.5
    if image_name == "secretsnaps_jp_05":
        add "ending_still" at video_tilt xalign 0.5 yalign 0.5

    # Close button
    imagebutton:
        idle "gui/inventory/button/btn_close.png"
        xpos 0.86
        ypos 0.1
        action [
            Hide("secretsnaps_popup")
        ]

    if active_set == 'canada':
        $ country_prefix = "ca"
    elif active_set == "france":
        $ country_prefix = "fr"
    else:
        $ country_prefix = "jp"

    #Nav
    hbox:
        $ current_num = int(image_name.rsplit("_0", 1)[1])
        $ base_name = "secretsnaps_" + country_prefix + "_0"
        yalign 0.965
        xalign 0.5
        #Left Button
        $ prev_name = Null
        if current_num > 1 and achievement.has(base_name+str(current_num - 1)):
            $ prev_name = base_name+str(current_num - 1)
        elif current_num >2 and achievement.has(base_name+str(current_num - 2)):
            $ prev_name = base_name+str(current_num - 2)
        elif current_num >3 and achievement.has(base_name+str(current_num - 3)):
            $ prev_name = base_name+str(current_num - 3)
        frame:
            xpos -700
            xysize(91,113)
            background Solid('#00000000')
            if prev_name != Null:
                imagebutton idle "gui/inventory/button/btn_left.png" action Show("secretsnaps_popup",image_name = prev_name)
        #Right Button
        $ next_name = Null
        if current_num < 5 and achievement.has(base_name + str(current_num + 1)):
            $ next_name = base_name + str(current_num + 1)
        elif current_num < 4 and achievement.has(base_name + str(current_num + 2)):
            $ next_name = base_name + str(current_num + 2)
        elif current_num < 3 and achievement.has(base_name + str(current_num + 3)):
            $ next_name = base_name + str(current_num + 3)
        frame:
            xpos 700
            xysize(91,113)
            background Solid('#00000000')
            if next_name != Null:
                imagebutton idle "gui/inventory/button/btn_right.png" action Show("secretsnaps_popup",image_name = next_name)

screen photodiary_popup(image_name):
    modal True
    zorder 1000

    add "transparent2.png" xpos -0.1 ypos -0.8  # Background

    # Display main item image
    add inventory_list[image_name][3] at image_tilt xalign 0.5 yalign 0.5

    # Show achievements based on item group    
    if active_set == 'canada':
        $ images = ca_achievement_images
        $ captured = persistent.ca_captured
        $ papes = ca_achievements[image_name]
        $ country_prefix = 'ca'
    elif active_set == 'france':
        $ images = fr_achievement_images
        $ captured = persistent.fr_captured
        $ papes = fr_achievements[image_name]    
        $ country_prefix = 'fr'    
    else: #Japan
        $ images = jp_achievement_images
        $ captured = persistent.jp_captured
        $ papes = jp_achievements[image_name]
        $ country_prefix = 'jp'

    for i in papes:
        if active_set == 'canada':
            $ name = list(ca_achievements.keys())[i]  
            $ pape_pos = ca_achievements[name][2]
        elif active_set == 'france':
            $ name = list(fr_achievements.keys())[i]  
            $ pape_pos = fr_achievements[name][2]       
        else: #Japan
            $ name = list(jp_achievements.keys())[i]  
            $ pape_pos = jp_achievements[name][2]

        if not captured[i]:
            imagebutton:
                pos pape_pos
                idle images[i]
                activate_sound "audio/sys_puppet.mp3"
                action [
                    Function(set_captured_true_for_image, i),
                    Function(grant_achievement_for_image,i),
                ]
    # Close button
    imagebutton:
        idle "gui/inventory/button/btn_close.png"
        xpos 0.8600
        ypos 0.1
        action [
            Hide("photodiary_popup")
        ]
    #Left Right buttons
    hbox:
        yalign 0.965
        xalign 0.5
        frame: #Left
            xpos -700
            xysize(91,113)
            background Solid('#00000000')
            if '2' in image_name:
                imagebutton idle "gui/inventory/button/btn_left.png" action Show("photodiary_popup",image_name="photodiary_"+country_prefix+"_01")
            elif '3' in image_name:
                imagebutton idle "gui/inventory/button/btn_left.png" action Show("photodiary_popup",image_name="photodiary_"+country_prefix+"_02")
        frame: #Right
            xpos 700
            xysize(91,113)
            background Solid('#00000000')
            if '1' in image_name and achievement.has("photodiary_"+country_prefix+"_02"):
                imagebutton idle "gui/inventory/button/btn_right.png" action Show("photodiary_popup",image_name="photodiary_"+country_prefix+"_02")
            elif '2' in image_name and achievement.has("photodiary_"+country_prefix+"_03"):
                imagebutton idle "gui/inventory/button/btn_right.png" action Show("photodiary_popup",image_name="photodiary_"+country_prefix+"_03")

screen gallery_popup(item_click_background,index):
    modal True
    zorder 1000

    add "transparent2.png" xpos -0.1 ypos -0.8
    add item_click_background at image_tilt yalign 0.5 xalign 0.5
    $ length = len(inventory_images[active_set][active_tab])
    $ index_left = index - 1
    $ index_right =index + 1 

    imagebutton:
        idle "gui/inventory/button/btn_close.png"
        xpos 0.8600
        ypos 0.1
        action [
            Hide("gallery_popup")
        ]
    hbox: 
        yalign 0.965
        xalign 0.5
        frame:
            xpos -700
            xysize(91,113)
            background Solid('#00000000')
            if (index_left > -1):
                $ item_background = get_item_background(active_set, active_tab, index_left)
                imagebutton idle "gui/inventory/button/btn_left.png" action [Show("gallery_popup",item_click_background=item_background,index=index_left)] 
            elif active_tab == "travelgallery_2" and (index_left == -1):
                $ item_background = get_item_background(active_set, "travelgallery", 11)
                imagebutton idle "gui/inventory/button/btn_left.png" action [Show("gallery_popup",item_click_background=item_background,index=11),SetVariable("active_tab","travelgallery")] 
        frame:
            xpos 700
            xysize(91,113)
            background Solid('#00000000')
            if (index_right < length) :
                $ item_background = get_item_background(active_set, active_tab, index_right)
                imagebutton idle "gui/inventory/button/btn_right.png" action [Show("gallery_popup",item_click_background=item_background,index=index_right)]
            elif active_tab == "travelgallery" and (index_right == length):
                $ item_background = get_item_background(active_set, "travelgallery_2", 0)
                imagebutton idle "gui/inventory/button/btn_right.png" action [Show("gallery_popup",item_click_background=item_background,index=0),SetVariable("active_tab","travelgallery_2")]
