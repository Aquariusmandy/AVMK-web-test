#Main menu music
define config.main_menu_music = "audio/main_theme.mp3"


#Dialogue & Narration Box  
style vanta_window:
    background Image("gui/gui/ui_dialoguebox_vanta.png",xalign=0.5, yalign=1.0)   
style wilson_window:
    background Image("gui/gui/ui_dialoguebox_wilson.png",xalign=0.5, yalign=1.0)   
style zali_window:
    background Image("gui/gui/ui_dialoguebox_zali.png",xalign=0.5, yalign=1.0)   

style wandv_window:
    background Image("gui/gui/ui_dialoguebox_w&v.png",xalign=0.5, yalign=1.0) 
style vandz_window:
    background Image("gui/gui/ui_dialoguebox_v&z.png",xalign=0.5, yalign=1.0)  
style zandw_window:
    background Image("gui/gui/ui_dialoguebox_z&w.png",xalign=0.5, yalign=1.0)        
style vandc_window:
    background Image("gui/gui/ui_dialoguebox_crew.png",xalign=0.5, yalign=1.0)  
 
style mana_window:
    background Image("gui/gui/ui_dialoguebox_mana.png", xalign=0.5, yalign=1.0) 
style rai_window:
    background Image("gui/gui/ui_dialoguebox_rai.png", xalign=0.5, yalign=1.0) 
    
init: # Initializing nameboxes
    style vanta_namebox:
        background "gui/gui/ui_namebox_vanta.png"
        yalign 1.0  # Means namebox at the bottom of screen
        yoffset -266  # Offset by pixel (Move up)

    style wilson_namebox:
        background "gui/gui/ui_namebox_wilson.png"
        yalign 1.0  # ネームボックスを画面の下端に配置することを意味する
        yoffset -266  # ネームボックスをピクセル単位で上に移動させる

    style zali_namebox:
        background "gui/gui/ui_namebox_zali.png"
        yalign 1.0  # ネームボックスを画面の下端に配置することを意味する
        yoffset -266  # ネームボックスをピクセル単位で上に移動させる

    style mana_namebox:
        background "gui/gui/ui_namebox_mana.png"
        yalign 1.0  # ネームボックスを画面の下端に配置することを意味する
        yoffset -266  # ネームボックスをピクセル単位で上に移動させる 

    style rai_namebox:
        background "gui/gui/ui_namebox_rai.png"
        yalign 1.0  # ネームボックスを画面の下端に配置することを意味する
        yoffset -266  # ネームボックスをピクセル単位で上に移動させる 

    style npc_namebox:
        background "gui/gui/ui_namebox_npc.png"
        yalign 1.0  # ネームボックスを画面の下端に配置することを意味する
        yoffset -266  # ネームボックスをピクセル単位で上に移動させる 

    style wandv_namebox:
        background "gui/gui/ui_namebox_v&w.png"
        yalign 1.0  # ネームボックスを画面の下端に配置することを意味する
        yoffset -266  # ネームボックスをピクセル単位で上に移動させる

    style vandz_namebox:
        background "gui/gui/ui_namebox_v&z.png"
        yalign 1.0  # ネームボックスを画面の下端に配置することを意味する
        yoffset -266  # ネームボックスをピクセル単位で上に移動させる

    style zandw_namebox:
        background "gui/gui/ui_namebox_z&w.png"
        yalign 1.0  # ネームボックスを画面の下端に配置することを意味する
        yoffset -266  # ネームボックスをピクセル単位で上に移動させる


init: # Initializing images (character sprites, background, stills, etc...)

    #Character Sprites
    #Vanta (Casual) 
    image van_c_3 = "images/chara/van_c_3.webp"
    image van_c_con = "images/chara/van_c_confident.webp"
    image van_c_emb = "images/chara/van_c_embarrassed.webp"
    image van_c_hap = "images/chara/van_c_happy.webp"
    image van_c_nor = "images/chara/van_c_normal.webp"
    image van_c_puz = "images/chara/van_c_puzzled.webp"
    image van_c_ser = "images/chara/van_c_serious.webp"
    image van_c_sur = "images/chara/van_c_surprised.webp"  

    #Vanta (Casual no glasses) 
    image van_c2_3 = "images/chara/van_c2_3.webp"
    image van_c2_con = "images/chara/van_c2_confident.webp"
    image van_c2_emb = "images/chara/van_c2_embarrassed.webp"
    image van_c2_hap = "images/chara/van_c2_happy.webp"
    image van_c2_nor = "images/chara/van_c2_normal.webp"
    image van_c2_puz = "images/chara/van_c2_puzzled.webp"
    image van_c2_ser = "images/chara/van_c2_serious.webp"
    image van_c2_sur = "images/chara/van_c2_surprised.webp" 

    #Vanta (Drag)    
    image van_d_3 = "images/chara/van_d_3.webp"
    image van_d_con = "images/chara/van_d_confident.webp"
    image van_d_emb = "images/chara/van_d_embarrassed.webp"
    image van_d_hap = "images/chara/van_d_happy.webp"
    image van_d_nor = "images/chara/van_d_normal.webp"
    image van_d_puz = "images/chara/van_d_puzzled.webp"
    image van_d_ser = "images/chara/van_d_serious.webp"
    image van_d_sur = "images/chara/van_d_surprised.webp"

    #Vanta (Bovine) 
    image van_b_3 = "images/chara/van_b_3.webp"
    image van_b_con = "images/chara/van_b_confident.webp"
    image van_b_emb = "images/chara/van_b_embarrassed.webp"
    image van_b_hap = "images/chara/van_b_happy.webp"
    image van_b_nor = "images/chara/van_b_normal.webp"
    image van_b_puz = "images/chara/van_b_puzzled.webp"
    image van_b_ser = "images/chara/van_b_serious.webp"
    image van_b_sur = "images/chara/van_b_surprised.webp"  

    #Vanta (Naked)    
    image van_n_sle = "images/chara/van_n_sleep.webp"
    image van_n_ser = "images/chara/van_n_serious.webp"
    image van_n_con = "images/chara/van_n_confident.webp"

    #Wilson (Casual)
    image wil_c_hap = "images/chara/wil_c_happy.webp"
    image wil_c_nor = "images/chara/wil_c_normal.webp"
    image wil_c_puz = "images/chara/wil_c_puzzled.webp"
    image wil_c_ser = "images/chara/wil_c_serious.webp"
    image wil_c_sur = "images/chara/wil_c_surprised.webp"

    #Wilson (Casual no glasses)
    image wil_c2_hap = "images/chara/wil_c2_happy.webp"
    image wil_c2_nor = "images/chara/wil_c2_normal.webp"
    image wil_c2_puz = "images/chara/wil_c2_puzzled.webp"
    image wil_c2_ser = "images/chara/wil_c2_serious.webp"
    image wil_c2_sur = "images/chara/wil_c2_surprised.webp"

    #Wilson (Drag)
    image wil_d_hap = "images/chara/wil_d_happy.webp"
    image wil_d_nor = "images/chara/wil_d_normal.webp"
    image wil_d_puz = "images/chara/wil_d_puzzled.webp"
    image wil_d_ser = "images/chara/wil_d_serious.webp"
    image wil_d_sur = "images/chara/wil_d_surprised.webp"

    #Wilson (Bovine)
    image wil_b_hap = "images/chara/wil_b_happy.webp"
    image wil_b_nor = "images/chara/wil_b_normal.webp"
    image wil_b_puz = "images/chara/wil_b_puzzled.webp"
    image wil_b_ser = "images/chara/wil_b_serious.webp"
    image wil_b_sur = "images/chara/wil_b_surprised.webp"

    #Wilson (Naked) 
    image wil_n_sle = "images/chara/wil_n_sleep.webp"
    image wil_n_puz = "images/chara/wil_n_puzzled.webp"
    image wil_n_ser = "images/chara/wil_n_serious.webp"

    #Zali (Casual)
    image zal_c_hap = "images/chara/zal_c_happy.webp"
    image zal_c_nor = "images/chara/zal_c_normal.webp"
    image zal_c_puz = "images/chara/zal_c_puzzled.webp"
    image zal_c_ser = "images/chara/zal_c_serious.webp"
    image zal_c_sur = "images/chara/zal_c_surprised.webp"   

    #Zali (Casual no glasses)
    image zal_c2_hap = "images/chara/zal_c2_happy.webp"
    image zal_c2_nor = "images/chara/zal_c2_normal.webp"
    image zal_c2_puz = "images/chara/zal_c2_puzzled.webp"
    image zal_c2_ser = "images/chara/zal_c2_serious.webp"
    image zal_c2_sur = "images/chara/zal_c2_surprised.webp"  

    #Zali (Drag)
    image zal_d_hap = "images/chara/zal_d_happy.webp"
    image zal_d_nor = "images/chara/zal_d_normal.webp"
    image zal_d_puz = "images/chara/zal_d_puzzled.webp"
    image zal_d_ser = "images/chara/zal_d_serious.webp"
    image zal_d_sur = "images/chara/zal_d_surprised.webp"               
    
    #Zali (Naked) 
    image zal_n_nor = "images/chara/zal_n_normal.webp"
    image zal_n_ser = "images/chara/zal_n_serious.webp"

    #CVisuals
    image ca_cv = "images/cvisual/ca_cv.webp"
    image fr_cv = "images/cvisual/fr_cv.webp"
    image jp_cv = "images/cvisual/jp_cv.webp"
    image main_menu = "images/cvisual/main_menu.png"
    image main_menu_2 = "images/cvisual/main_menu_2.png"

    #Still
    image ca_st_edcg = "images/still/ca_st_edcg.webp"
    image fr_st_edcg = "images/still/fr_st_edcg.webp"
    image jp_st_edcg = "images/still/jp_st_edcg.webp"

# Defining characters

define vanta_char = Character(_("Vantacrow"), color="#473027", window_style='vanta_window', namebox_style="vanta_namebox")
define wilson_char = Character(_("Wilson"), color="#473027", window_style='wilson_window',namebox_style="wilson_namebox")
define zali_char = Character(_( "Vezalius"), color="#473027", window_style='zali_window', namebox_style="zali_namebox")
define wandv_char = Character(_("Wilson & Vantacrow"), color="#473027", window_style='wandv_window', namebox_style="wandv_namebox")
define vandz_char = Character(_("Vantacrow & Vezalius"), color="#473027", window_style='vandz_window', namebox_style="vandz_namebox")
define zandw_char = Character(_("Vezalius & Wilson"), color="#473027", window_style='zandw_window', namebox_style="zandw_namebox")
define vandc_char = Character(_("Vantacrow & Crew"), color="#473027", window_style='vandc_window', namebox_style="vandc_namebox")
define mana_char = Character(_("Mana"),color='#473027', window_style = "mana_window",namebox_style="mana_namebox")
define rai_char = Character(_("Rai"),color='#473027', window_style = "rai_window",namebox_style="rai_namebox")




#キャラクターの立ち位置2人の時
transform left_2p:
    xalign 0.15
    yalign 0.2
    zoom 1.1  # 110%の拡大
transform right_2p:
    xalign 0.95
    yalign 0.2
    zoom 1.1  # 110%の拡大

#キャラクターの立ち位置3人の時
transform center:
    xalign 0.5
    yalign 0.2
    zoom 1.1  # 110%の拡大
transform left:
    xalign -0.1
    yalign 0.2
    zoom 1.1  # 110%の拡大
transform right:
    xalign 1.1
    yalign 0.2
    zoom 1.1  # 110%の拡大

# Comic placementコミックの配置
transform fr_com_real_upper:
    xalign 0.5 # 中央より左。0.5が中央なので、それより小さな値。
    yalign 0.1 # 中央より上。0.5が中央なので、それより小さな値。

transform earthquake_before:
    xpos 0.5 ypos 0.5
    anchor (0.5, 0.5)
    zoom 1.1

transform earthquake:
    xpos 0.5 ypos 0.5
    anchor (0.5, 0.5)
    zoom 1.1
    linear 0.05 xoffset -10 yoffset -10
    linear 0.05 xoffset 10 yoffset 10
    linear 0.05 xoffset -10 yoffset -10
    linear 0.05 xoffset 10 yoffset 10
    linear 0.05 xoffset 0 yoffset 0
    linear 0.05 xoffset -10 yoffset -10
    linear 0.05 xoffset 10 yoffset 10
    linear 0.05 xoffset -10 yoffset -10
    linear 0.05 xoffset 10 yoffset 10
    linear 0.05 xoffset 0 yoffset 0

default last_screen = None
default active_set = "canada"
default active_tab = "secretsnaps"
default country_prefix = "ca"


image 5 = "images/home_image.jpg"

label splashscreen:
    
    #show white
    #$ renpy.music.play("audio/main_theme.mp3", channel="music", loop=True)
    # Display the video
    #$ renpy.movie_cutscene("movies/30 seconds.webm", loops=30, stop_music=False) 
    show white with dissolve
    # show 5 with dissolve
    pause 1.0
    hide white with dissolve
    # Hide the image with dissolve
    # hide 5 
    return
image red_dot = "gui/menubutton/red_dot.png" 
image white = "temp/white.jpg"
image ending_still = Movie(play="movies/ending_animation.webm",channel='movie')

init python:
       
    class Item(object):
        def __init__(self, name, idle, hover, locked, background):
            self.name = name
            self.idle = idle
            self.hover = hover
            self.locked = locked
            self.background = background
    # Initialize items


    # gui/inventory/minigame/sticker
    stickers = ['sticker_ca_01','sticker_ca_02','sticker_ca_03','sticker_ca_04','sticker_ca_05','sticker_fr_01','sticker_fr_02','sticker_fr_03','sticker_fr_04','sticker_fr_05','sticker_jp_01','sticker_jp_02','sticker_jp_03','sticker_jp_04','sticker_jp_05']
    # gui/inventory/secretsnaps
    secretsnaps_images = ['secretsnaps_ca_01','secretsnaps_ca_02','secretsnaps_ca_03','secretsnaps_ca_04','secretsnaps_ca_05','secretsnaps_fr_01','secretsnaps_fr_02','secretsnaps_fr_03','secretsnaps_fr_04','secretsnaps_fr_05','secretsnaps_jp_01','secretsnaps_jp_02','secretsnaps_jp_03','secretsnaps_jp_04','secretsnaps_jp_05']
    # gui/inventory/photodiary
    photodiary_images = ['photodiary_ca_01','photodiary_ca_02','photodiary_ca_03','photodiary_fr_01','photodiary_fr_02','photodiary_fr_03','photodiary_jp_01','photodiary_jp_02','photodiary_jp_03']

    traveled_images = []

    inventory_list = {}

    for i in stickers:
        name = i
        default = "gui/inventory/minigame/sticker/"+name+".png"
        locked = "gui/inventory/lock_seal.png"
        popup = "gui/inventory/minigame/get_pop_sticker/get_"+name+".webp"
        inventory_list[name]=[name, default, locked, popup]

    for i in secretsnaps_images:
        name = i
        default = "gui/inventory/secretsnaps/"+name+"_big.webp"
        locked =  "gui/inventory/secretsnaps/"+name+"_big.webp"
        popup = "gui/inventory/secretsnaps/"+name+"_big.webp"
        inventory_list[name]=[name, default, locked, popup]

    for i in photodiary_images:
        name = i
        default = "gui/inventory/photodiary/"+name+"_big.webp"
        locked = "gui/inventory/photodiary/"+name+"_big.webp"
        popup = "gui/inventory/photodiary/"+name+"_big.webp"
        inventory_list[name]=[name, default, locked, popup]    
    
    ### CGs - For Gallery ###
    
    ca_gallery_list = {}
    fr_gallery_list = {}
    jp_gallery_list = {}
    #ca
    for i in range(1,21):
        if i<10:
            name = 'travelgallery_ca_0'+str(i)
        else:
            name = "travelgallery_ca_"+str(i)
        filename = "gui/inventory/travelgallery/"+name+".webp"
        ca_gallery_list[i]=[name,filename]
    
    #fr
    for i in range(1,20):
        if i<10:
            name = 'travelgallery_fr_0'+str(i)
        else:
            name = "travelgallery_fr_"+str(i)
        filename = "gui/inventory/travelgallery/"+name+".webp"
        fr_gallery_list[i] =[name,filename]

    #jp
    for i in range(1,19):
        if i<10:
            name = 'travelgallery_jp_0'+str(i)
        else:
            name = "travelgallery_jp_"+str(i)
        filename = "gui/inventory/travelgallery/"+name+".webp"
        jp_gallery_list[i] = [name, filename]

    # Try to use achievement to implement the "lock inventory_" function
    achievement.register('controlnew')


    seenlist = {}
    ### popup first see item
    for i in range(9):
        name = "seen_"+str(i)
        seenlist[name] = True


    # Obtain items

    def get_item_background(set_name, tab_name, item_index):
        try:
            background_info = inventory_images[set_name][tab_name][item_index]["background"]
            return background_info  # Default alignment for other tabs
        except KeyError:
            return "Background not available"  # Return a default placeholder image if background is not available

    def get_item_name(set_name, tab_name, item_index):
        try:
            return inventory_images[set_name][tab_name][item_index]["name"]
        except KeyError:
            return "Name not available"

    def get_item_locked(set_name, tab_name, item_index):
        try:
            return inventory_images[set_name][tab_name][item_index]["locked"]
        except KeyError:
            return "Name not available"

    inventory_images = {
        "canada": {
            "photodiary": [
                {"name": inventory_list['photodiary_ca_01'][0], "idle": inventory_list['photodiary_ca_01'][1], "locked":inventory_list['photodiary_ca_01'][2],"background":inventory_list['photodiary_ca_01'][3],"transform":photodiary_01},
                {"name": inventory_list['sticker_ca_01'][0], "idle": inventory_list['sticker_ca_01'][1], "locked":inventory_list['sticker_ca_01'][2],"background":inventory_list['sticker_ca_01'][3]},
                {"name": inventory_list['sticker_ca_02'][0], "idle": inventory_list['sticker_ca_02'][1], "locked":inventory_list['sticker_ca_02'][2],"background":inventory_list['sticker_ca_02'][3]},
                {"name": inventory_list['photodiary_ca_02'][0], "idle": inventory_list['photodiary_ca_02'][1], "locked":inventory_list['photodiary_ca_02'][2],"background":inventory_list['photodiary_ca_02'][3],"transform":photodiary_02},
                {"name": inventory_list['sticker_ca_03'][0], "idle": inventory_list['sticker_ca_03'][1], "locked":inventory_list['sticker_ca_03'][2],"background":inventory_list['sticker_ca_03'][3]},
                {"name": inventory_list['sticker_ca_04'][0], "idle": inventory_list['sticker_ca_04'][1], "locked":inventory_list['sticker_ca_04'][2],"background":inventory_list['sticker_ca_04'][3]},
                {"name": inventory_list['photodiary_ca_03'][0], "idle": inventory_list['photodiary_ca_03'][1], "locked":inventory_list['photodiary_ca_03'][2],"background":inventory_list['photodiary_ca_03'][3],"transform":photodiary_03},                
                {"name": inventory_list['sticker_ca_05'][0], "idle": inventory_list['sticker_ca_05'][1], "locked":inventory_list['sticker_ca_05'][2],"background":inventory_list['sticker_ca_05'][3]},
                
            ],
            "secretsnaps": [
                {"name": inventory_list['secretsnaps_ca_01'][0], "idle": inventory_list['secretsnaps_ca_01'][1], "locked":inventory_list['secretsnaps_ca_01'][2],"background":inventory_list['secretsnaps_ca_01'][3],"transform":secretsnap_01},
                {"name": inventory_list['secretsnaps_ca_03'][0], "idle": inventory_list['secretsnaps_ca_03'][1], "locked":inventory_list['secretsnaps_ca_03'][2],"background":inventory_list['secretsnaps_ca_03'][3],"transform":secretsnap_03}, 
                {"name": inventory_list['secretsnaps_ca_04'][0], "idle": inventory_list['secretsnaps_ca_04'][1], "locked":inventory_list['secretsnaps_ca_04'][2],"background":inventory_list['secretsnaps_ca_04'][3],"transform":secretsnap_04},               
                {"name": inventory_list['secretsnaps_ca_02'][0], "idle": inventory_list['secretsnaps_ca_02'][1], "locked":inventory_list['secretsnaps_ca_02'][2],"background":inventory_list['secretsnaps_ca_02'][3],"transform":secretsnap_02},
                {"name": inventory_list['secretsnaps_ca_05'][0], "idle": inventory_list['secretsnaps_ca_05'][1], "locked":inventory_list['secretsnaps_ca_05'][2],"background":inventory_list['secretsnaps_ca_05'][3],"transform":secretsnap_05},
            ],
            "travelgallery": [
                {"name": ca_gallery_list[1][0], "idle":ca_gallery_list[1][1],"background":ca_gallery_list[1][1]},
                {"name": ca_gallery_list[2][0], "idle":ca_gallery_list[2][1],"background":ca_gallery_list[2][1]},
                {"name": ca_gallery_list[3][0], "idle":ca_gallery_list[3][1],"background":ca_gallery_list[3][1]},
                {"name": ca_gallery_list[4][0], "idle":ca_gallery_list[4][1],"background":ca_gallery_list[4][1]},
                {"name": ca_gallery_list[5][0], "idle":ca_gallery_list[5][1],"background":ca_gallery_list[5][1]},
                {"name": ca_gallery_list[6][0], "idle":ca_gallery_list[6][1],"background":ca_gallery_list[6][1]},
                {"name": ca_gallery_list[7][0], "idle":ca_gallery_list[7][1],"background":ca_gallery_list[7][1]},
                {"name": ca_gallery_list[8][0], "idle":ca_gallery_list[8][1],"background":ca_gallery_list[8][1]},
                {"name": ca_gallery_list[9][0], "idle":ca_gallery_list[9][1],"background":ca_gallery_list[9][1]},
                {"name": ca_gallery_list[10][0], "idle":ca_gallery_list[10][1],"background":ca_gallery_list[10][1]},
                {"name": ca_gallery_list[11][0], "idle":ca_gallery_list[11][1],"background":ca_gallery_list[11][1]},
                {"name": ca_gallery_list[12][0], "idle":ca_gallery_list[12][1],"background":ca_gallery_list[12][1]},
            ],
            "travelgallery_2":[
                {"name": ca_gallery_list[13][0], "idle":ca_gallery_list[13][1],"background":ca_gallery_list[13][1]},
                {"name": ca_gallery_list[14][0], "idle":ca_gallery_list[14][1],"background":ca_gallery_list[14][1]},
                {"name": ca_gallery_list[15][0], "idle":ca_gallery_list[15][1],"background":ca_gallery_list[15][1]},
                {"name": ca_gallery_list[16][0], "idle":ca_gallery_list[16][1],"background":ca_gallery_list[16][1]},
                {"name": ca_gallery_list[17][0], "idle":ca_gallery_list[17][1],"background":ca_gallery_list[17][1]},
                {"name": ca_gallery_list[18][0], "idle":ca_gallery_list[18][1],"background":ca_gallery_list[18][1]},
                {"name": ca_gallery_list[19][0], "idle":ca_gallery_list[19][1],"background":ca_gallery_list[19][1]},
                {"name": ca_gallery_list[20][0], "idle":ca_gallery_list[20][1],"background":ca_gallery_list[20][1]},
            ]

        },
        "france": {
            "photodiary": [
                {"name": inventory_list['photodiary_fr_01'][0], "idle": inventory_list['photodiary_fr_01'][1], "locked":inventory_list['photodiary_fr_01'][2],"background":inventory_list['photodiary_fr_01'][3],"transform":photodiary_01,},
                {"name": inventory_list['sticker_fr_01'][0], "idle": inventory_list['sticker_fr_01'][1], "locked":inventory_list['sticker_fr_01'][2],"background":inventory_list['sticker_fr_01'][3]},
                {"name": inventory_list['sticker_fr_02'][0], "idle": inventory_list['sticker_fr_02'][1], "locked":inventory_list['sticker_fr_02'][2],"background":inventory_list['sticker_fr_02'][3]},
                {"name": inventory_list['photodiary_fr_02'][0], "idle": inventory_list['photodiary_fr_02'][1], "locked":inventory_list['photodiary_fr_02'][2],"background":inventory_list['photodiary_fr_02'][3],"transform":photodiary_02},
                {"name": inventory_list['sticker_fr_03'][0], "idle": inventory_list['sticker_fr_03'][1], "locked":inventory_list['sticker_fr_03'][2],"background":inventory_list['sticker_fr_03'][3]},
                {"name": inventory_list['sticker_fr_04'][0], "idle": inventory_list['sticker_fr_04'][1], "locked":inventory_list['sticker_fr_04'][2],"background":inventory_list['sticker_fr_04'][3]},
                {"name": inventory_list['photodiary_fr_03'][0], "idle": inventory_list['photodiary_fr_03'][1], "locked":inventory_list['photodiary_fr_03'][2],"background":inventory_list['photodiary_fr_03'][3],"transform":photodiary_03},                
                {"name": inventory_list['sticker_fr_05'][0], "idle": inventory_list['sticker_fr_05'][1], "locked":inventory_list['sticker_fr_05'][2],"background":inventory_list['sticker_fr_05'][3]}, 
            ],
            "secretsnaps": [
                {"name": inventory_list['secretsnaps_fr_01'][0], "idle": inventory_list['secretsnaps_fr_01'][1], "locked":inventory_list['secretsnaps_fr_01'][2],"background":inventory_list['secretsnaps_fr_01'][3],"transform":secretsnap_01},
                {"name": inventory_list['secretsnaps_fr_03'][0], "idle": inventory_list['secretsnaps_fr_03'][1], "locked":inventory_list['secretsnaps_fr_03'][2],"background":inventory_list['secretsnaps_fr_03'][3],"transform":secretsnap_03},
                {"name": inventory_list['secretsnaps_fr_04'][0], "idle": inventory_list['secretsnaps_fr_04'][1], "locked":inventory_list['secretsnaps_fr_04'][2],"background":inventory_list['secretsnaps_fr_04'][3],"transform":secretsnap_04},                                
                {"name": inventory_list['secretsnaps_fr_02'][0], "idle": inventory_list['secretsnaps_fr_02'][1], "locked":inventory_list['secretsnaps_fr_02'][2],"background":inventory_list['secretsnaps_fr_02'][3],"transform":secretsnap_02},
                {"name": inventory_list['secretsnaps_fr_05'][0], "idle": inventory_list['secretsnaps_fr_05'][1], "locked":inventory_list['secretsnaps_fr_05'][2],"background":inventory_list['secretsnaps_fr_05'][3],"transform":secretsnap_05},
            ],
            "travelgallery": [
                {"name": fr_gallery_list[1][0], "idle":fr_gallery_list[1][1],"background":fr_gallery_list[1][1]},
                {"name": fr_gallery_list[2][0], "idle":fr_gallery_list[2][1],"background":fr_gallery_list[2][1]},
                {"name": fr_gallery_list[3][0], "idle":fr_gallery_list[3][1],"background":fr_gallery_list[3][1]},
                {"name": fr_gallery_list[4][0], "idle":fr_gallery_list[4][1],"background":fr_gallery_list[4][1]},
                {"name": fr_gallery_list[5][0], "idle":fr_gallery_list[5][1],"background":fr_gallery_list[5][1]},
                {"name": fr_gallery_list[6][0], "idle":fr_gallery_list[6][1],"background":fr_gallery_list[6][1]},
                {"name": fr_gallery_list[7][0], "idle":fr_gallery_list[7][1],"background":fr_gallery_list[7][1]},
                {"name": fr_gallery_list[8][0], "idle":fr_gallery_list[8][1],"background":fr_gallery_list[8][1]},
                {"name": fr_gallery_list[9][0], "idle":fr_gallery_list[9][1],"background":fr_gallery_list[9][1]},
                {"name": fr_gallery_list[10][0], "idle":fr_gallery_list[10][1],"background":fr_gallery_list[10][1]},
                {"name": fr_gallery_list[11][0], "idle":fr_gallery_list[11][1],"background":fr_gallery_list[11][1]},
                {"name": fr_gallery_list[12][0], "idle":fr_gallery_list[12][1],"background":fr_gallery_list[12][1]},
            ],
            "travelgallery_2":[
                {"name": fr_gallery_list[13][0], "idle":fr_gallery_list[13][1],"background":fr_gallery_list[13][1]},
                {"name": fr_gallery_list[14][0], "idle":fr_gallery_list[14][1],"background":fr_gallery_list[14][1]},
                {"name": fr_gallery_list[15][0], "idle":fr_gallery_list[15][1],"background":fr_gallery_list[15][1]},
                {"name": fr_gallery_list[16][0], "idle":fr_gallery_list[16][1],"background":fr_gallery_list[16][1]},
                {"name": fr_gallery_list[17][0], "idle":fr_gallery_list[17][1],"background":fr_gallery_list[17][1]},
                {"name": fr_gallery_list[18][0], "idle":fr_gallery_list[18][1],"background":fr_gallery_list[18][1]},
                {"name": fr_gallery_list[19][0], "idle":fr_gallery_list[19][1],"background":fr_gallery_list[19][1]},                        
            ]
           
        },
        "japan": {
            "photodiary": [
                {"name": inventory_list['photodiary_jp_01'][0], "idle": inventory_list['photodiary_jp_01'][1], "locked":inventory_list['photodiary_jp_01'][2],"background":inventory_list['photodiary_jp_01'][3],"transform":photodiary_01},
                {"name": inventory_list['sticker_jp_01'][0], "idle": inventory_list['sticker_jp_01'][1], "locked":inventory_list['sticker_jp_01'][2],"background":inventory_list['sticker_jp_01'][3]},
                {"name": inventory_list['sticker_jp_02'][0], "idle": inventory_list['sticker_jp_02'][1], "locked":inventory_list['sticker_jp_02'][2],"background":inventory_list['sticker_jp_02'][3]},
                {"name": inventory_list['photodiary_jp_02'][0], "idle": inventory_list['photodiary_jp_02'][1], "locked":inventory_list['photodiary_jp_02'][2],"background":inventory_list['photodiary_jp_02'][3],"transform":photodiary_02},
                {"name": inventory_list['sticker_jp_03'][0], "idle": inventory_list['sticker_jp_03'][1], "locked":inventory_list['sticker_jp_03'][2],"background":inventory_list['sticker_jp_03'][3]},
                {"name": inventory_list['sticker_jp_04'][0], "idle": inventory_list['sticker_jp_04'][1], "locked":inventory_list['sticker_jp_04'][2],"background":inventory_list['sticker_jp_04'][3]},
                {"name": inventory_list['photodiary_jp_03'][0], "idle": inventory_list['photodiary_jp_03'][1], "locked":inventory_list['photodiary_jp_03'][2],"background":inventory_list['photodiary_jp_03'][3],"transform":photodiary_03},                
                {"name": inventory_list['sticker_jp_05'][0], "idle": inventory_list['sticker_jp_05'][1], "locked":inventory_list['sticker_jp_05'][2],"background":inventory_list['sticker_jp_05'][3]}, 
            ],
            "secretsnaps": [
                {"name": inventory_list['secretsnaps_jp_01'][0], "idle": inventory_list['secretsnaps_jp_01'][1], "locked":inventory_list['secretsnaps_jp_01'][2],"background":inventory_list['secretsnaps_jp_01'][3], "transform":secretsnap_01},
                {"name": inventory_list['secretsnaps_jp_03'][0], "idle": inventory_list['secretsnaps_jp_03'][1], "locked":inventory_list['secretsnaps_jp_03'][2],"background":inventory_list['secretsnaps_jp_03'][3], "transform":secretsnap_03},
                {"name": inventory_list['secretsnaps_jp_04'][0], "idle": inventory_list['secretsnaps_jp_04'][1], "locked":inventory_list['secretsnaps_jp_04'][2],"background":inventory_list['secretsnaps_jp_04'][3], "transform":secretsnap_04},                                
                {"name": inventory_list['secretsnaps_jp_02'][0], "idle": inventory_list['secretsnaps_jp_02'][1], "locked":inventory_list['secretsnaps_jp_02'][2],"background":inventory_list['secretsnaps_jp_02'][3], "transform":secretsnap_02},
                {"name": inventory_list['secretsnaps_jp_05'][0], "idle": inventory_list['secretsnaps_jp_05'][1], "locked":inventory_list['secretsnaps_jp_05'][2],"background":inventory_list['secretsnaps_jp_05'][3], "transform":secretsnap_05},
            ],
            "travelgallery": [
                {"name": jp_gallery_list[1][0], "idle":jp_gallery_list[1][1],"background":jp_gallery_list[1][1]},
                {"name": jp_gallery_list[2][0], "idle":jp_gallery_list[2][1],"background":jp_gallery_list[2][1]},
                {"name": jp_gallery_list[3][0], "idle":jp_gallery_list[3][1],"background":jp_gallery_list[3][1]},
                {"name": jp_gallery_list[4][0], "idle":jp_gallery_list[4][1],"background":jp_gallery_list[4][1]},
                {"name": jp_gallery_list[5][0], "idle":jp_gallery_list[5][1],"background":jp_gallery_list[5][1]},
                {"name": jp_gallery_list[6][0], "idle":jp_gallery_list[6][1],"background":jp_gallery_list[6][1]},
                {"name": jp_gallery_list[7][0], "idle":jp_gallery_list[7][1],"background":jp_gallery_list[7][1]},
                {"name": jp_gallery_list[8][0], "idle":jp_gallery_list[8][1],"background":jp_gallery_list[8][1]},
                {"name": jp_gallery_list[9][0], "idle":jp_gallery_list[9][1],"background":jp_gallery_list[9][1]},
                {"name": jp_gallery_list[10][0], "idle":jp_gallery_list[10][1],"background":jp_gallery_list[10][1]},
                {"name": jp_gallery_list[11][0], "idle":jp_gallery_list[11][1],"background":jp_gallery_list[11][1]},
                {"name": jp_gallery_list[12][0], "idle":jp_gallery_list[12][1],"background":jp_gallery_list[12][1]},
            ],
            "travelgallery_2":[
                {"name": jp_gallery_list[13][0], "idle":jp_gallery_list[13][1],"background":jp_gallery_list[13][1]},
                {"name": jp_gallery_list[14][0], "idle":jp_gallery_list[14][1],"background":jp_gallery_list[14][1]},
                {"name": jp_gallery_list[15][0], "idle":jp_gallery_list[15][1],"background":jp_gallery_list[15][1]},
                {"name": jp_gallery_list[16][0], "idle":jp_gallery_list[16][1],"background":jp_gallery_list[16][1]},
                {"name": jp_gallery_list[17][0], "idle":jp_gallery_list[17][1],"background":jp_gallery_list[17][1]},
                {"name": jp_gallery_list[18][0], "idle":jp_gallery_list[18][1],"background":jp_gallery_list[18][1]},
            ]
        }
    }

default zorder = -2
default red_dot_shown = False
default showinventory_ = -1 #this is for option 2
default persistent.achievement_popup_shown = False # this is for option 1
default persistent.cleared_game = False
default persistent.endgame_popup = False
default mini_game = False

image credits_image:
    contains:
        "system/credits transparent with drafts.webp"
        xalign 0.5
        yalign -0.05
        linear 120.0 yalign 0.961 #Will need to adjust based on image length #number for linear changes speed

screen ending_credits():
    frame:
        background Solid('#000000FF')
        add "credits_image"

label start:
    $ achievement.clear_all()
    $ persistent._clear()
    $ renpy.clear_retain()
    $ renpy.restart_interaction() 
    $ quick_menu = True
    jump chapter_1 